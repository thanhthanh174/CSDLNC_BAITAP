------------------------BAI TAP TUAN 6----------------------------------------
--CÂU 1:
--Tạo bảng Ngân hàng
CREATE TABLE NganHang (
    MaNH NUMBER PRIMARY KEY,
    TenNH VARCHAR2(100)
);

--Tạo bảng Chi nhánh
CREATE TABLE ChiNhanh (
    MaNH NUMBER,
    MaCN VARCHAR2(10),
    ThanhPhoCN VARCHAR2(50),
    TaiSan NUMBER,
    PRIMARY KEY (MaCN),
    FOREIGN KEY (MaNH) REFERENCES NganHang(MaNH)
);

--Tạo bảng Khách hàng
CREATE TABLE KhachHang (
    MaKH VARCHAR2(20) PRIMARY KEY,
    TenKH VARCHAR2(100),
    DiaChi VARCHAR2(200)
);

--Tạo bảng Tài khoản gởi
CREATE TABLE TaiKhoanGoi (
    MaKH VARCHAR2(20),
    MaCN VARCHAR2(10),
    SoTKG VARCHAR2(20),
    SoTienGoi NUMBER,
    PRIMARY KEY (SoTKG),
    FOREIGN KEY (MaKH) REFERENCES KhachHang(MaKH),
    FOREIGN KEY (MaCN) REFERENCES ChiNhanh(MaCN)
);

--Tạo bảng Tài khoản vay
CREATE TABLE TaiKhoanVay (
    MaKH VARCHAR2(20),
    MaCN VARCHAR2(10),
    SoTKV VARCHAR2(20),
    SoTienVay NUMBER,
    PRIMARY KEY (SoTKV),
    FOREIGN KEY (MaKH) REFERENCES KhachHang(MaKH),
    FOREIGN KEY (MaCN) REFERENCES ChiNhanh(MaCN)
);


--CÂU 2:
--Dữ liệu bảng Ngân hàng
INSERT INTO NganHang VALUES (1,'Ngan Hang Cong Thuong');
INSERT INTO NganHang VALUES (2,'Ngan Hang Ngoai Thuong');
INSERT INTO NganHang VALUES (3,'Ngan Hang Nong Nghiep');
INSERT INTO NganHang VALUES (4,'Ngan Hang A Chau');
INSERT INTO NganHang VALUES (5,'Ngan Hang Thuong Tin');

SELECT * FROM NganHang

--Dữ liệu bảng Chi nhánh
INSERT INTO ChiNhanh VALUES (1,'CN01','Da Lat',2000000000);
INSERT INTO ChiNhanh VALUES (2,'CN02','Nha Trang',2700000000);
INSERT INTO ChiNhanh VALUES (3,'CN03','Thanh Hoa',4500000000);
INSERT INTO ChiNhanh VALUES (4,'CN04','TP HCM',6000000000);
INSERT INTO ChiNhanh VALUES (5,'CN05','Da Nang',7000000000);
INSERT INTO ChiNhanh VALUES (1,'CN11','TP HCM',5000000000);
INSERT INTO ChiNhanh VALUES (2,'CN12','Hue',1400000000);
INSERT INTO ChiNhanh VALUES (3,'CN13','Da Nang',3600000000);
INSERT INTO ChiNhanh VALUES (4,'CN14','Ha Noi',5700000000);
INSERT INTO ChiNhanh VALUES (1,'CN21','Ha Noi',3500000000);
INSERT INTO ChiNhanh VALUES (2,'CN22','Ha Noi',4500000000);
INSERT INTO ChiNhanh VALUES (3,'CN23','Da Lat',2400000000);
INSERT INTO ChiNhanh VALUES (1,'CN31','Da Nang',4000000000);
INSERT INTO ChiNhanh VALUES (2,'CN32','TP HCM',5600000000);
INSERT INTO ChiNhanh VALUES (3,'CN33','Can Tho',5400000000);
INSERT INTO ChiNhanh VALUES (3,'CN43','Nam Dinh',3600000000);

SELECT * FROM ChiNhanh

--Dữ liệu bảng Khách hàng
INSERT INTO KhachHang VALUES ('111222333','Ho Thi Thanh Thao','456 Le Duan, Ha Noi');
INSERT INTO KhachHang VALUES ('112233445','Tran Van Tien','12 Dien Bien Phu, Q1, TP HCM');
INSERT INTO KhachHang VALUES ('123123123','Phan Thi Quynh Nhu','54 Hai Ba Trung, Ha Noi');
INSERT INTO KhachHang VALUES ('123412341','Nguyen Van Thao','34 Tran Phu, TP Nha Trang');
INSERT INTO KhachHang VALUES ('123456789','Nguyen Thi Hoa','1/4 Hoang Van Thu, Da Lat');
INSERT INTO KhachHang VALUES ('221133445','Nguyen Thi Kim Mai','4 Tran Binh Trong, Da Lat');
INSERT INTO KhachHang VALUES ('222111333','Do Tien Dong','123 Tran Phu, Nam Dinh');
INSERT INTO KhachHang VALUES ('331122445','Bui Thi Dong','345 Tran Hung Dao, Thanh Hoa');
INSERT INTO KhachHang VALUES ('333111222','Tran Dinh Hung','783 Ly Thuong Kiet, Can Tho');
INSERT INTO KhachHang VALUES ('441122335','Nguyen Dinh Cuong','P12 Thanh Xuan Nam, Thanh Xuan');
INSERT INTO KhachHang VALUES ('456456456','Tran Nam Son','5 Le Duan, TP Da Nang');
INSERT INTO KhachHang VALUES ('551122334','Tran Thi Khanh Van','1A Ho Tung Mau, Da Lat');
INSERT INTO KhachHang VALUES ('987654321','Ho Thanh Son','209 Tran Hung Dao, Q5, TP HCM');

SELECT * FROM KhachHang

--Dữ liệu bảng Tài khoản gởi
INSERT INTO TaiKhoanGoi VALUES ('123123123','CN01','00001A',10000000);
INSERT INTO TaiKhoanGoi VALUES ('123456789','CN01','00001C',127000000);
INSERT INTO TaiKhoanGoi VALUES ('221133445','CN02','00002A',12500000);
INSERT INTO TaiKhoanGoi VALUES ('456456456','CN03','00003H',123000000);
INSERT INTO TaiKhoanGoi VALUES ('222111333','CN05','00005A',1200000);
INSERT INTO TaiKhoanGoi VALUES ('987654321','CN05','00005D',345000000);
INSERT INTO TaiKhoanGoi VALUES ('123412341','CN05','00005N',45000000);
INSERT INTO TaiKhoanGoi VALUES ('331122445','CN13','00003A',27000000);
INSERT INTO TaiKhoanGoi VALUES ('551122334','CN14','00004D',560000000);
INSERT INTO TaiKhoanGoi VALUES ('123456789','CN14','00004P',35400000);
INSERT INTO TaiKhoanGoi VALUES ('123412341','CN21','00001B',67000000);
INSERT INTO TaiKhoanGoi VALUES ('222111333','CN22','00002G',56000000);
INSERT INTO TaiKhoanGoi VALUES ('987654321','CN23','00004F',4500000);
INSERT INTO TaiKhoanGoi VALUES ('333111222','CN33','00003D',47000000);

SELECT * FROM TaiKhoanGoi

--Dữ liệu Tài khoản vay
INSERT INTO TaiKhoanVay VALUES ('111222333','CN01','10001A',10000000);
INSERT INTO TaiKhoanVay VALUES ('333111222','CN02','10002A',6000000);
INSERT INTO TaiKhoanVay VALUES ('551122334','CN04','10004A',20000000);
INSERT INTO TaiKhoanVay VALUES ('221133445','CN05','10005G',15000000);
INSERT INTO TaiKhoanVay VALUES ('987654321','CN11','10001D',45000000);
INSERT INTO TaiKhoanVay VALUES ('112233445','CN12','10002D',12000000);
INSERT INTO TaiKhoanVay VALUES ('441122335','CN13','10003F',5500000);
INSERT INTO TaiKhoanVay VALUES ('123123123','CN14','10005A',12500000);

SELECT * FROM TaiKhoanVay

--CÂU 3: TRUY VẤN
--1.
SELECT DISTINCT TenNH
FROM NganHang NH JOIN ChiNhanh CN ON NH.MaNH = CN.MaNH
WHERE CN.ThanhPhoCN = 'Da Lat';

--2.
SELECT DISTINCT CN.ThanhPhoCN
FROM NganHang NH JOIN ChiNhanh CN ON NH.MaNH = CN.MaNH
WHERE NH.TenNH = 'Ngan Hang Cong Thuong';

--3.
SELECT CN.*
FROM ChiNhanh CN JOIN NganHang NH ON CN.MaNH = NH.MaNH
WHERE NH.TenNH = 'Ngan Hang Cong Thuong' AND CN.ThanhPhoCN = 'TP HCM';

--4.
SELECT NH.TenNH, CN.*
FROM NganHang NH JOIN ChiNhanh CN ON NH.MaNH = CN.MaNH;

--5.
SELECT * FROM KhachHang WHERE DiaChi LIKE '%Ha Noi%';

--6.
SELECT * FROM KhachHang WHERE TenKH LIKE '%Son%';

--7.
SELECT * FROM KhachHang WHERE DiaChi LIKE '%Tran Hung Dao%';

--8.
SELECT * FROM KhachHang WHERE TenKH LIKE '%Thao%';

--9.
SELECT * FROM KhachHang
WHERE MaKH LIKE '11%' AND DiaChi LIKE '%TP HCM%';

--10.
SELECT NH.TenNH, CN.ThanhPhoCN, CN.TaiSan
FROM NganHang NH JOIN ChiNhanh CN ON NH.MaNH = CN.MaNH
ORDER BY CN.TaiSan, CN.ThanhPhoCN;

--11.
SELECT *
FROM NganHang NH JOIN ChiNhanh CN ON NH.MaNH = CN.MaNH
WHERE CN.TaiSan BETWEEN 3000000000 AND 5000000000;

--12.
SELECT MaNH, AVG(TaiSan) FROM ChiNhanh GROUP BY MaNH;

--13.
SELECT KH.*
FROM KhachHang KH
JOIN TaiKhoanVay V ON KH.MaKH = V.MaKH
JOIN ChiNhanh CN ON V.MaCN = CN.MaCN
JOIN NganHang NH ON CN.MaNH = NH.MaNH
WHERE NH.TenNH='Ngan Hang Cong Thuong' AND KH.TenKH LIKE '%Thao%';

--14.
SELECT NH.TenNH, SUM(CN.TaiSan)
FROM NganHang NH JOIN ChiNhanh CN ON NH.MaNH = CN.MaNH
GROUP BY NH.TenNH;

--15.
SELECT MaCN, TaiSan FROM ChiNhanh
WHERE TaiSan = (SELECT MAX(TaiSan) FROM ChiNhanh);

--16.
SELECT DISTINCT KH.* FROM KhachHang KH
JOIN TaiKhoanGoi G ON KH.MaKH = G.MaKH
JOIN ChiNhanh CN ON G.MaCN = CN.MaCN
JOIN NganHang NH ON CN.MaNH = NH.MaNH
WHERE NH.TenNH='Ngan Hang A Chau';

--17
SELECT V.SoTKV FROM TaiKhoanVay V
JOIN ChiNhanh CN ON V.MaCN = CN.MaCN
JOIN NganHang NH ON CN.MaNH = NH.MaNH
WHERE NH.TenNH='Ngan Hang Ngoai Thuong' AND V.SoTienVay > 1200000;

--18.
SELECT MaCN, SUM(SoTienGoi) FROM TaiKhoanGoi
GROUP BY MaCN;

--19.
SELECT KH.TenKH, V.SoTKV, G.SoTKG FROM KhachHang KH
LEFT JOIN TaiKhoanVay V ON KH.MaKH = V.MaKH
LEFT JOIN TaiKhoanGoi G ON KH.MaKH = G.MaKH
WHERE KH.TenKH LIKE '%Son%';

--20.
SELECT KH.* FROM KhachHang KH
JOIN TaiKhoanVay V ON KH.MaKH = V.MaKH
GROUP BY KH.MaKH, KH.TenKH, KH.DiaChi
HAVING SUM(V.SoTienVay) > 30000000;

