SHOW user;
-------------------------------Tạo bảng-----------------------------------------
CREATE TABLE s_region (
    id NUMBER PRIMARY KEY,
    name VARCHAR2(50)
);

CREATE TABLE s_warehouse (
    id NUMBER PRIMARY KEY,
    region_id NUMBER,
    address VARCHAR2(100),
    city VARCHAR2(50),
    state VARCHAR2(50),
    country VARCHAR2(50),
    zip_code VARCHAR2(10),
    phone VARCHAR2(20),
    manager_id NUMBER
);

CREATE TABLE s_title (
    title VARCHAR2(50) PRIMARY KEY
);

CREATE TABLE s_dept (
    id NUMBER PRIMARY KEY,
    name VARCHAR2(50),
    region_id NUMBER
);

CREATE TABLE s_emp (
    id NUMBER PRIMARY KEY,
    last_name VARCHAR2(50),
    first_name VARCHAR2(50),
    userid VARCHAR2(20),
    start_date DATE,
    comments VARCHAR2(100),
    manager_id NUMBER,
    title VARCHAR2(50),
    dept_id NUMBER,
    salary NUMBER,
    commission_pct NUMBER
);

CREATE TABLE s_customer (
    id NUMBER PRIMARY KEY,
    name VARCHAR2(100),
    phone VARCHAR2(20),
    address VARCHAR2(100),
    city VARCHAR2(50),
    state VARCHAR2(50),
    country VARCHAR2(50),
    zip_code VARCHAR2(10),
    credit_rating VARCHAR2(10),
    sales_rep_id NUMBER,
    region_id NUMBER,
    comments VARCHAR2(100)
);

CREATE TABLE s_product (
    id NUMBER PRIMARY KEY,
    name VARCHAR2(100),
    short_desc VARCHAR2(200),
    suggested_whlsl_price NUMBER
);

CREATE TABLE s_ord (
    id NUMBER PRIMARY KEY,
    customer_id NUMBER,
    date_ordered DATE,
    total NUMBER
);

CREATE TABLE s_item (
    ord_id NUMBER,
    item_id NUMBER,
    product_id NUMBER,
    price NUMBER,
    quantity NUMBER,
    PRIMARY KEY (ord_id, item_id)
);

CREATE TABLE s_image (
    id NUMBER PRIMARY KEY,
    format VARCHAR2(20),
    use_filename VARCHAR2(10),
    filename VARCHAR2(100),
    image BLOB
);

CREATE TABLE s_longtext (
    id NUMBER PRIMARY KEY,
    use_filename VARCHAR2(10),
    filename VARCHAR2(100),
    text CLOB
);

CREATE TABLE s_inventory (
    product_id NUMBER,
    warehouse_id NUMBER,
    amount_in_stock NUMBER,
    reorder_point NUMBER,
    max_in_stock NUMBER,
    out_of_stock_explanation VARCHAR2(100),
    restock_date DATE,
    PRIMARY KEY (product_id, warehouse_id)
);

ALTER TABLE s_dept
ADD CONSTRAINT fk_dept_region
FOREIGN KEY (region_id) REFERENCES s_region(id);

ALTER TABLE s_emp
ADD CONSTRAINT fk_emp_dept
FOREIGN KEY (dept_id) REFERENCES s_dept(id);
ALTER TABLE s_emp
ADD CONSTRAINT fk_emp_manager
FOREIGN KEY (manager_id) REFERENCES s_emp(id);

ALTER TABLE s_customer
ADD CONSTRAINT fk_customer_region
FOREIGN KEY (region_id) REFERENCES s_region(id);

ALTER TABLE s_ord
ADD CONSTRAINT fk_ord_customer
FOREIGN KEY (customer_id) REFERENCES s_customer(id);

ALTER TABLE s_item
ADD CONSTRAINT fk_item_ord
FOREIGN KEY (ord_id) REFERENCES s_ord(id);
ALTER TABLE s_item
ADD CONSTRAINT fk_item_product
FOREIGN KEY (product_id) REFERENCES s_product(id);

SELECT table_name 
FROM user_tables;

desc s_region;

-----------------------------Insert dữ liệu ------------------------------------
INSERT INTO s_region VALUES (1, 'Vietnam');
INSERT INTO s_region VALUES (2, 'Thailand');
INSERT INTO s_region VALUES (3, 'Singapore');
INSERT INTO s_region VALUES (4, 'Malaysia');
INSERT INTO s_region VALUES (5, 'Indonesia');
INSERT INTO s_region VALUES (6, 'Philippines');
INSERT INTO s_region VALUES (7, 'China');
INSERT INTO s_region VALUES (8, 'Japan');
INSERT INTO s_region VALUES (9, 'South Korea');
INSERT INTO s_region VALUES (10, 'India');
INSERT INTO s_region VALUES (11, 'USA');
INSERT INTO s_region VALUES (12, 'Canada');
INSERT INTO s_region VALUES (13, 'Brazil');
INSERT INTO s_region VALUES (14, 'Argentina');
INSERT INTO s_region VALUES (15, 'UK');
INSERT INTO s_region VALUES (16, 'France');
INSERT INTO s_region VALUES (17, 'Germany');
INSERT INTO s_region VALUES (18, 'Italy');
INSERT INTO s_region VALUES (19, 'Australia');
INSERT INTO s_region VALUES (20, 'New Zealand');

BEGIN
    INSERT INTO s_warehouse VALUES (1, 3, 'Q1', 'HCM', 'HCM', 'Vietnam', '70000', '0901111111', 1);
    INSERT INTO s_warehouse VALUES (2, 2, 'Đà Nẵng', 'Đà Nẵng', 'DN', 'Vietnam', '55000', '0902222222', 2);
    INSERT INTO s_warehouse VALUES (3, 1, 'Hà Nội', 'Hà Nội', 'HN', 'Vietnam', '10000', '0903333333', 3);
END;
/

BEGIN
    INSERT INTO s_title VALUES ('Manager');
    INSERT INTO s_title VALUES ('Staff');
    INSERT INTO s_title VALUES ('HR');
    INSERT INTO s_title VALUES ('Sales');
END;
/

BEGIN
    INSERT INTO s_dept VALUES (1, 'Kinh doanh', 1);
    INSERT INTO s_dept VALUES (2, 'Marketing', 2);
    INSERT INTO s_dept VALUES (3, 'Nhân sự', 3);
    INSERT INTO s_dept VALUES (4, 'Kế toán', 1);
    INSERT INTO s_dept VALUES (5, 'IT', 2);
    INSERT INTO s_dept VALUES (10, 'Sales 10', 1);
    INSERT INTO s_dept VALUES (50, 'Sales 50', 2);
    INSERT INTO s_dept VALUES (31, 'Dept 31', 1);
    INSERT INTO s_dept VALUES (42, 'Dept 42', 2);
END;
/


BEGIN
    INSERT INTO s_emp VALUES (1, 'Nguyen', 'An', 'an.nguyen', DATE '1995-03-10', NULL, NULL, 'Manager', 1, 15000000, 0.2);
    INSERT INTO s_emp VALUES (2, 'Tran', 'Binh', 'binh.tran', DATE '1993-07-21', NULL, 1, 'Staff', 1, 12000000, 0.1);
    INSERT INTO s_emp VALUES (3, 'Le', 'Chi', 'chi.le', DATE '1996-11-05', NULL, 1, 'Staff', 2, 11000000, 0.1);
    INSERT INTO s_emp VALUES (4, 'Pham', 'Dung', 'dung.pham', DATE '1992-01-15', NULL, NULL, 'Manager', 3, 16000000, 0.25);
    INSERT INTO s_emp VALUES (5, 'Hoang', 'Em', 'em.hoang', DATE '1998-09-09', NULL, 4, 'Staff', 3, 10000000, 0.1);
END;
/
    INSERT INTO s_emp VALUES (10, 'Smith', 'John', 'john.smith',
    TO_DATE('15/05/1990','DD/MM/YYYY'), NULL, NULL, 'Manager', 10, 1500, 0.1);
    INSERT INTO s_emp VALUES (11, 'Tran', 'Lan', 'lan.tran',
    TO_DATE('10/03/1991','DD/MM/YYYY'), NULL, 10, 'Staff', 50, 1800, 0.1);
    INSERT INTO s_emp VALUES (12, 'Le', 'Son', 'son.le',
    TO_DATE('01/01/1992','DD/MM/YYYY'), NULL, 10, 'Staff', 31, 2000, 0.1);
    INSERT INTO s_emp VALUES (13, 'Pham', 'Sang', 'sang.pham',
    TO_DATE('01/01/1993','DD/MM/YYYY'), NULL, 10, 'Staff', 42, 1400, 0.1);
    
SELECT *FROM s_emp;

BEGIN
    INSERT INTO s_customer VALUES (1, 'Nguyen Van Luong', '0901234567', 'Q1', 'HCM', 'VN', 'Vietnam', '70000', 'VIP', 1, 1, NULL);
    INSERT INTO s_customer VALUES (2, 'Tran Thi Bich Tuyen', '0902345678', 'Q3', 'HCM', 'VN', 'Vietnam', '70000', 'GOOD', 2, 2, NULL);
    INSERT INTO s_customer VALUES (3, 'Le Van Cuong', '0903456789', 'Thu Duc', 'HCM', 'VN', 'Vietnam', '70000', 'NORMAL', 3, 1, NULL);
    INSERT INTO s_customer VALUES (4, 'Pham Thi Doan', '0904567890', 'Q7', 'HCM', 'VN', 'Vietnam', '70000', 'VIP', 1, 3, NULL);
    INSERT INTO s_customer VALUES (10, 'Pro Customer', '0909999999', 'Q1', 'HCM', 'VN', 'Vietnam', '70000', 'VIP', 10, 1, NULL);
END;
/

BEGIN
    INSERT INTO s_product VALUES (1, 'Xe đạp thể thao', 'Xe đạp địa hình cao cấp', 5000000);
    INSERT INTO s_product VALUES (2, 'Ván trượt tuyết', 'Dùng cho thể thao mùa đông', 3000000);
    INSERT INTO s_product VALUES (3, 'Giày chạy bộ', 'Giày Nike chính hãng', 2000000);
    INSERT INTO s_product VALUES (4, 'Áo thể thao', 'Áo thun co giãn', 500000);
    INSERT INTO s_product VALUES (5, 'Balo du lịch', 'Chống nước', 800000);
    INSERT INTO s_product VALUES (10, 'Pro Bike X', 'High quality bicycle', 5000);
    INSERT INTO s_product VALUES (11, 'Pro Shoes', 'Sport shoes', 2000);
    INSERT INTO s_product VALUES (12, 'Mountain Bike', 'This bicycle is strong', 6000);
END;
/

BEGIN
    INSERT INTO s_ord VALUES (1, 1, SYSDATE-5, 5500000);
    INSERT INTO s_ord VALUES (2, 2, SYSDATE-3, 3000000);
    INSERT INTO s_ord VALUES (3, 3, SYSDATE-2, 2000000);
    INSERT INTO s_ord VALUES (4, 1, SYSDATE-1, 800000);
END;
/

BEGIN
    INSERT INTO s_item VALUES (1, 1, 1, 5000000, 1);
    INSERT INTO s_item VALUES (2, 2, 2, 3000000, 1);
    INSERT INTO s_item VALUES (3, 3, 3, 2000000, 1);
    INSERT INTO s_item VALUES (4, 4, 5, 800000, 1);
END;
/

BEGIN
    INSERT INTO s_image VALUES (1, 'jpg', 'YES', 'bike.jpg', EMPTY_BLOB());
    INSERT INTO s_image VALUES (2, 'png', 'YES', 'ski.png', EMPTY_BLOB());
    INSERT INTO s_image VALUES (3, 'jpg', 'YES', 'shoes.jpg', EMPTY_BLOB());
END;
/

BEGIN
    INSERT INTO s_longtext VALUES (1, 'YES', 'bike.txt', 'Xe đạp phù hợp leo núi và đường dài');
    INSERT INTO s_longtext VALUES (2, 'YES', 'ski.txt', 'Ván trượt chuyên nghiệp');
END;
/

BEGIN
    INSERT INTO s_inventory VALUES (1, 1, 50, 10, 200, NULL, SYSDATE+30);
    INSERT INTO s_inventory VALUES (2, 2, 20, 5, 100, NULL, SYSDATE+20);
    INSERT INTO s_inventory VALUES (3, 3, 100, 20, 300, NULL, SYSDATE+40);
    INSERT INTO s_inventory VALUES (4, 4, 200, 50, 500, NULL, SYSDATE+60);
    INSERT INTO s_inventory VALUES (5, 5, 10, 5, 50, 'Sắp hết hàng', SYSDATE+10);
END;
/

COMMIT;
-----------------------------------BÀI 2----------------------------------------
--1
SELECT name AS "Ten khach hang", id AS "Ma khach hang"
FROM s_customer
ORDER BY id DESC;

--2
SELECT first_name || ' ' || last_name AS "Employees", dept_id
FROM s_emp
WHERE dept_id IN (10,50)
ORDER BY first_name;

--3
SELECT last_name, first_name
FROM s_emp
WHERE first_name LIKE '%S%' OR last_name LIKE '%S%';

--4
SELECT userid, start_date
FROM s_emp
WHERE start_date BETWEEN TO_DATE('14/05/1990','DD/MM/YYYY')
AND TO_DATE('26/05/1991','DD/MM/YYYY');

--5
SELECT last_name, salary
FROM s_emp
WHERE salary BETWEEN 1000 AND 2000;

--6
SELECT last_name || ' ' || first_name AS "Employee Name",
salary AS "Monthly Salary"
FROM s_emp
WHERE dept_id IN (31,42,50)
AND salary > 1350;

--7
SELECT last_name, start_date
FROM s_emp
WHERE TO_CHAR(start_date,'YYYY')='1991';

--8
SELECT last_name, first_name
FROM s_emp
WHERE id NOT IN (
    SELECT manager_id FROM s_emp WHERE manager_id IS NOT NULL
);

--9
SELECT name
FROM s_product
WHERE name LIKE 'Pro%'
ORDER BY name;

--10
SELECT name, short_desc
FROM s_product
WHERE LOWER(short_desc) LIKE '%bicycle%';

--11
SELECT short_desc FROM s_product;

--12
SELECT last_name || ' ' || first_name || ' (' || title || ')' AS "Nhan vien"
FROM s_emp;

-----------------------------------BÀI 3----------------------------------------
--1
SELECT id, last_name, ROUND(salary*1.15,2) AS "Luong moi"
FROM s_emp;

--2
SELECT last_name, start_date,
TO_CHAR(NEXT_DAY(ADD_MONTHS(start_date,6),'MONDAY'),
'Ddspth "of" Month YYYY') AS "Ngay tang luong"
FROM s_emp;

--3
SELECT name FROM s_product WHERE LOWER(name) LIKE '%ski%';

--4
SELECT last_name,
ROUND(MONTHS_BETWEEN(SYSDATE,start_date))
FROM s_emp
ORDER BY 2;

--5
SELECT COUNT(DISTINCT manager_id)
FROM s_emp WHERE manager_id IS NOT NULL;

--6
SELECT MAX(total) AS "Highest", MIN(total) AS "Lowest"
FROM s_ord;

-----------------------------------BÀI 4----------------------------------------
--1
SELECT p.name, p.id, i.quantity AS "ORDERED"
FROM s_product p, s_item i
WHERE p.id = i.product_id
AND i.ord_id = 101;

--2
SELECT c.id, o.id
FROM s_customer c LEFT JOIN s_ord o
ON c.id = o.customer_id
ORDER BY c.id;

--3
SELECT o.customer_id, i.product_id, i.quantity
FROM s_ord o, s_item i
WHERE o.id = i.ord_id
AND o.total > 100000;

-----------------------------------BÀI 5----------------------------------------
--1
SELECT manager_id AS "Ma quan ly",
       COUNT(id) AS "So nhan vien"
FROM s_emp
WHERE manager_id IS NOT NULL
GROUP BY manager_id
ORDER BY manager_id;

--2
SELECT manager_id AS "Ma quan ly",
       COUNT(id) AS "So nhan vien"
FROM s_emp
WHERE manager_id IS NOT NULL
GROUP BY manager_id
HAVING COUNT(id) >= 20;

--3
SELECT r.id AS "Ma vung",
       r.name AS "Ten vung",
       COUNT(d.id) AS "So phong ban"
FROM s_region r, s_dept d
WHERE r.id = d.region_id
GROUP BY r.id, r.name
ORDER BY r.id;

--4
SELECT c.name AS "Ten khach hang",
       COUNT(o.id) AS "So don dat hang"
FROM s_customer c, s_ord o
WHERE c.id = o.customer_id
GROUP BY c.id, c.name
ORDER BY c.name;

--5
SELECT c.name,
       COUNT(o.id) AS "So don hang"
FROM s_customer c, s_ord o
WHERE c.id = o.customer_id
GROUP BY c.id, c.name
HAVING COUNT(o.id) = (
    SELECT MAX(COUNT(id))
    FROM s_ord
    GROUP BY customer_id
);

--6
SELECT c.name,
       SUM(o.total) AS "Tong tien"
FROM s_customer c, s_ord o
WHERE c.id = o.customer_id
GROUP BY c.id, c.name
HAVING SUM(o.total) = (
    SELECT MAX(tong)
    FROM (
        SELECT SUM(total) AS tong
        FROM s_ord
        GROUP BY customer_id
    )
);

-----------------------------------BÀI 6----------------------------------------
--1
SELECT last_name, first_name, start_date
FROM s_emp
WHERE dept_id IN (
    SELECT dept_id
    FROM s_emp
    WHERE first_name = 'Lan'
)
AND first_name != 'Lan';

--2
SELECT id, last_name, first_name, userid
FROM s_emp
WHERE salary > (
    SELECT AVG(salary)
    FROM s_emp
);

--3
SELECT id, last_name, first_name
FROM s_emp
WHERE salary > (
    SELECT AVG(salary)
    FROM s_emp
)
AND (
    UPPER(first_name) LIKE '%L%' 
    OR UPPER(last_name) LIKE '%L%'
);

--4
SELECT c.name
FROM s_customer c
WHERE NOT EXISTS (
    SELECT 1
    FROM s_ord o
    WHERE o.customer_id = c.id
);