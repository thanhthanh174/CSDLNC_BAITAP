show user;

ALTER TABLE MONHOC
ADD MaMonTienQuyet NUMBER;

ALTER TABLE MONHOC
ADD CONSTRAINT fk_monhoc_tienquyet
FOREIGN KEY (MaMonTienQuyet)
REFERENCES MONHOC(MaMon);

ALTER TRIGGER TRG_UPDATE_GRADE_SUMMARY DISABLE;

DESC DIEM;

--thêm môn tiên quyết
INSERT INTO MONHOC (MaMon, TenMon, MaMonTienQuyet)
VALUES (1, 'Co so du lieu', NULL);

INSERT INTO MONHOC (MaMon, TenMon, MaMonTienQuyet)
VALUES (2, 'CSDL nang cao', 1);

--thêm SV
INSERT INTO SINHVIEN (MaSV, HO, TEN, NGAYDANGKY)
VALUES (120, 'Nguyen', 'An', SYSDATE);

--thêm GV
INSERT INTO GIAOVIEN (MaGV, HO, TEN)
VALUES (20, 'Tran', 'Binh');

--thêm lớp học
INSERT INTO LOPHOC (MaLop, MaMon, MaGV)
VALUES (201, 2, 1);

--SV đăng ký học môn nâng cao
INSERT INTO DANGKY (MaSV, MaLop, NGAYDANGKY)
VALUES (120, 201, SYSDATE);

----------------------------------BÀI 1-----------------------------------------
--1.1
CREATE OR REPLACE VIEW vw_kiemtra_hocvuot AS
SELECT 
    sv.MaSV AS ma_sinh_vien,
    sv.HO || ' ' || sv.TEN AS ho_ten,
    mh.TenMon AS ten_mon_hoc,
    mh.MaMon AS ma_mon_hoc,
    tq.TenMon AS ten_mon_tien_quyet,
    tq.MaMon AS ma_mon_tien_quyet
FROM DANGKY dk
JOIN SINHVIEN sv
    ON dk.MaSV = sv.MaSV
JOIN LOPHOC lh
    ON dk.MaLop = lh.MaLop
JOIN MONHOC mh
    ON lh.MaMon = mh.MaMon
JOIN MONHOC tq
    ON mh.MaMonTienQuyet = tq.MaMon
WHERE mh.MaMonTienQuyet IS NOT NULL
AND NOT EXISTS (
    SELECT 1
    FROM DIEM d
    JOIN LOPHOC lh2
        ON d.MaLop = lh2.MaLop
    WHERE d.MaSV = sv.MaSV
    AND lh2.MaMon = mh.MaMonTienQuyet
    AND d.DIEM IS NOT NULL
);

SELECT * FROM vw_kiemtra_hocvuot;

--đếm số sinh viên học vượt theo từng môn
SELECT 
    ten_mon_hoc,
    ma_mon_hoc,
    COUNT(*) AS so_sv_hoc_vuot
FROM vw_kiemtra_hocvuot
GROUP BY ten_mon_hoc, ma_mon_hoc
ORDER BY so_sv_hoc_vuot DESC;

--1.2
CREATE OR REPLACE VIEW vw_hieusuat_giangday AS
SELECT 
    MaGV,
    ho_ten,
    so_lop,
    tong_sv,
    sv_co_diem,
    diem_tb,
    diem_max,
    diem_min,

    ROUND(
        sv_dat * 100 / NULLIF(sv_co_diem, 0),
        1
    ) AS ty_le_dat_pct,

    DENSE_RANK() OVER (
        ORDER BY diem_tb DESC NULLS LAST
    ) AS hang_diem_tb,

    RANK() OVER (
        ORDER BY tong_sv DESC
    ) AS hang_so_sv

FROM (
    SELECT 
        gv.MaGV,

        gv.HO || ' ' || gv.TEN AS ho_ten,

        COUNT(DISTINCT lh.MaLop) AS so_lop,

        COUNT(d.MaSV) AS tong_sv,

        COUNT(d.DIEM) AS sv_co_diem,

        ROUND(AVG(d.DIEM), 2) AS diem_tb,

        MAX(d.DIEM) AS diem_max,

        MIN(d.DIEM) AS diem_min,

        SUM(
            CASE
                WHEN d.DIEM >= 5
                THEN 1
                ELSE 0
            END
        ) AS sv_dat

    FROM GIAOVIEN gv

    LEFT JOIN LOPHOC lh
        ON gv.MaGV = lh.MaGV

    LEFT JOIN DIEM d
        ON lh.MaLop = d.MaLop

    GROUP BY 
        gv.MaGV,
        gv.HO,
        gv.TEN
);

--top 3 GV có điểm tb cao nhất
SELECT 
    ho_ten,
    ty_le_dat_pct,
    sv_co_diem,
    diem_tb
FROM vw_hieusuat_giangday
WHERE hang_diem_tb <= 3
ORDER BY hang_diem_tb;

--1.3
CREATE OR REPLACE VIEW vw_thongke_dangky_thang AS

SELECT 
    nam,
    thang,
    so_dang_ky,
    so_sv_moi,
    so_mon,
    diem_tb_thang,

    SUM(so_dang_ky) OVER (
        ORDER BY nam, thang
        ROWS BETWEEN UNBOUNDED PRECEDING 
        AND CURRENT ROW
    ) AS luy_ke_dang_ky

FROM (
    
    SELECT 
        
        TO_CHAR(dk.NGAYDANGKY, 'YYYY') AS nam,

        TO_CHAR(dk.NGAYDANGKY, 'MM') AS thang,

        COUNT(*) AS so_dang_ky,

        COUNT(DISTINCT dk.MaSV) AS so_sv_moi,

        COUNT(DISTINCT lh.MaMon) AS so_mon,

        ROUND(AVG(d.DIEM), 2) AS diem_tb_thang

    FROM DANGKY dk

    JOIN LOPHOC lh
        ON dk.MaLop = lh.MaLop

    LEFT JOIN DIEM d
        ON dk.MaSV = d.MaSV
        AND dk.MaLop = d.MaLop

    GROUP BY 
        TO_CHAR(dk.NGAYDANGKY, 'YYYY'),
        TO_CHAR(dk.NGAYDANGKY, 'MM')
)

ORDER BY nam DESC, thang ASC;

SELECT * FROM vw_thongke_dangky_thang;

--1.4
--Bước 1
CREATE OR REPLACE VIEW vw_dangky_full AS

SELECT 
    dk.MaSV,
    dk.MaLop,
    dk.NGAYDANGKY,

    sv.HO || ' ' || sv.TEN AS ten_sv,

    mh.TenMon AS ten_mon,

    gv.HO || ' ' || gv.TEN AS ten_gv

FROM DANGKY dk

JOIN SINHVIEN sv
    ON dk.MaSV = sv.MaSV

JOIN LOPHOC lh
    ON dk.MaLop = lh.MaLop

JOIN MONHOC mh
    ON lh.MaMon = mh.MaMon

JOIN GIAOVIEN gv
    ON lh.MaGV = gv.MaGV;
    
--Bước 2
CREATE OR REPLACE TRIGGER trg_iot_dangky_full

INSTEAD OF INSERT
ON vw_dangky_full

FOR EACH ROW

DECLARE

    v_sv_check NUMBER;

    v_lop_check NUMBER;

BEGIN

    --kt SV tồn tại

    SELECT COUNT(*)
    INTO v_sv_check
    FROM SINHVIEN
    WHERE MaSV = :NEW.MaSV;

    IF v_sv_check = 0 THEN
        RAISE_APPLICATION_ERROR(
            -20050,
            'Sinh vien khong ton tai!'
        );
    END IF;

    --kt lớp tồn tại

    SELECT COUNT(*)
    INTO v_lop_check
    FROM LOPHOC
    WHERE MaLop = :NEW.MaLop;

    IF v_lop_check = 0 THEN
        RAISE_APPLICATION_ERROR(
            -20051,
            'Lop hoc khong ton tai!'
        );
    END IF;

    --insert vào bảng thật

    INSERT INTO DANGKY (
        MaSV,
        MaLop,
        NGAYDANGKY,
        NGUOITAO,
        NGAYTAO,
        NGUOISUA,
        NGAYSUA
    )
    VALUES (
        :NEW.MaSV,
        :NEW.MaLop,
        NVL(:NEW.NGAYDANGKY, SYSDATE),
        USER,
        SYSDATE,
        USER,
        SYSDATE
    );

    DBMS_OUTPUT.PUT_LINE(
        '[OK] Da dang ky: SV '
        || :NEW.MaSV
        || ' -> Lop '
        || :NEW.MaLop
    );

END;
/

--kt insert 
INSERT INTO LOPHOC (
    MaLop,
    MaMon,
    MaGV
)
VALUES (
    202,
    2,
    1
);

INSERT INTO vw_dangky_full (
    MaSV,
    MaLop
)
VALUES (
    120,
    202
);

COMMIT;

SELECT * FROM DANGKY
WHERE MaSV = 120;

--1.5
CREATE OR REPLACE VIEW vw_phanbo_diem AS

SELECT 
    MaLop,
    MaMon,
    TenMon,

    sv_A,
    sv_B,
    sv_C,
    sv_D,
    sv_F,
    sv_chua_co,

    p25,
    p50_median,
    p75,

    ROUND(std_dev, 2) AS do_lech_chuan,

    ROUND(
        std_dev / NULLIF(diem_tb, 0) * 100,
        2
    ) AS he_so_bt

FROM (

    SELECT 
        lh.MaLop,

        mh.MaMon,

        mh.TenMon,

        SUM(
            CASE
                WHEN d.DIEM >= 9
                THEN 1
                ELSE 0
            END
        ) AS sv_A,

        SUM(
            CASE
                WHEN d.DIEM >= 8
                AND d.DIEM < 9
                THEN 1
                ELSE 0
            END
        ) AS sv_B,

        SUM(
            CASE
                WHEN d.DIEM >= 7
                AND d.DIEM < 8
                THEN 1
                ELSE 0
            END
        ) AS sv_C,

        SUM(
            CASE
                WHEN d.DIEM >= 5
                AND d.DIEM < 7
                THEN 1
                ELSE 0
            END
        ) AS sv_D,

        SUM(
            CASE
                WHEN d.DIEM < 5
                AND d.DIEM IS NOT NULL
                THEN 1
                ELSE 0
            END
        ) AS sv_F,

        SUM(
            CASE
                WHEN d.DIEM IS NULL
                THEN 1
                ELSE 0
            END
        ) AS sv_chua_co,

        PERCENTILE_CONT(0.25)
        WITHIN GROUP (ORDER BY d.DIEM) AS p25,

        PERCENTILE_CONT(0.50)
        WITHIN GROUP (ORDER BY d.DIEM) AS p50_median,

        PERCENTILE_CONT(0.75)
        WITHIN GROUP (ORDER BY d.DIEM) AS p75,

        STDDEV(d.DIEM) AS std_dev,

        AVG(d.DIEM) AS diem_tb

    FROM LOPHOC lh

    JOIN MONHOC mh
        ON lh.MaMon = mh.MaMon

    LEFT JOIN DIEM d
        ON lh.MaLop = d.MaLop

    GROUP BY 
        lh.MaLop,
        mh.MaMon,
        mh.TenMon

    HAVING COUNT(d.DIEM) >= 2
);

SELECT * FROM vw_phanbo_diem
ORDER BY MaLop;

--1.6
CREATE OR REPLACE VIEW vw_pivot_diem_sinhvien AS

SELECT 
    MaSV,

    ho_ten,

    MAX(
        CASE
            WHEN MaLop = 201
            THEN DIEM
        END
    ) AS diem_lop_201,

    MAX(
        CASE
            WHEN MaLop = 202
            THEN DIEM
        END
    ) AS diem_lop_202,

    MAX(
        CASE
            WHEN MaLop = 203
            THEN DIEM
        END
    ) AS diem_lop_203,

    MAX(
        CASE
            WHEN MaLop = 204
            THEN DIEM
        END
    ) AS diem_lop_204,

    ROUND(AVG(DIEM), 2) AS diem_tb_chung,

    COUNT(MaLop) AS tong_lop

FROM (

    SELECT 
        d.MaSV,

        sv.HO || ' ' || sv.TEN AS ho_ten,

        d.MaLop,

        d.DIEM

    FROM DIEM d

    JOIN SINHVIEN sv
        ON d.MaSV = sv.MaSV
)

GROUP BY 
    MaSV,
    ho_ten

ORDER BY MaSV;

SELECT * FROM vw_pivot_diem_sinhvien;

--1.7
CREATE OR REPLACE VIEW vw_kiemtra_toanven_dl AS

--lỗi 1: SV trong DANGKY ko tồn tại trong SINHVIEN
SELECT 
    'LOI_1: SV_KHONG_TON_TAI' AS loai_van_de,
    TO_CHAR(dk.MaSV) AS ma_tham_chieu,
    'MaSV ' || dk.MaSV || 
    ' có trong DANGKY nhưng không có trong SINHVIEN' AS mo_ta
FROM DANGKY dk
WHERE NOT EXISTS (
    SELECT 1
    FROM SINHVIEN sv
    WHERE sv.MaSV = dk.MaSV
)

UNION ALL

--lỗi 2: Lớp học thiếu GV
SELECT
    'LOI_2: LOP_THIEU_GIAOVIEN',
    TO_CHAR(lh.MaLop),
    'MaLop ' || lh.MaLop || 
    ' không có MaGV hợp lệ'
FROM LOPHOC lh
WHERE NOT EXISTS (
    SELECT 1
    FROM GIAOVIEN gv
    WHERE gv.MaGV = lh.MaGV
)

UNION ALL

--lỗi 3: Điểm ko hợp lệ (>10 hoặc <0)
SELECT
    'LOI_3: DIEM_KHONG_HOP_LE',
    TO_CHAR(d.MaSV) || '/' || TO_CHAR(d.MaLop),
    'Điểm = ' || d.DIEM || 
    ' không hợp lệ'
FROM DIEM d
WHERE d.DIEM > 10
   OR d.DIEM < 0

UNION ALL

--lỗi 4: SV đăng ký quá 3 lớp
SELECT
    'LOI_4: DANGKY_QUA_3_LOP',
    TO_CHAR(MaSV),
    'MaSV ' || MaSV || 
    ' đăng ký ' || COUNT(*) || ' lớp'
FROM DANGKY
GROUP BY MaSV
HAVING COUNT(*) > 3;

SELECT * FROM vw_kiemtra_toanven_dl;



----------------------------------BÀI 2-----------------------------------------
--2.1
CREATE OR REPLACE PROCEDURE get_students_by_class
(
    p_malop IN NUMBER,
    p_result OUT SYS_REFCURSOR
)

IS
    v_check NUMBER;

BEGIN

    --kt lớp tồn tại
    SELECT COUNT(*)
    INTO v_check
    FROM LOPHOC
    WHERE MaLop = p_malop;

    IF v_check = 0 THEN

        p_result := NULL;

        DBMS_OUTPUT.PUT_LINE(
            'Lớp ' || p_malop || ' không tồn tại!'
        );

        RETURN;

    END IF;

    --trả về cursor
    OPEN p_result FOR

    SELECT
        sv.MaSV,

        sv.HO || ' ' || sv.TEN AS ho_ten,

        d.DIEM,

        CASE

            WHEN d.DIEM >= 9 THEN 'A'

            WHEN d.DIEM >= 8 THEN 'B'

            WHEN d.DIEM >= 7 THEN 'C'

            WHEN d.DIEM >= 5 THEN 'D'

            WHEN d.DIEM IS NULL THEN 'Chua co'

            ELSE 'F'

        END AS xep_loai,

        RANK() OVER (
            ORDER BY d.DIEM DESC NULLS LAST
        ) AS thu_hang

    FROM DANGKY dk

    JOIN SINHVIEN sv
        ON dk.MaSV = sv.MaSV

    LEFT JOIN DIEM d
        ON dk.MaSV = d.MaSV
       AND dk.MaLop = d.MaLop

    WHERE dk.MaLop = p_malop

    ORDER BY thu_hang;

END get_students_by_class;
/

--in kết quả
CREATE OR REPLACE PROCEDURE print_class_result
(
    p_malop IN NUMBER
)

IS

    v_cur SYS_REFCURSOR;

    v_masv NUMBER;

    v_ten VARCHAR2(100);

    v_diem NUMBER;

    v_xep VARCHAR2(20);

    v_hang NUMBER;

BEGIN

    get_students_by_class(
        p_malop,
        v_cur
    );

    IF v_cur IS NULL THEN
        RETURN;
    END IF;

    DBMS_OUTPUT.PUT_LINE(
        '=== KET QUA LOP ' || p_malop || ' ==='
    );

    DBMS_OUTPUT.PUT_LINE(
        RPAD('Hang',6) ||
        RPAD('Ho Ten',25) ||
        RPAD('Diem',10) ||
        'Xep loai'
    );

    DBMS_OUTPUT.PUT_LINE(
        RPAD('-',55,'-')
    );

    LOOP

        FETCH v_cur
        INTO
            v_masv,
            v_ten,
            v_diem,
            v_xep,
            v_hang;

        EXIT WHEN v_cur%NOTFOUND;

        DBMS_OUTPUT.PUT_LINE(

            RPAD(v_hang,6) ||

            RPAD(v_ten,25) ||

            RPAD(
                NVL(TO_CHAR(v_diem), '--'),
                10
            ) ||

            v_xep
        );

    END LOOP;

    CLOSE v_cur;

END print_class_result;
/

--test
BEGIN

    print_class_result(102);

END;
/

--1.2
CREATE OR REPLACE PROCEDURE validate_enrollment
(
    p_masv IN NUMBER,
    p_malop IN NUMBER
)

IS

    --khai báo exception
    ex_sv_not_found EXCEPTION;
    PRAGMA EXCEPTION_INIT(ex_sv_not_found, -20101);

    ex_lop_not_found EXCEPTION;
    PRAGMA EXCEPTION_INIT(ex_lop_not_found, -20102);

    ex_lop_day EXCEPTION;
    PRAGMA EXCEPTION_INIT(ex_lop_day, -20103);

    ex_trung_dangky EXCEPTION;
    PRAGMA EXCEPTION_INIT(ex_trung_dangky, -20104);

    v_check NUMBER;

    v_soluong NUMBER;

BEGIN

    --kt SV tồn tại
    SELECT COUNT(*)
    INTO v_check
    FROM SINHVIEN
    WHERE MaSV = p_masv;

    IF v_check = 0 THEN

        RAISE_APPLICATION_ERROR(
            -20101,
            'Sinh viên ' || p_masv || ' không tồn tại!'
        );

    END IF;

    --kt lớp tồn tại
    SELECT COUNT(*)
    INTO v_check
    FROM LOPHOC
    WHERE MaLop = p_malop;

    IF v_check = 0 THEN

        RAISE_APPLICATION_ERROR(
            -20102,
            'Lớp ' || p_malop || ' không tồn tại!'
        );

    END IF;

    --kt số lượng SV trong lớp
    SELECT COUNT(*)
    INTO v_soluong
    FROM DANGKY
    WHERE MaLop = p_malop;

    IF v_soluong >= 3 THEN

        RAISE_APPLICATION_ERROR(
            -20103,
            'Lớp ' || p_malop || ' đã đầy!'
        );

    END IF;

    --kt trùng đăng ký
    SELECT COUNT(*)
    INTO v_check
    FROM DANGKY
    WHERE MaSV = p_masv
      AND MaLop = p_malop;

    IF v_check > 0 THEN

        RAISE_APPLICATION_ERROR(
            -20104,
            'Sinh viên đã đăng ký lớp này rồi!'
        );

    END IF;

    DBMS_OUTPUT.PUT_LINE(
        '[OK] Tất cả điều kiện đều hợp lệ!'
    );

EXCEPTION

    WHEN ex_sv_not_found THEN

        DBMS_OUTPUT.PUT_LINE(
            '[KHONG TON TAI] ' || SQLERRM
        );

    WHEN ex_lop_not_found THEN

        DBMS_OUTPUT.PUT_LINE(
            '[LOP SAI] ' || SQLERRM
        );

    WHEN ex_lop_day THEN

        DBMS_OUTPUT.PUT_LINE(
            '[DAY LOP] ' || SQLERRM
        );

    WHEN ex_trung_dangky THEN

        DBMS_OUTPUT.PUT_LINE(
            '[TRUNG LAP] ' || SQLERRM
        );

    WHEN OTHERS THEN

        DBMS_OUTPUT.PUT_LINE(
            '[LOI KHAC] ' || SQLERRM
        );

END validate_enrollment;
/

--test
BEGIN

    validate_enrollment(120, 201);

END;
/

--2.3
CREATE OR REPLACE PROCEDURE calc_total_prerequisite_cost
(
    p_mamon IN NUMBER,

    p_total OUT NUMBER,

    p_depth IN NUMBER DEFAULT 0
)

IS

    v_hocphi NUMBER;

    v_mon_tq NUMBER;

    v_tenmon VARCHAR2(100);

    v_sub_total NUMBER := 0;

    v_indent VARCHAR2(50);

BEGIN

    --giới hạn độ sâu đệ quy
    IF p_depth >= 10 THEN

        DBMS_OUTPUT.PUT_LINE(
            'CANH BAO: Dat gioi han do sau!'
        );

        p_total := 0;

        RETURN;

    END IF;

    --lấy thông tin môn học
    BEGIN

        SELECT 
            HocPhi,
            MaMonTienQuyet,
            TenMon

        INTO
            v_hocphi,
            v_mon_tq,
            v_tenmon

        FROM MONHOC

        WHERE MaMon = p_mamon;

    EXCEPTION

        WHEN NO_DATA_FOUND THEN

            p_total := 0;

            RETURN;

    END;

    --thụt đầu dòng để in đẹp
    v_indent := LPAD(' ', p_depth * 4);

    --nếu có môn tiên quyết thì gọi đệ quy
    IF v_mon_tq IS NOT NULL THEN

        calc_total_prerequisite_cost(
            v_mon_tq,
            v_sub_total,
            p_depth + 1
        );

    END IF;

    --tổng học phí
    p_total := NVL(v_hocphi, 0) + v_sub_total;

    DBMS_OUTPUT.PUT_LINE(

        v_indent ||

        'Cap ' || p_depth ||

        ': Mon ' || p_mamon ||

        ' - ' || v_tenmon ||

        ' (Hoc phi: ' || NVL(v_hocphi,0) || ')'
    );

END calc_total_prerequisite_cost;
/

--test
DECLARE

    v_total NUMBER;

BEGIN

    calc_total_prerequisite_cost(
        2,
        v_total
    );

    DBMS_OUTPUT.PUT_LINE(
        'Tong hoc phi can hoc: ' || v_total
    );

END;
/

--2.4
CREATE OR REPLACE PACKAGE pkg_student_mgmt AS

    --hằng số
    c_max_classes CONSTANT NUMBER := 3;

    --procedure đăng ký lớp
    PROCEDURE enroll
    (
        p_masv NUMBER,
        p_malop NUMBER
    );

    --procedure hủy đăng ký
    PROCEDURE withdraw
    (
        p_masv NUMBER,
        p_malop NUMBER
    );

    --hàm tính điểm tb
    FUNCTION get_student_gpa
    (
        p_masv NUMBER
    )
    RETURN NUMBER;

    --procedure in bảng điểm
    PROCEDURE print_transcript
    (
        p_masv NUMBER
    );

    --hàm đếm số lớp đã đăng ký
    FUNCTION count_enrolled
    (
        p_masv NUMBER
    )
    RETURN NUMBER;

END pkg_student_mgmt;
/

-- PACKAGE BODY
CREATE OR REPLACE PACKAGE BODY pkg_student_mgmt AS

    --biến nội bộ package
    g_call_count NUMBER := 0;
    
    --hàm đếm số lớp đã đăng ký
    FUNCTION count_enrolled
    (
        p_masv NUMBER
    )
    RETURN NUMBER

    IS

        v_cnt NUMBER;

    BEGIN

        SELECT COUNT(*)
        INTO v_cnt
        FROM DANGKY
        WHERE MaSV = p_masv;

        RETURN v_cnt;

    END;

    --procedure đăng ký lớp
    PROCEDURE enroll
    (
        p_masv NUMBER,
        p_malop NUMBER
    )

    IS

        v_check NUMBER;

        v_soluong NUMBER;

    BEGIN

        g_call_count := g_call_count + 1;

        --kt SV
        SELECT COUNT(*)
        INTO v_check
        FROM SINHVIEN
        WHERE MaSV = p_masv;

        IF v_check = 0 THEN

            DBMS_OUTPUT.PUT_LINE(
                '[LOI] Sinh viên không tồn tại'
            );

            RETURN;

        END IF;

        --kt lớp học
        SELECT COUNT(*)
        INTO v_check
        FROM LOPHOC
        WHERE MaLop = p_malop;

        IF v_check = 0 THEN

            DBMS_OUTPUT.PUT_LINE(
                '[LOI] Lớp học không tồn tại'
            );

            RETURN;

        END IF;

        --kt số lớp tối đa
        IF count_enrolled(p_masv) >= c_max_classes THEN

            DBMS_OUTPUT.PUT_LINE(
                '[LOI] Sinh viên đã đủ '
                || c_max_classes || ' lớp'
            );

            RETURN;

        END IF;

        --kt lớp đầy
        SELECT COUNT(*)
        INTO v_soluong
        FROM DANGKY
        WHERE MaLop = p_malop;

        IF v_soluong >= 3 THEN

            DBMS_OUTPUT.PUT_LINE(
                '[LOI] Lớp đã đầy'
            );

            RETURN;

        END IF;

        --thêm đăng ký
        INSERT INTO DANGKY
        (
            MaSV,
            MaLop,
            NgayDangKy
        )
        VALUES
        (
            p_masv,
            p_malop,
            SYSDATE
        );

        COMMIT;

        DBMS_OUTPUT.PUT_LINE(
            '[OK] Đăng ký thành công: SV '
            || p_masv ||
            ' -> Lớp ' || p_malop
        );

    END enroll;

    --procedure hủy đăng ký
    PROCEDURE withdraw
    (
        p_masv NUMBER,
        p_malop NUMBER
    )

    IS

        v_check NUMBER;

    BEGIN

        SELECT COUNT(*)
        INTO v_check
        FROM DANGKY
        WHERE MaSV = p_masv
          AND MaLop = p_malop;

        IF v_check = 0 THEN

            DBMS_OUTPUT.PUT_LINE(
                '[LOI] Sinh viên chưa đăng ký lớp này'
            );

            RETURN;

        END IF;

        DELETE FROM DANGKY
        WHERE MaSV = p_masv
          AND MaLop = p_malop;

        COMMIT;

        DBMS_OUTPUT.PUT_LINE(
            '[OK] Đã hủy đăng ký lớp'
        );

    END withdraw;

    --hàm tính GPA
    FUNCTION get_student_gpa
    (
        p_masv NUMBER
    )

    RETURN NUMBER

    IS

        v_gpa NUMBER;

    BEGIN

        SELECT ROUND(AVG(DIEM),2)
        INTO v_gpa
        FROM DIEM
        WHERE MaSV = p_masv;

        RETURN v_gpa;

    END;

    --procedure in bảng điểm
    PROCEDURE print_transcript
    (
        p_masv NUMBER
    )

    IS

    BEGIN

        DBMS_OUTPUT.PUT_LINE(
            '=== BANG DIEM SINH VIEN '
            || p_masv || ' ==='
        );

        FOR rec IN
        (

            SELECT
                mh.MaMon,
                mh.TenMon,
                d.DIEM

            FROM DIEM d

            JOIN LOPHOC lh
                ON d.MaLop = lh.MaLop

            JOIN MONHOC mh
                ON lh.MaMon = mh.MaMon

            WHERE d.MaSV = p_masv

            ORDER BY mh.MaMon

        )

        LOOP

            DBMS_OUTPUT.PUT_LINE(

                rec.MaMon || ' - ' ||

                RPAD(rec.TenMon,25) ||

                ' : ' ||

                NVL(
                    TO_CHAR(rec.DIEM),
                    'Chua co diem'
                )

            );

        END LOOP;

        DBMS_OUTPUT.PUT_LINE(

            'GPA: ' ||

            NVL(
                TO_CHAR(get_student_gpa(p_masv)),
                'N/A'
            )

        );

    END;

END pkg_student_mgmt;
/

--test
BEGIN
    pkg_student_mgmt.enroll(120, 220);
END;
/

--2.5
CREATE OR REPLACE PROCEDURE bulk_update_diem IS

    TYPE t_num IS TABLE OF NUMBER INDEX BY PLS_INTEGER;

    v_masv      t_num;
    v_malop     t_num;
    v_diem      t_num;

    v_start NUMBER;
    v_end   NUMBER;
    v_rows  NUMBER := 0;

BEGIN

    v_start := DBMS_UTILITY.GET_TIME;

    --đọc dữ liệu vào mảng
    SELECT 
        MaSV,
        MaLop,
        DIEM
    BULK COLLECT INTO 
        v_masv,
        v_malop,
        v_diem
    FROM DIEM
    WHERE DIEM IS NOT NULL;

    DBMS_OUTPUT.PUT_LINE(
        'Doc duoc ' || v_masv.COUNT || ' ban ghi...'
    );

    --update hàng loạt
    FORALL i IN 1 .. v_masv.COUNT SAVE EXCEPTIONS

        UPDATE DIEM
        SET 
            DIEM = v_diem(i),
            NgaySua = SYSDATE
        WHERE MaSV = v_masv(i)
        AND MaLop = v_malop(i);

    v_rows := SQL%ROWCOUNT;

    COMMIT;

    v_end := DBMS_UTILITY.GET_TIME;

    DBMS_OUTPUT.PUT_LINE(
        'Xu ly: ' || v_rows ||
        ' hang | Thoi gian: ' ||
        ROUND((v_end - v_start)/100,2) ||
        ' giay'
    );

EXCEPTION
    WHEN OTHERS THEN

        FOR j IN 1 .. SQL%BULK_EXCEPTIONS.COUNT LOOP

            DBMS_OUTPUT.PUT_LINE(
                'Loi hang ' ||
                SQL%BULK_EXCEPTIONS(j).ERROR_INDEX ||
                ': ' ||
                SQLERRM(
                    -SQL%BULK_EXCEPTIONS(j).ERROR_CODE
                )
            );

        END LOOP;

        ROLLBACK;

END bulk_update_diem;
/

--test
BEGIN
    bulk_update_diem;
END;
/

--2.6
CREATE OR REPLACE PROCEDURE generate_course_report
(
    p_mamon IN NUMBER
)

IS

    v_check NUMBER;

    v_tenmon VARCHAR2(100);

    v_sep  VARCHAR2(70) := RPAD('=',60,'=');

    v_sep2 VARCHAR2(70) := RPAD('-',60,'-');

    v_tong_sv NUMBER := 0;

    v_sum_diem NUMBER := 0;

    v_co_diem NUMBER := 0;

BEGIN

    --kt môn học tồn tại
    SELECT COUNT(*)
    INTO v_check
    FROM MONHOC
    WHERE MaMon = p_mamon;

    IF v_check = 0 THEN

        DBMS_OUTPUT.PUT_LINE(
            'Mon hoc ' || p_mamon || ' khong ton tai!'
        );

        RETURN;

    END IF;

    --lấy tên môn
    SELECT TenMon
    INTO v_tenmon
    FROM MONHOC
    WHERE MaMon = p_mamon;

    --in tiêu đề
    DBMS_OUTPUT.PUT_LINE(v_sep);

    DBMS_OUTPUT.PUT_LINE(
        'BAO CAO MON HOC: ' || p_mamon
    );

    DBMS_OUTPUT.PUT_LINE(v_sep2);

    DBMS_OUTPUT.PUT_LINE(
        'Ten mon hoc: ' || v_tenmon
    );

    DBMS_OUTPUT.PUT_LINE(v_sep2);

    --header bảng
    DBMS_OUTPUT.PUT_LINE(

        RPAD('Lop',8) ||

        RPAD('Giao vien',25) ||

        LPAD('SVDK',8) ||

        LPAD('DTB',8)

    );

    DBMS_OUTPUT.PUT_LINE(v_sep2);

    --cursor FOR LOOP
    FOR rec IN
    (

        SELECT
            lh.MaLop,

            gv.HO || ' ' || gv.TEN AS ten_gv,

            COUNT(dk.MaSV) AS so_sv,

            ROUND(AVG(d.DIEM),1) AS dtb

        FROM LOPHOC lh

        JOIN GIAOVIEN gv
            ON lh.MaGV = gv.MaGV

        LEFT JOIN DANGKY dk
            ON lh.MaLop = dk.MaLop

        LEFT JOIN DIEM d
            ON dk.MaSV = d.MaSV
           AND dk.MaLop = d.MaLop

        WHERE lh.MaMon = p_mamon

        GROUP BY
            lh.MaLop,
            gv.HO,
            gv.TEN

        ORDER BY lh.MaLop

    )

    LOOP

        v_tong_sv := v_tong_sv + rec.so_sv;

        IF rec.dtb IS NOT NULL THEN

            v_sum_diem := v_sum_diem + rec.dtb;

            v_co_diem := v_co_diem + 1;

        END IF;

        DBMS_OUTPUT.PUT_LINE(

            RPAD(rec.MaLop,8) ||

            RPAD(rec.ten_gv,25) ||

            LPAD(rec.so_sv,8) ||

            LPAD(
                NVL(TO_CHAR(rec.dtb),'--'),
                8
            )

        );

    END LOOP;

    DBMS_OUTPUT.PUT_LINE(v_sep2);

    DBMS_OUTPUT.PUT_LINE(
        'Tong SV dang ky: ' || v_tong_sv
    );

    IF v_co_diem > 0 THEN

        DBMS_OUTPUT.PUT_LINE(
            'Diem TB toan mon: ' ||
            ROUND(v_sum_diem / v_co_diem,2)
        );

    END IF;

    DBMS_OUTPUT.PUT_LINE(v_sep);

END generate_course_report;
/

--test
BEGIN
    generate_course_report(1);
END;
/

--2.7
CREATE OR REPLACE FUNCTION convert_to_gpa_40
(
    p_masv IN NUMBER
)
RETURN NUMBER
IS
    v_gpa NUMBER;
BEGIN

    SELECT ROUND(
        AVG(
            CASE
                WHEN DIEM >= 90 THEN 4.0
                WHEN DIEM >= 85 THEN 3.7
                WHEN DIEM >= 80 THEN 3.3
                WHEN DIEM >= 75 THEN 3.0
                WHEN DIEM >= 70 THEN 2.7
                WHEN DIEM >= 65 THEN 2.3
                WHEN DIEM >= 60 THEN 2.0
                WHEN DIEM >= 50 THEN 1.0
                ELSE 0.0
            END
        ),
        2
    )
    INTO v_gpa
    FROM DIEM
    WHERE MaSV = p_masv;

    RETURN v_gpa;

END;
/

CREATE OR REPLACE PROCEDURE print_gpa_report
IS
BEGIN
    DBMS_OUTPUT.PUT_LINE(
        RPAD('MaSV',10) ||
        RPAD('Ho Ten',25) ||
        LPAD('GPA(4.0)',10)
    );

    DBMS_OUTPUT.PUT_LINE(RPAD('-',45,'-'));

    FOR rec IN (
        SELECT 
            MaSV,
            HO || ' ' || TEN AS ho_ten
        FROM SINHVIEN
        ORDER BY MaSV
    )
    LOOP
        DECLARE
            v_gpa NUMBER;
        BEGIN
            v_gpa := convert_to_gpa_40(rec.MaSV);

            IF v_gpa IS NOT NULL THEN
                DBMS_OUTPUT.PUT_LINE(
                    RPAD(rec.MaSV,10) ||
                    RPAD(rec.ho_ten,25) ||
                    LPAD(v_gpa,10)
                );
            END IF;
        END;
    END LOOP;
END print_gpa_report;
/

--test
BEGIN
    print_gpa_report;
END;
/

--2.8
CREATE TABLE notification_log (
    log_id NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    nguoi_nhan VARCHAR2(50),
    noi_dung VARCHAR2(500),
    loai VARCHAR2(20),
    thoi_gian DATE DEFAULT SYSDATE,
    trang_thai VARCHAR2(10) DEFAULT 'SENT'
);
/

CREATE OR REPLACE PROCEDURE log_notification
(
    p_nguoi_nhan VARCHAR2,
    p_noi_dung VARCHAR2,
    p_loai VARCHAR2 DEFAULT 'INFO'
)
IS
    PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN

    INSERT INTO notification_log
    (
        nguoi_nhan,
        noi_dung,
        loai
    )
    VALUES
    (
        p_nguoi_nhan,
        SUBSTR(p_noi_dung,1,500),
        p_loai
    );

    COMMIT;

EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
END log_notification;
/

BEGIN

    INSERT INTO SINHVIEN
    (
        MaSV,
        HO,
        TEN,
        NGAYDANGKY,
        NGUOITAO,
        NGAYTAO,
        NGUOISUA,
        NGAYSUA
    )
    VALUES
    (
        9999,
        'Test',
        'Rollback',
        SYSDATE,
        USER,
        SYSDATE,
        USER,
        SYSDATE
    );

    log_notification(
        'Admin',
        'Da them sinh vien 9999',
        'INSERT'
    );

    ROLLBACK;

END;
/

SELECT * FROM notification_log;

SELECT * FROM SINHVIEN
WHERE MaSV = 9999;



----------------------------------BÀI 3-----------------------------------------
--3.1
ALTER TABLE LOPHOC
ADD SoSV NUMBER DEFAULT 0;

CREATE OR REPLACE TRIGGER trg_update_class_count
FOR INSERT OR UPDATE OR DELETE ON DANGKY
COMPOUND TRIGGER

    TYPE t_ids IS TABLE OF NUMBER INDEX BY PLS_INTEGER;

    v_ids t_ids;
    v_idx PLS_INTEGER := 0;

BEFORE STATEMENT IS
BEGIN
    v_idx := 0;
    v_ids.DELETE;
END BEFORE STATEMENT;

AFTER EACH ROW IS
BEGIN

    v_idx := v_idx + 1;

    v_ids(v_idx) :=
        CASE
            WHEN INSERTING OR UPDATING THEN :NEW.MaLop
            ELSE :OLD.MaLop
        END;

END AFTER EACH ROW;

AFTER STATEMENT IS
BEGIN

    FOR i IN 1 .. v_idx LOOP

        UPDATE LOPHOC
        SET SoSV =
        (
            SELECT COUNT(*)
            FROM DANGKY
            WHERE MaLop = v_ids(i)
        )
        WHERE MaLop = v_ids(i);

    END LOOP;

END AFTER STATEMENT;

END trg_update_class_count;
/

--test
INSERT INTO DANGKY
(
    MaSV,
    MaLop,
    NgayDangKy,
    NGUOITAO,
    NGAYTAO,
    NGUOISUA,
    NGAYSUA
)
VALUES
(
    120,
    201,
    SYSDATE,
    USER,
    SYSDATE,
    USER,
    SYSDATE
);

COMMIT;

SELECT MaLop, SoSV
FROM LOPHOC
WHERE MaLop = 201;

--3.2
CREATE OR REPLACE VIEW vw_chitiet_dangky AS
SELECT
    dk.MaLop,
    dk.MaSV,

    sv.HO || ' ' || sv.TEN AS ten_sv,

    mh.TenMon AS ten_mon,

    d.DIEM,

    gv.HO || ' ' || gv.TEN AS ten_gv

FROM DANGKY dk

JOIN SINHVIEN sv
    ON dk.MaSV = sv.MaSV

JOIN LOPHOC lh
    ON dk.MaLop = lh.MaLop

JOIN MONHOC mh
    ON lh.MaMon = mh.MaMon

JOIN GIAOVIEN gv
    ON lh.MaGV = gv.MaGV

LEFT JOIN DIEM d
    ON dk.MaSV = d.MaSV
   AND dk.MaLop = d.MaLop;
/

CREATE OR REPLACE TRIGGER trg_iot_update_grade
INSTEAD OF UPDATE ON vw_chitiet_dangky
FOR EACH ROW

DECLARE
    v_old_grade NUMBER;

BEGIN

    IF :NEW.DIEM IS NOT NULL
       AND (:NEW.DIEM < 0 OR :NEW.DIEM > 100)
    THEN
        RAISE_APPLICATION_ERROR(
            -20060,
            'Diem khong hop le (0-100)!'
        );
    END IF;

    BEGIN
        SELECT DIEM
        INTO v_old_grade
        FROM DIEM
        WHERE MaSV = :OLD.MaSV
          AND MaLop = :OLD.MaLop;

    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            v_old_grade := NULL;
    END;

    MERGE INTO DIEM d
    USING
    (
        SELECT
            :OLD.MaSV AS sid,
            :OLD.MaLop AS lid
        FROM DUAL
    ) src

    ON (
        d.MaSV = src.sid
        AND d.MaLop = src.lid
    )

    WHEN MATCHED THEN
        UPDATE SET
            d.DIEM = :NEW.DIEM,
            d.NGUOISUA = USER,
            d.NGAYSUA = SYSDATE

    WHEN NOT MATCHED THEN
        INSERT
        (
            MaSV,
            MaLop,
            DIEM,
            NGUOITAO,
            NGAYTAO,
            NGUOISUA,
            NGAYSUA
        )
        VALUES
        (
            :OLD.MaSV,
            :OLD.MaLop,
            :NEW.DIEM,
            USER,
            SYSDATE,
            USER,
            SYSDATE
        );

    log_notification(
        'System',
        'Cap nhat diem SV '
        || :OLD.MaSV
        || ' lop '
        || :OLD.MaLop
        || ': '
        || NVL(TO_CHAR(v_old_grade),'NULL')
        || ' -> '
        || :NEW.DIEM,
        'GRADE'
    );

END trg_iot_update_grade;
/

--test
UPDATE vw_chitiet_dangky
SET DIEM = 88
WHERE MaSV = 120
AND MaLop = 201;

COMMIT;

--xem điểm
SELECT * FROM DIEM
WHERE MaSV = 120
AND MaLop = 201;

--xem log
SELECT * FROM notification_log
ORDER BY log_id DESC;

--3.4
CREATE TABLE ddl_audit_log
(
    log_id NUMBER GENERATED ALWAYS AS IDENTITY,
    event_type VARCHAR2(30),
    object_type VARCHAR2(30),
    object_name VARCHAR2(128),
    owner VARCHAR2(30),
    event_time DATE,
    current_usr VARCHAR2(30)
);
/

CREATE OR REPLACE TRIGGER trg_ddl_audit

AFTER DDL
ON SCHEMA

DECLARE

    PRAGMA AUTONOMOUS_TRANSACTION;

BEGIN

    INSERT INTO ddl_audit_log
    (
        event_type,
        object_type,
        object_name,
        owner,
        event_time,
        current_usr
    )
    VALUES
    (
        ORA_SYSEVENT,
        ORA_DICT_OBJ_TYPE,
        ORA_DICT_OBJ_NAME,
        ORA_DICT_OBJ_OWNER,
        SYSDATE,
        ORA_LOGIN_USER
    );

    COMMIT;

EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;

END trg_ddl_audit;
/

--test
CREATE TABLE test_ddl_track
(
    id NUMBER
);

DROP TABLE test_ddl_track;

SELECT * FROM ddl_audit_log
ORDER BY log_id DESC;

--3.4
CREATE OR REPLACE TRIGGER trg_prevent_student_delete

BEFORE DELETE
ON SINHVIEN

FOR EACH ROW

DECLARE
    v_count NUMBER;

BEGIN

    SELECT COUNT(*)
    INTO v_count
    FROM DANGKY
    WHERE MaSV = :OLD.MaSV;

    IF v_count > 0 THEN

        RAISE_APPLICATION_ERROR(
            -20030,
            'Khong the xoa SV '
            || :OLD.MaSV
            || ' dang co '
            || v_count
            || ' lop dang ky! Hay huy dang ky truoc.'
        );

    END IF;

END;
/

CREATE OR REPLACE TRIGGER trg_cascade_delete_grade

AFTER DELETE
ON SINHVIEN

FOR EACH ROW

BEGIN

    DELETE FROM DIEM
    WHERE MaSV = :OLD.MaSV;

    DBMS_OUTPUT.PUT_LINE(
        'Da xoa '
        || SQL%ROWCOUNT
        || ' bang diem cua SV '
        || :OLD.MaSV
    );

END;
/

CREATE OR REPLACE TRIGGER trg_update_count_on_delete

AFTER DELETE
ON DANGKY

FOR EACH ROW

BEGIN

    UPDATE LOPHOC
    SET SoSV = SoSV - 1
    WHERE MaLop = :OLD.MaLop
    AND SoSV > 0;

END;
/

--test
DELETE FROM SINHVIEN
WHERE MaSV = 120;

DELETE FROM DANGKY
WHERE MaSV = 120;

DELETE FROM SINHVIEN
WHERE MaSV = 120;

ROLLBACK;

--3.5
CREATE TABLE CHUNGCHI
(
    MaCC NUMBER GENERATED ALWAYS AS IDENTITY,
    MaSV NUMBER,
    MaMon NUMBER,
    NgayCap DATE,
    LoaiCC VARCHAR2(20)
);
/

CREATE OR REPLACE TRIGGER trg_auto_certificate

AFTER UPDATE OF DIEM
ON DIEM

FOR EACH ROW

WHEN (NEW.DIEM >= 50)

DECLARE

    v_mamon NUMBER;

    v_check NUMBER;

    v_loaicc VARCHAR2(20);

    v_ten_sv VARCHAR2(100);

    v_ten_mon VARCHAR2(100);

BEGIN

    --lay thong tin mon hoc va sinh vien

    SELECT
        lh.MaMon,
        mh.TenMon,
        sv.HO || ' ' || sv.TEN
    INTO
        v_mamon,
        v_ten_mon,
        v_ten_sv

    FROM LOPHOC lh

    JOIN MONHOC mh
        ON lh.MaMon = mh.MaMon

    JOIN SINHVIEN sv
        ON sv.MaSV = :NEW.MaSV

    WHERE lh.MaLop = :NEW.MaLop;

    --kt da co chung chi chua

    SELECT COUNT(*)
    INTO v_check
    FROM CHUNGCHI
    WHERE MaSV = :NEW.MaSV
      AND MaMon = v_mamon;

    IF v_check > 0 THEN
        RETURN;
    END IF;

    --xep loai chung chi

    v_loaicc :=
        CASE
            WHEN :NEW.DIEM >= 90 THEN 'HIGH_DISTINCTION'
            WHEN :NEW.DIEM >= 75 THEN 'DISTINCTION'
            ELSE 'PASS'
        END;

    --cap chung chi

    INSERT INTO CHUNGCHI
    (
        MaSV,
        MaMon,
        NgayCap,
        LoaiCC
    )
    VALUES
    (
        :NEW.MaSV,
        v_mamon,
        SYSDATE,
        v_loaicc
    );

    DBMS_OUTPUT.PUT_LINE(
        'Chuc mung '
        || v_ten_sv
        || ' da hoan thanh mon '
        || v_ten_mon
        || ' voi '
        || v_loaicc
        || '!'
    );

END trg_auto_certificate;
/

--test
UPDATE DIEM
SET DIEM = 92
WHERE MaSV = 120
AND MaLop = 201;

COMMIT;

SELECT * FROM CHUNGCHI;



----------------------------------BÀI 4-----------------------------------------
ALTER TABLE LOPHOC
ADD SiSoToiDa NUMBER DEFAULT 30;

UPDATE LOPHOC
SET SiSoToiDa = 30;

--4.1
CREATE OR REPLACE VIEW vw_enrollment_dashboard AS

SELECT

    (SELECT COUNT(*)
     FROM LOPHOC) AS so_lop_mo,

    (
        SELECT SUM(lh.SiSoToiDa - NVL(dk.sl,0))

        FROM LOPHOC lh

        LEFT JOIN
        (
            SELECT MaLop,
                   COUNT(*) sl
            FROM DANGKY
            GROUP BY MaLop
        ) dk

        ON lh.MaLop = dk.MaLop

    ) AS tong_cho_trong,

    ROUND(
        (
            SELECT COUNT(*)
            FROM DANGKY
        ) * 100.0 /

        NULLIF(
            (
                SELECT SUM(SiSoToiDa)
                FROM LOPHOC
            ),
            0
        ),
        1
    ) AS ty_le_lap_day_pct,

    (
        SELECT MaLop || ' (' || sl || ' SV)'

        FROM
        (
            SELECT MaLop,
                   COUNT(*) sl
            FROM DANGKY
            GROUP BY MaLop
            ORDER BY sl DESC
        )

        FETCH FIRST 1 ROW ONLY

    ) AS lop_dong_nhat,

    (
        SELECT MaLop || ' (' || sl || ' SV)'

        FROM
        (
            SELECT MaLop,
                   COUNT(*) sl
            FROM DANGKY
            GROUP BY MaLop
            ORDER BY sl ASC
        )

        FETCH FIRST 1 ROW ONLY

    ) AS lop_it_nhat

FROM DUAL;
/

SELECT * FROM vw_enrollment_dashboard;

CREATE OR REPLACE PACKAGE pkg_enrollment_system AS

    FUNCTION is_eligible
    (
        p_masv NUMBER,
        p_malop NUMBER
    )
    RETURN BOOLEAN;

    PROCEDURE do_enroll
    (
        p_masv NUMBER,
        p_malop NUMBER
    );

    PROCEDURE do_withdraw
    (
        p_masv NUMBER,
        p_malop NUMBER
    );

    FUNCTION get_waitlist_position
    (
        p_masv NUMBER,
        p_malop NUMBER
    )
    RETURN NUMBER;

END pkg_enrollment_system;
/

CREATE OR REPLACE PACKAGE BODY pkg_enrollment_system AS

FUNCTION is_eligible
(
    p_masv NUMBER,
    p_malop NUMBER
)
RETURN BOOLEAN

IS

    v_sv NUMBER;
    v_lop NUMBER;

    v_siso NUMBER;
    v_dadangky NUMBER;

    v_trung NUMBER;

BEGIN

    -- Kiem tra sinh vien

    SELECT COUNT(*)
    INTO v_sv
    FROM SINHVIEN
    WHERE MaSV = p_masv;

    IF v_sv = 0 THEN
        RETURN FALSE;
    END IF;

    -- Kiem tra lop

    SELECT COUNT(*)
    INTO v_lop
    FROM LOPHOC
    WHERE MaLop = p_malop;

    IF v_lop = 0 THEN
        RETURN FALSE;
    END IF;

    -- Kiem tra si so

    SELECT SiSoToiDa
    INTO v_siso
    FROM LOPHOC
    WHERE MaLop = p_malop;

    SELECT COUNT(*)
    INTO v_dadangky
    FROM DANGKY
    WHERE MaLop = p_malop;

    IF v_dadangky >= v_siso THEN
        RETURN FALSE;
    END IF;

    -- Kiem tra trung dang ky

    SELECT COUNT(*)
    INTO v_trung
    FROM DANGKY
    WHERE MaSV = p_masv
      AND MaLop = p_malop;

    IF v_trung > 0 THEN
        RETURN FALSE;
    END IF;

    -- Kiem tra qua 3 lop

    SELECT COUNT(*)
    INTO v_dadangky
    FROM DANGKY
    WHERE MaSV = p_masv;

    IF v_dadangky >= 3 THEN
        RETURN FALSE;
    END IF;

    RETURN TRUE;

END is_eligible;

PROCEDURE do_enroll
(
    p_masv NUMBER,
    p_malop NUMBER
)

IS

BEGIN

    IF NOT is_eligible(p_masv, p_malop) THEN

        DBMS_OUTPUT.PUT_LINE(
            '[TU CHOI] Khong du dieu kien dang ky!'
        );

        RETURN;

    END IF;

    INSERT INTO DANGKY
    (
        MaSV,
        MaLop,
        NgayDangKy,
        NGUOITAO,
        NGAYTAO,
        NGUOISUA,
        NGAYSUA
    )
    VALUES
    (
        p_masv,
        p_malop,
        SYSDATE,
        USER,
        SYSDATE,
        USER,
        SYSDATE
    );

    COMMIT;

    log_notification(
        USER,
        'Dang ky: SV '
        || p_masv
        || ' -> Lop '
        || p_malop,
        'ENROLL'
    );

    DBMS_OUTPUT.PUT_LINE(
        '[OK] Dang ky thanh cong!'
    );

END do_enroll;

PROCEDURE do_withdraw
(
    p_masv NUMBER,
    p_malop NUMBER
)

IS

    v_check NUMBER;

BEGIN

    SELECT COUNT(*)
    INTO v_check
    FROM DANGKY
    WHERE MaSV = p_masv
      AND MaLop = p_malop;

    IF v_check = 0 THEN

        DBMS_OUTPUT.PUT_LINE(
            '[LOI] SV chua dang ky lop nay!'
        );

        RETURN;

    END IF;

    DELETE FROM DANGKY
    WHERE MaSV = p_masv
      AND MaLop = p_malop;

    COMMIT;

    log_notification(
        USER,
        'Huy dang ky: SV '
        || p_masv
        || ' khoi Lop '
        || p_malop,
        'WITHDRAW'
    );

    DBMS_OUTPUT.PUT_LINE(
        '[OK] Huy dang ky thanh cong!'
    );

END do_withdraw;

FUNCTION get_waitlist_position
(
    p_masv NUMBER,
    p_malop NUMBER
)
RETURN NUMBER

IS

    v_siso NUMBER;
    v_dk NUMBER;

BEGIN

    SELECT SiSoToiDa
    INTO v_siso
    FROM LOPHOC
    WHERE MaLop = p_malop;

    SELECT COUNT(*)
    INTO v_dk
    FROM DANGKY
    WHERE MaLop = p_malop;

    IF v_dk < v_siso THEN
        RETURN 0;
    END IF;

    RETURN v_dk - v_siso + 1;

END;

END pkg_enrollment_system;
/

--test
BEGIN

    pkg_enrollment_system.do_enroll(120, 201);

    pkg_enrollment_system.do_enroll(999, 201);

END;
/

SELECT * FROM notification_log
ORDER BY log_id DESC;

--4.2
--Phan A
EXPLAIN PLAN FOR
SELECT * FROM vw_course_summary;

SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY);

CREATE INDEX idx_dangky_malop
ON DANGKY(MaLop);

CREATE INDEX idx_dangky_masv
ON DANGKY(MaSV);

CREATE INDEX idx_lophoc_mamon
ON LOPHOC(MaMon);

CREATE INDEX idx_lophoc_magv
ON LOPHOC(MaGV);

EXPLAIN PLAN FOR
SELECT * FROM vw_enrollment_dashboard;

SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY);

--PHAN B
CREATE OR REPLACE PROCEDURE report_class_detail_v2
(
    p_malop IN NUMBER
)
IS

    TYPE t_rec IS RECORD
    (
        ho_ten VARCHAR2(100),
        diem NUMBER
    );

    TYPE t_recs IS TABLE OF t_rec
    INDEX BY PLS_INTEGER;

    v_data t_recs;

    v_stt NUMBER := 0;

BEGIN

    SELECT sv.HO || ' ' || sv.TEN,
           d.DIEM
    BULK COLLECT INTO v_data

    FROM DANGKY dk

    JOIN SINHVIEN sv
        ON dk.MaSV = sv.MaSV

    LEFT JOIN DIEM d
        ON dk.MaSV = d.MaSV
       AND dk.MaLop = d.MaLop

    WHERE dk.MaLop = p_malop

    ORDER BY sv.TEN;

    DBMS_OUTPUT.PUT_LINE('So SV: ' || v_data.COUNT);

    FOR i IN 1 .. v_data.COUNT LOOP

        v_stt := v_stt + 1;

        DBMS_OUTPUT.PUT_LINE(
            LPAD(v_stt, 3) || ' ' ||
            RPAD(v_data(i).ho_ten, 25) ||
            LPAD(NVL(TO_CHAR(v_data(i).diem), '--'), 8)
        );

    END LOOP;

END;
/

--test
BEGIN
    report_class_detail_v2(201);
END;
/

--PHAN C
CREATE OR REPLACE PROCEDURE run_all_tests
IS

    v_pass NUMBER := 0;
    v_fail NUMBER := 0;
    v_cnt NUMBER;

    PROCEDURE assert_test
    (
        p_test VARCHAR2,
        p_cond BOOLEAN
    )
    IS
    BEGIN

        IF p_cond THEN

            v_pass := v_pass + 1;

            DBMS_OUTPUT.PUT_LINE('[PASS] ' || p_test);

        ELSE

            v_fail := v_fail + 1;

            DBMS_OUTPUT.PUT_LINE('[FAIL] ' || p_test);

        END IF;

    END;

BEGIN

    DBMS_OUTPUT.PUT_LINE('=== BAT DAU TEST ===');

    --test 1
    BEGIN

        INSERT INTO DANGKY
        (
            MaSV,
            MaLop,
            NgayDangKy
        )
        VALUES
        (
            120,
            201,
            SYSDATE
        );

        SELECT COUNT(*)
        INTO v_cnt
        FROM DANGKY
        WHERE MaSV = 120
          AND MaLop = 201;

        assert_test('Dang ky hop le', v_cnt > 0);

        ROLLBACK;

    EXCEPTION
        WHEN OTHERS THEN
            assert_test('Dang ky hop le', FALSE);
    END;
    
    --test 2
    BEGIN

        SELECT COUNT(*)
        INTO v_cnt
        FROM SINHVIEN
        WHERE MaSV = 99999;

        assert_test('SV khong ton tai', v_cnt = 0);

    END;

    DBMS_OUTPUT.PUT_LINE(
        '=== KET QUA: PASS=' || v_pass ||
        ' FAIL=' || v_fail || ' ==='
    );

END;
/

--test
BEGIN
    run_all_tests;
END;
/