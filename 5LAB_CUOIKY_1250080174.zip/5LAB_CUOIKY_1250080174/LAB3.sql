show user;
-----------------------------------Tạo bảng-------------------------------------
CREATE TABLE MONHOC (
    MaMon NUMBER(8,0) PRIMARY KEY,
    TenMon VARCHAR2(50),
    HocPhi NUMBER(9,2),
    MonTienQuyet NUMBER(8,0),
    NguoiTao VARCHAR2(30) NOT NULL,
    NgayTao DATE NOT NULL,
    NguoiSua VARCHAR2(30) NOT NULL,
    NgaySua DATE NOT NULL
);

CREATE TABLE LOPHOC (
    MaLop NUMBER(8,0) PRIMARY KEY,
    MaMon NUMBER(8,0) NOT NULL,
    SoLop NUMBER(3),
    ThoiGianBatDau DATE,
    PhongHoc VARCHAR2(50),
    MaGV NUMBER(8,0) NOT NULL,
    SucChua NUMBER(3),
    NguoiTao VARCHAR2(30) NOT NULL,
    NgayTao DATE NOT NULL,
    NguoiSua VARCHAR2(30) NOT NULL,
    NgaySua DATE NOT NULL,

    CONSTRAINT fk_lophoc_mon FOREIGN KEY (MaMon) REFERENCES MONHOC(MaMon)
);

CREATE TABLE SINHVIEN (
    MaSV NUMBER(8,0) PRIMARY KEY,
    DanhXung VARCHAR2(5),
    Ten VARCHAR2(25),
    Ho VARCHAR2(25) NOT NULL,
    DiaChi VARCHAR2(50),
    DienThoai VARCHAR2(15),
    CongTy VARCHAR2(50),
    NgayDangKy DATE NOT NULL,
    NguoiTao VARCHAR2(30) NOT NULL,
    NgayTao DATE NOT NULL,
    NguoiSua VARCHAR2(30) NOT NULL,
    NgaySua DATE NOT NULL
);

CREATE TABLE GIAOVIEN (
    MaGV NUMBER(8,0) PRIMARY KEY,
    DanhXung VARCHAR2(5),
    Ten VARCHAR2(25),
    Ho VARCHAR2(25),
    DiaChi VARCHAR2(50),
    DienThoai VARCHAR2(15),
    NguoiTao VARCHAR2(30) NOT NULL,
    NgayTao DATE NOT NULL,
    NguoiSua VARCHAR2(30) NOT NULL,
    NgaySua DATE NOT NULL
);

CREATE TABLE DANGKY (
    MaSV NUMBER(8,0),
    MaLop NUMBER(8,0),
    NgayDangKy DATE NOT NULL,
    DiemTongKet NUMBER(3),
    NguoiTao VARCHAR2(30) NOT NULL,
    NgayTao DATE NOT NULL,
    NguoiSua VARCHAR2(30) NOT NULL,
    NgaySua DATE NOT NULL,

    CONSTRAINT pk_dangky PRIMARY KEY (MaSV, MaLop),
    CONSTRAINT fk_dk_sv FOREIGN KEY (MaSV) REFERENCES SINHVIEN(MaSV),
    CONSTRAINT fk_dk_lop FOREIGN KEY (MaLop) REFERENCES LOPHOC(MaLop)
);

CREATE TABLE DIEM (
    MaSV NUMBER(8,0),
    MaLop NUMBER(8,0),
    Diem NUMBER(3) NOT NULL,
    NhanXet VARCHAR2(2000),
    NguoiTao VARCHAR2(30) NOT NULL,
    NgayTao DATE NOT NULL,
    NguoiSua VARCHAR2(30) NOT NULL,
    NgaySua DATE NOT NULL,

    CONSTRAINT pk_diem PRIMARY KEY (MaSV, MaLop),
    CONSTRAINT fk_diem_sv FOREIGN KEY (MaSV) REFERENCES SINHVIEN(MaSV),
    CONSTRAINT fk_diem_lop FOREIGN KEY (MaLop) REFERENCES LOPHOC(MaLop)
);

SELECT table_name 
FROM user_tables;

------------------------------Insert dữ liệu------------------------------------
INSERT INTO MONHOC VALUES (10, 'Co so du lieu', 1000, NULL, USER, SYSDATE, USER, SYSDATE);
INSERT INTO MONHOC VALUES (20, 'Lap trinh web', 1200, NULL, USER, SYSDATE, USER, SYSDATE);
INSERT INTO MONHOC VALUES (30, 'Lap trinh GIS', 1500, 10, USER, SYSDATE, USER, SYSDATE);
INSERT INTO MONHOC VALUES (40, 'Tri tue nhan tao', 1800, 20, USER, SYSDATE, USER, SYSDATE);
INSERT INTO MONHOC VALUES (50, 'Toan cao cap', 2000, 40, USER, SYSDATE, USER, SYSDATE);
SELECT * FROM MONHOC;

INSERT INTO GIAOVIEN VALUES (1, 'Mr', 'An', 'Nguyen', 'HCM', '0801565072', USER, SYSDATE, USER, SYSDATE);
INSERT INTO GIAOVIEN VALUES (2, 'Ms', 'Binh', 'Tran', 'Ha Noi', '0902248589', USER, SYSDATE, USER, SYSDATE);
INSERT INTO GIAOVIEN VALUES (3, 'Mr', 'Cuong', 'Le', 'Da Nang', '0803669487', USER, SYSDATE, USER, SYSDATE);
INSERT INTO GIAOVIEN VALUES (4, 'Ms', 'Trang', 'Pham', 'Tien Giang', '0944534969', USER, SYSDATE, USER, SYSDATE);
INSERT INTO GIAOVIEN VALUES (5, 'Mr', 'Khanh', 'Vo', 'Tay Ninh', '0905656123', USER, SYSDATE, USER, SYSDATE);
SELECT * FROM GIAOVIEN;

INSERT INTO SINHVIEN VALUES (101, 'Mr', 'Nam', 'Pham', 'Can Tho', '0809264555', 'ABC', SYSDATE, USER, SYSDATE, USER, SYSDATE);
INSERT INTO SINHVIEN VALUES (102, 'Ms', 'Lan', 'Nguyen', 'HCM', '0904455236', 'XYZ', SYSDATE, USER, SYSDATE, USER, SYSDATE);
INSERT INTO SINHVIEN VALUES (103, 'Mr', 'Huy', 'Tran', 'Ha Noi', '0306355684', 'DEF', SYSDATE, USER, SYSDATE, USER, SYSDATE);
INSERT INTO SINHVIEN VALUES (104, 'Ms', 'Linh', 'Le', 'Lam Dong', '0335654989', 'GHI', SYSDATE, USER, SYSDATE, USER, SYSDATE);
INSERT INTO SINHVIEN VALUES (105, 'Mr', 'Tuan', 'Hoang', 'Dong Nai', '0898456515', 'AAA', SYSDATE, USER, SYSDATE, USER, SYSDATE);
INSERT INTO SINHVIEN VALUES (106, 'Ms', 'Nga', 'Pham', 'Dong Thap', '0885465632', 'BBB', SYSDATE, USER, SYSDATE, USER, SYSDATE);
INSERT INTO SINHVIEN VALUES (107, 'Mr', 'Duy', 'Nguyen', 'HCM', '0912468957', 'CCC', SYSDATE, USER, SYSDATE, USER, SYSDATE);
INSERT INTO SINHVIEN VALUES (108, 'Ms', 'Vy', 'Tran', 'Gia Lai', '0976547885', 'DDD', SYSDATE, USER, SYSDATE, USER, SYSDATE);
INSERT INTO SINHVIEN VALUES (109, 'Mr', 'Long', 'Le', 'Tra Vinh', '0352645258', 'EEE', SYSDATE, USER, SYSDATE, USER, SYSDATE);
INSERT INTO SINHVIEN VALUES (110, 'Ms', 'Mai', 'Nguyen', 'HCM', '0362485849', 'FFF', SYSDATE, USER, SYSDATE, USER, SYSDATE);
SELECT * FROM SINHVIEN;

INSERT INTO LOPHOC VALUES (1, 10, 1, SYSDATE, 'A1', 1, 30, USER, SYSDATE, USER, SYSDATE);
INSERT INTO LOPHOC VALUES (2, 10, 2, SYSDATE, 'A2', 1, 30, USER, SYSDATE, USER, SYSDATE);
INSERT INTO LOPHOC VALUES (3, 20, 1, SYSDATE, 'B1', 2, 30, USER, SYSDATE, USER, SYSDATE);
INSERT INTO LOPHOC VALUES (4, 20, 2, SYSDATE, 'B2', 2, 30, USER, SYSDATE, USER, SYSDATE);
INSERT INTO LOPHOC VALUES (5, 30, 1, SYSDATE, 'C1', 3, 30, USER, SYSDATE, USER, SYSDATE);
INSERT INTO LOPHOC VALUES (6, 30, 2, SYSDATE, 'C2', 3, 30, USER, SYSDATE, USER, SYSDATE);
INSERT INTO LOPHOC VALUES (7, 40, 1, SYSDATE, 'D1', 4, 30, USER, SYSDATE, USER, SYSDATE);
INSERT INTO LOPHOC VALUES (8, 40, 2, SYSDATE, 'D2', 4, 30, USER, SYSDATE, USER, SYSDATE);
INSERT INTO LOPHOC VALUES (9, 50, 1, SYSDATE, 'E1', 5, 30, USER, SYSDATE, USER, SYSDATE);
INSERT INTO LOPHOC VALUES (10, 50, 2, SYSDATE, 'E2', 5, 30, USER, SYSDATE, USER, SYSDATE);
SELECT * FROM LOPHOC;

--SV học nhiều nhất
INSERT INTO DANGKY VALUES (101, 1, SYSDATE, 85, USER, SYSDATE, USER, SYSDATE);
INSERT INTO DANGKY VALUES (101, 2, SYSDATE, 90, USER, SYSDATE, USER, SYSDATE);
INSERT INTO DANGKY VALUES (101, 3, SYSDATE, 70, USER, SYSDATE, USER, SYSDATE);
INSERT INTO DANGKY VALUES (101, 4, SYSDATE, 88, USER, SYSDATE, USER, SYSDATE);
INSERT INTO DANGKY VALUES (101, 5, SYSDATE, 95, USER, SYSDATE, USER, SYSDATE);

--Các SV khác
INSERT INTO DANGKY VALUES (102, 1, SYSDATE, 75, USER, SYSDATE, USER, SYSDATE);
INSERT INTO DANGKY VALUES (102, 4, SYSDATE, 60, USER, SYSDATE, USER, SYSDATE);
INSERT INTO DANGKY VALUES (103, 5, SYSDATE, 50, USER, SYSDATE, USER, SYSDATE);
INSERT INTO DANGKY VALUES (104, 2, SYSDATE, 78, USER, SYSDATE, USER, SYSDATE);
INSERT INTO DANGKY VALUES (104, 3, SYSDATE, 82, USER, SYSDATE, USER, SYSDATE);
INSERT INTO DANGKY VALUES (105, 8, SYSDATE, 85, USER, SYSDATE, USER, SYSDATE);
INSERT INTO DANGKY VALUES (106, 10, SYSDATE, 55, USER, SYSDATE, USER, SYSDATE);
INSERT INTO DANGKY VALUES (107, 7, SYSDATE, 92, USER, SYSDATE, USER, SYSDATE);
INSERT INTO DANGKY VALUES (108, 9, SYSDATE, 73, USER, SYSDATE, USER, SYSDATE);
INSERT INTO DANGKY VALUES (109, 1, SYSDATE, 68, USER, SYSDATE, USER, SYSDATE);
INSERT INTO DANGKY VALUES (110, 10, SYSDATE, 40, USER, SYSDATE, USER, SYSDATE);
SELECT * FROM DANGKY;

INSERT INTO DIEM VALUES (101, 1, 85, 'Tot', USER, SYSDATE, USER, SYSDATE);
INSERT INTO DIEM VALUES (101, 2, 90, 'Xuat sac', USER, SYSDATE, USER, SYSDATE);
INSERT INTO DIEM VALUES (104, 3, 82, 'Kha', USER, SYSDATE, USER, SYSDATE);
INSERT INTO DIEM VALUES (107, 7, 92, 'Gioi', USER, SYSDATE, USER, SYSDATE);
INSERT INTO DIEM VALUES (110, 10, 40, 'Yeu', USER, SYSDATE, USER, SYSDATE);
SELECT * FROM DIEM;


-----------------------------------BAI 1----------------------------------------
----------1
--a
CREATE TABLE Cau1 (
    ID NUMBER,
    NAME VARCHAR2(50)
);

--b
CREATE SEQUENCE Cau1Seq
START WITH 5
INCREMENT BY 5;

--c -> j
SET SERVEROUTPUT ON;

DECLARE
    v_name VARCHAR2(50);
    v_id NUMBER;
BEGIN
    --d. SV đăng ký NHIỀU lớp nhất
    SELECT HO || ' ' || TEN
    INTO v_name
    FROM (
        SELECT sv.HO, sv.TEN
        FROM SINHVIEN sv
        JOIN DANGKY dk ON sv.MaSV = dk.MaSV
        GROUP BY sv.MaSV, sv.HO, sv.TEN
        ORDER BY COUNT(*) DESC
    )
    WHERE ROWNUM = 1;

    INSERT INTO Cau1 VALUES (Cau1Seq.NEXTVAL, v_name);
    SAVEPOINT sp_a;
    
    --e. SV đăng ký ÍT lớp nhất
    SELECT HO || ' ' || TEN
    INTO v_name
    FROM (
        SELECT sv.HO, sv.TEN
        FROM SINHVIEN sv
        JOIN DANGKY dk ON sv.MaSV = dk.MaSV
        GROUP BY sv.MaSV, sv.HO, sv.TEN
        ORDER BY COUNT(*) ASC
    )
    WHERE ROWNUM = 1;

    INSERT INTO Cau1 VALUES (Cau1Seq.NEXTVAL, v_name);
    SAVEPOINT sp_b;

    --f. GV dạy NHIỀU lớp nhất
    SELECT HO || ' ' || TEN
    INTO v_name
    FROM (
        SELECT gv.HO, gv.TEN
        FROM GIAOVIEN gv
        LEFT JOIN LOPHOC lh ON gv.MaGV = lh.MaGV
        GROUP BY gv.MaGV, gv.HO, gv.TEN
        ORDER BY COUNT(lh.MaLop) DESC
    )
    WHERE ROWNUM = 1;

    INSERT INTO Cau1 VALUES (Cau1Seq.NEXTVAL, v_name);
    SAVEPOINT sp_c;

    --g. Lấy ID vừa thêm
    SELECT MAX(ID)
    INTO v_id
    FROM Cau1
    WHERE NAME = v_name;

    DBMS_OUTPUT.PUT_LINE('ID giang vien nhieu lop: ' || v_id);
    
    --h. ROLLBACK về Savepoint B
    ROLLBACK TO sp_b;

    --i. GV dạy ÍT lớp nhất (dùng lại v_id)
    SELECT HO || ' ' || TEN
    INTO v_name
    FROM (
        SELECT gv.HO, gv.TEN
        FROM GIAOVIEN gv
        LEFT JOIN LOPHOC lh ON gv.MaGV = lh.MaGV
        GROUP BY gv.MaGV, gv.HO, gv.TEN
        ORDER BY COUNT(lh.MaLop) ASC
    )
    WHERE ROWNUM = 1;

    INSERT INTO Cau1 VALUES (v_id, v_name);

    --j. thêm lại GV dạy nhiều lớp nhất (dùng sequence)
    SELECT HO || ' ' || TEN
    INTO v_name
    FROM (
        SELECT gv.HO, gv.TEN
        FROM GIAOVIEN gv
        LEFT JOIN LOPHOC lh ON gv.MaGV = lh.MaGV
        GROUP BY gv.MaGV, gv.HO, gv.TEN
        ORDER BY COUNT(lh.MaLop) DESC
    )
    WHERE ROWNUM = 1;
    INSERT INTO Cau1 VALUES (Cau1Seq.NEXTVAL, v_name);

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Hoan tat! Chay: SELECT * FROM Cau1;');
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('Khong tim thay du lieu!');
        ROLLBACK;
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Loi: ' || SQLERRM);
        ROLLBACK;
END;
/

SELECT * FROM Cau1;

----------2
SET SERVEROUTPUT ON;

DECLARE
    v_masv NUMBER := &ma_sinh_vien;
    v_ho VARCHAR2(25) := '&ho';
    v_ten VARCHAR2(25) := '&ten';
    v_diachi VARCHAR2(50) := '&dia_chi';

    v_hoten VARCHAR2(50);
    v_soluong NUMBER;
BEGIN
    --thử tìm SV
    SELECT HO || ' ' || TEN
    INTO v_hoten
    FROM SINHVIEN
    WHERE MaSV = v_masv;
    --nếu tồn tại thì đếm số lớp
    SELECT COUNT(*)
    INTO v_soluong
    FROM DANGKY
    WHERE MaSV = v_masv;

    DBMS_OUTPUT.PUT_LINE('Ho ten: ' || v_hoten);
    DBMS_OUTPUT.PUT_LINE('So lop dang hoc: ' || v_soluong);

EXCEPTION
    --nếu KO tồn tại thì thêm mới
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('Sinh vien chua ton tai. Dang them moi...');

        INSERT INTO SINHVIEN
        VALUES (
            v_masv,
            NULL,
            v_ten,
            v_ho,
            v_diachi,
            NULL,
            NULL,
            SYSDATE,
            USER,
            SYSDATE,
            USER,
            SYSDATE
        );

        COMMIT;

        DBMS_OUTPUT.PUT_LINE('Da them sinh vien: ' || v_ho || ' ' || v_ten);
END;
/


-----------------------------------BAI 2----------------------------------------
----------1
SET SERVEROUTPUT ON;

DECLARE
    v_magv NUMBER := &ma_giao_vien;
    v_soluong NUMBER;
BEGIN
    --đếm số lớp GV dạy
    SELECT COUNT(*)
    INTO v_soluong
    FROM LOPHOC
    WHERE MaGV = v_magv;
    -- KT bằng if
    IF v_soluong >= 5 THEN
        DBMS_OUTPUT.PUT_LINE('Giao vien nay nen nghi ngoi!');
    ELSE
        DBMS_OUTPUT.PUT_LINE('So lop dang day: ' || v_soluong);
    END IF;

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('Khong tim thay giao vien!');
END;
/

----------2
SET SERVEROUTPUT ON;

DECLARE
    v_masv NUMBER := &ma_sinh_vien;
    v_malop NUMBER := &ma_lop;

    v_diem NUMBER;
    v_diemchu VARCHAR2(2);
    v_check NUMBER;
BEGIN
    --kt SV tồn tại
    SELECT COUNT(*) INTO v_check
    FROM SINHVIEN
    WHERE MaSV = v_masv;

    IF v_check = 0 THEN
        DBMS_OUTPUT.PUT_LINE('Loi: Ma sinh vien khong ton tai!');
        RETURN;
    END IF;

    --kt lớp tồn tại
    SELECT COUNT(*) INTO v_check
    FROM LOPHOC
    WHERE MaLop = v_malop;

    IF v_check = 0 THEN
        DBMS_OUTPUT.PUT_LINE('Loi: Ma lop khong ton tai!');
        RETURN;
    END IF;
    --lấy điểm
    SELECT DiemTongKet
    INTO v_diem
    FROM DANGKY
    WHERE MaSV = v_masv AND MaLop = v_malop;
    --CASE đổi điểm chữ
    CASE
        WHEN v_diem >= 90 THEN v_diemchu := 'A';
        WHEN v_diem >= 80 THEN v_diemchu := 'B';
        WHEN v_diem >= 70 THEN v_diemchu := 'C';
        WHEN v_diem >= 50 THEN v_diemchu := 'D';
        ELSE v_diemchu := 'F';
    END CASE;

    DBMS_OUTPUT.PUT_LINE('Diem: ' || v_diem || ' -> Diem chu: ' || v_diemchu);

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('Sinh vien chua dang ky lop nay!');
END;
/



-----------------------------------BAI 3----------------------------------------
SET SERVEROUTPUT ON;

DECLARE
    --cursor 1: duyệt môn học
    CURSOR cur_monhoc IS
        SELECT MaMon, TenMon
        FROM MONHOC
        ORDER BY MaMon;
    --cursor 2: lớp theo môn
    CURSOR cur_lop (p_mamon NUMBER) IS
        SELECT lh.MaLop,
               COUNT(dk.MaSV) AS so_sv
        FROM LOPHOC lh
        LEFT JOIN DANGKY dk ON lh.MaLop = dk.MaLop
        WHERE lh.MaMon = p_mamon
        GROUP BY lh.MaLop
        ORDER BY lh.MaLop;
    v_mamon MONHOC.MaMon%TYPE;
    v_tenmon MONHOC.TenMon%TYPE;
    v_malop LOPHOC.MaLop%TYPE;
    v_sosv NUMBER;

BEGIN
    --mở cursor ngoài
    OPEN cur_monhoc;

    LOOP
        FETCH cur_monhoc INTO v_mamon, v_tenmon;
        EXIT WHEN cur_monhoc%NOTFOUND;
        --in môn học
        DBMS_OUTPUT.PUT_LINE(v_mamon || ' ' || v_tenmon);
        --mở cursor trong 
        OPEN cur_lop(v_mamon);

        LOOP
            FETCH cur_lop INTO v_malop, v_sosv;
            EXIT WHEN cur_lop%NOTFOUND;

            DBMS_OUTPUT.PUT_LINE('  Lop: ' || v_malop ||
                                 ' co so luong sinh vien dang ki: ' || v_sosv);
        END LOOP;

        CLOSE cur_lop;

    END LOOP;

    CLOSE cur_monhoc;

EXCEPTION
    WHEN OTHERS THEN
        IF cur_monhoc%ISOPEN THEN CLOSE cur_monhoc; END IF;
        IF cur_lop%ISOPEN THEN CLOSE cur_lop; END IF;

        DBMS_OUTPUT.PUT_LINE('Loi: ' || SQLERRM);
END;
/



-----------------------------------BAI 4----------------------------------------
----------1
--a
CREATE OR REPLACE PROCEDURE find_sname
(
    i_student_id IN SINHVIEN.MaSV%TYPE,
    o_first_name OUT SINHVIEN.Ten%TYPE,
    o_last_name OUT SINHVIEN.Ho%TYPE
)
IS
BEGIN
    SELECT Ten, Ho
    INTO o_first_name, o_last_name
    FROM SINHVIEN
    WHERE MaSV = i_student_id;

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        o_first_name := NULL;
        o_last_name := NULL;
        DBMS_OUTPUT.PUT_LINE('Khong tim thay sinh vien!');
END;
/

--b
CREATE OR REPLACE PROCEDURE print_student_name
(
    i_student_id IN SINHVIEN.MaSV%TYPE
)
IS
    v_first SINHVIEN.Ten%TYPE;
    v_last SINHVIEN.Ho%TYPE;
BEGIN
    -- Gọi procedure kia
    find_sname(i_student_id, v_first, v_last);

    IF v_first IS NOT NULL OR v_last IS NOT NULL THEN
        DBMS_OUTPUT.PUT_LINE('Ho ten sinh vien: ' || v_last || ' ' || v_first);
    END IF;
END;
/

--test
BEGIN
    print_student_name(101);
END;
/

----------2
CREATE OR REPLACE PROCEDURE Discount
IS
BEGIN
    FOR rec IN (
        SELECT mh.MaMon, mh.TenMon, mh.HocPhi
        FROM MONHOC mh
        WHERE (
            SELECT COUNT(*)
            FROM DANGKY dk
            JOIN LOPHOC lh ON dk.MaLop = lh.MaLop
            WHERE lh.MaMon = mh.MaMon
        ) > 15
    ) LOOP

        UPDATE MONHOC
        SET HocPhi = HocPhi * 0.95
        WHERE MaMon = rec.MaMon;

        DBMS_OUTPUT.PUT_LINE(
            'Da giam gia mon: ' || rec.TenMon ||
            ' | Gia cu: ' || rec.HocPhi ||
            ' | Gia moi: ' || ROUND(rec.HocPhi * 0.95, 2)
        );

    END LOOP;

    COMMIT;

    DBMS_OUTPUT.PUT_LINE('Hoan tat giam gia!');

EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('Loi: ' || SQLERRM);
END;
/

--test
BEGIN
    Discount;
END;
/

----------3
CREATE OR REPLACE FUNCTION Total_cost_for_student
(
    p_student_id IN SINHVIEN.MaSV%TYPE
)
RETURN NUMBER
IS
    v_total NUMBER;
    v_check NUMBER;
BEGIN
    --kt SV tồn tại
    SELECT COUNT(*)
    INTO v_check
    FROM SINHVIEN
    WHERE MaSV = p_student_id;

    IF v_check = 0 THEN
        RETURN NULL;
    END IF;
    --tính tổng học phí
    SELECT NVL(SUM(mh.HocPhi), 0)
    INTO v_total
    FROM DANGKY dk
    JOIN LOPHOC lh ON dk.MaLop = lh.MaLop
    JOIN MONHOC mh ON lh.MaMon = mh.MaMon
    WHERE dk.MaSV = p_student_id;

    RETURN v_total;

EXCEPTION
    WHEN OTHERS THEN
        RETURN NULL;
END;
/

--test
BEGIN
    DBMS_OUTPUT.PUT_LINE('Tong chi phi: ' || Total_cost_for_student(101));
END;
/




-----------------------------------BAI 5----------------------------------------
----------1
--bảng MONHOC
CREATE OR REPLACE TRIGGER trg_monhoc_audit
BEFORE INSERT OR UPDATE ON MONHOC
FOR EACH ROW
BEGIN
    IF INSERTING THEN
        :NEW.NguoiTao := USER;
        :NEW.NgayTao := SYSDATE;
    END IF;
    :NEW.NguoiSua := USER;
    :NEW.NgaySua := SYSDATE;
END;
/

--bảng SINHVIEN
CREATE OR REPLACE TRIGGER trg_sinhvien_audit
BEFORE INSERT OR UPDATE ON SINHVIEN
FOR EACH ROW
BEGIN
    IF INSERTING THEN
        :NEW.NguoiTao := USER;
        :NEW.NgayTao := SYSDATE;
    END IF;

    :NEW.NguoiSua := USER;
    :NEW.NgaySua := SYSDATE;
END;
/

--bảng LOPHOC
CREATE OR REPLACE TRIGGER trg_lophoc_audit
BEFORE INSERT OR UPDATE ON LOPHOC
FOR EACH ROW
BEGIN
    IF INSERTING THEN
        :NEW.NguoiTao := USER;
        :NEW.NgayTao := SYSDATE;
    END IF;

    :NEW.NguoiSua := USER;
    :NEW.NgaySua := SYSDATE;
END;
/

--bảng DANGKY
CREATE OR REPLACE TRIGGER trg_dangky_audit
BEFORE INSERT OR UPDATE ON DANGKY
FOR EACH ROW
BEGIN
    IF INSERTING THEN
        :NEW.NguoiTao := USER;
        :NEW.NgayTao := SYSDATE;
    END IF;

    :NEW.NguoiSua := USER;
    :NEW.NgaySua := SYSDATE;
END;
/

--bảng GIAOVIEN
CREATE OR REPLACE TRIGGER trg_giaovien_audit
BEFORE INSERT OR UPDATE ON GIAOVIEN
FOR EACH ROW
BEGIN
    IF INSERTING THEN
        :NEW.NguoiTao := USER;
        :NEW.NgayTao := SYSDATE;
    END IF;

    :NEW.NguoiSua := USER;
    :NEW.NgaySua := SYSDATE;
END;
/

-- bảng DIEM
CREATE OR REPLACE TRIGGER trg_diem_audit
BEFORE INSERT OR UPDATE ON DIEM
FOR EACH ROW
BEGIN
    IF INSERTING THEN
        :NEW.NguoiTao := USER;
        :NEW.NgayTao := SYSDATE;
    END IF;

    :NEW.NguoiSua := USER;
    :NEW.NgaySua := SYSDATE;
END;
/

----------2
CREATE OR REPLACE TRIGGER trg_max_dangky
BEFORE INSERT ON DANGKY
FOR EACH ROW
DECLARE
    v_soluong NUMBER;
BEGIN
    --đếm số lớp hiện tại
    SELECT COUNT(*)
    INTO v_soluong
    FROM DANGKY
    WHERE MaSV = :NEW.MaSV;
    --nếu >= 3 thì chặn
    IF v_soluong >= 3 THEN
        RAISE_APPLICATION_ERROR(
            -20001,
            'Sinh vien da dang ky du 3 lop!'
        );
    END IF;
END;
/

--test
INSERT INTO DANGKY VALUES (101, 999, SYSDATE, 80, USER, SYSDATE, USER, SYSDATE);