---------------------------- PHIẾU BÀI TẬP 1 ----------------------------
CREATE TABLE Hang(
    Mahang VARCHAR2(10) PRIMARY KEY,
    Tenhang VARCHAR2(50),
    Soluong NUMBER,
    Giaban NUMBER
);

CREATE TABLE Hoadon(
    Mahd VARCHAR2(10) PRIMARY KEY,
    Mahang VARCHAR2(10),
    Soluongban NUMBER,
    Ngayban DATE
);

INSERT INTO Hang VALUES ('H01','Laptop',50,20000000);
INSERT INTO Hang VALUES ('H02','Chuot',100,200000);
INSERT INTO Hang VALUES ('H03','Ban phim',80,500000);

INSERT INTO Hoadon VALUES ('HD01','H01',5,SYSDATE);
INSERT INTO Hoadon VALUES ('HD02','H02',10,SYSDATE);
INSERT INTO Hoadon VALUES ('HD03','H03',8,SYSDATE);


SELECT * FROM Hang;
SELECT * FROM Hoadon;


-- 1. 
CREATE OR REPLACE TRIGGER trg_insert_hoadon
BEFORE INSERT ON hoadon
FOR EACH ROW
DECLARE
    v_dem NUMBER := 0;
    v_soluong NUMBER := 0;
BEGIN
    --kiểm tra Mahang có tồn tại
    SELECT COUNT(*) INTO v_dem
    FROM hang
    WHERE mahang = :NEW.mahang;

    IF v_dem = 0 THEN
        RAISE_APPLICATION_ERROR(-20001, 'Ma hang khong ton tai');
    END IF;

    --lấy số lượng tồn
    SELECT soluong INTO v_soluong
    FROM hang
    WHERE mahang = :NEW.mahang;

    --kiểm tra đủ hàng
    IF :NEW.soluongban > v_soluong THEN
        RAISE_APPLICATION_ERROR(-20002, 'So luong ban vuot qua ton kho');
    END IF;

    --trừ tồn kho
    UPDATE hang
    SET soluong = soluong - :NEW.soluongban
    WHERE mahang = :NEW.mahang;

END trg_insert_hoadon;
/

--test
INSERT INTO Hoadon VALUES ('HD04','H01',5,SYSDATE);
SELECT * FROM Hang;
SELECT * FROM Hoadon;


--2. 
CREATE OR REPLACE TRIGGER trg_delete_hoadon
AFTER DELETE ON hoadon
FOR EACH ROW
BEGIN
    UPDATE hang
    SET soluong = soluong + :OLD.soluongban
    WHERE mahang = :OLD.mahang;

END trg_delete_hoadon;
/

--test
DELETE FROM Hoadon
WHERE Mahd = 'HD04';

SELECT * FROM Hang;


--3. 
CREATE OR REPLACE TRIGGER trg_update_hoadon
BEFORE UPDATE ON hoadon
FOR EACH ROW
BEGIN
    UPDATE hang
    SET soluong = soluong - (:NEW.soluongban - :OLD.soluongban)
    WHERE mahang = :NEW.mahang;

END trg_update_hoadon;
/

--test
UPDATE hoadon
SET soluongban = 10
WHERE mahd = 'HD01';

SELECT * FROM Hang;
SELECT * FROM Hoadon;


---------------------------- PHIẾU BÀI TẬP 2 ----------------------------
CREATE TABLE Mathang (
    Mahang VARCHAR2(5) CONSTRAINT pk_mathang PRIMARY KEY,
    Tenhang VARCHAR2(50) NOT NULL,
    Soluong NUMBER(10)
);

CREATE TABLE Nhatkybanhang (
    Stt NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    Ngay DATE,
    Nguoimua VARCHAR2(50),
    Mahang VARCHAR2(5) REFERENCES Mathang(Mahang),
    Soluong NUMBER(10),
    Giaban NUMBER(15,2)
);

INSERT INTO Mathang VALUES ('1','Laptop Dell',100);
INSERT INTO Mathang VALUES ('2','Chuot Logitech',200);
INSERT INTO Mathang VALUES ('3','Ban phim Razer',150);
INSERT INTO Mathang VALUES ('4','Tai nghe Sony',120);
INSERT INTO Mathang VALUES ('5','Man hinh Samsung',80);

SELECT * FROM Mathang;

INSERT INTO Nhatkybanhang(Ngay,Nguoimua,Mahang,Soluong,Giaban)
VALUES (SYSDATE,'Nguyen Thi Kim Thi','1',2,25000000);
INSERT INTO Nhatkybanhang(Ngay,Nguoimua,Mahang,Soluong,Giaban)
VALUES (SYSDATE,'Nhan Anh Thu','2',5,300000);
INSERT INTO Nhatkybanhang(Ngay,Nguoimua,Mahang,Soluong,Giaban)
VALUES (SYSDATE,'Le Hai Trieu','3',3,1500000);
INSERT INTO Nhatkybanhang(Ngay,Nguoimua,Mahang,Soluong,Giaban)
VALUES (SYSDATE,'Pham Ngoc Thuy Trang','4',4,2000000);
INSERT INTO Nhatkybanhang(Ngay,Nguoimua,Mahang,Soluong,Giaban)
VALUES (SYSDATE,'Do Trung thien','5',2,7000000);

SELECT * FROM Nhatkybanhang;


--a. 
CREATE OR REPLACE TRIGGER trg_nhatkybanhang_insert
AFTER INSERT ON Nhatkybanhang
FOR EACH ROW
BEGIN
    UPDATE Mathang
    SET Soluong = Soluong - :NEW.Soluong
    WHERE Mahang = :NEW.Mahang;
END;
/

--test
INSERT INTO Nhatkybanhang(Ngay,Nguoimua,Mahang,Soluong,Giaban)
VALUES (SYSDATE,'Thu','1',5,10000);

SELECT * FROM Mathang;
SELECT * FROM Nhatkybanhang;


--b. 
CREATE OR REPLACE TRIGGER trg_nhatkybanhang_update_soluong
AFTER UPDATE OF Soluong ON Nhatkybanhang
FOR EACH ROW
BEGIN
    UPDATE Mathang
    SET Soluong = Soluong - (:NEW.Soluong - :OLD.Soluong)
    WHERE Mahang = :NEW.Mahang;
END;
/

--test
UPDATE Nhatkybanhang
SET Soluong = 10
WHERE Stt = 1;

SELECT * FROM Mathang;


--c.
CREATE OR REPLACE TRIGGER trg_check_soluong_insert
BEFORE INSERT ON Nhatkybanhang
FOR EACH ROW
DECLARE
    v_soluong NUMBER;
BEGIN
    SELECT Soluong INTO v_soluong
    FROM Mathang
    WHERE Mahang = :NEW.Mahang;

    IF :NEW.Soluong > v_soluong THEN
        RAISE_APPLICATION_ERROR(-20001,'So luong ban vuot qua ton kho');
    END IF;

    UPDATE Mathang
    SET Soluong = Soluong - :NEW.Soluong
    WHERE Mahang = :NEW.Mahang;
END;
/

--test
INSERT INTO Nhatkybanhang(Ngay,Nguoimua,Mahang,Soluong,Giaban)
VALUES (SYSDATE,'Thien','1',5000,10000);


--d. 
--package biến đếm
CREATE OR REPLACE PACKAGE pkg_state AS
    g_row_count NUMBER := 0;
END pkg_state;
/
--compound trigger UPDATE
CREATE OR REPLACE TRIGGER trg_update_limit
FOR UPDATE ON Nhatkybanhang
COMPOUND TRIGGER

BEFORE STATEMENT IS
BEGIN
    pkg_state.g_row_count := 0;
END BEFORE STATEMENT;

BEFORE EACH ROW IS
BEGIN
    pkg_state.g_row_count := pkg_state.g_row_count + 1;

    IF pkg_state.g_row_count > 1 THEN
        RAISE_APPLICATION_ERROR(-20002,'Chi duoc update 1 dong');
    END IF;

    UPDATE Mathang
    SET Soluong = Soluong - (:NEW.Soluong - :OLD.Soluong)
    WHERE Mahang = :NEW.Mahang;

END BEFORE EACH ROW;

END;
/

--test
UPDATE Nhatkybanhang
SET Soluong = Soluong + 1
WHERE Stt = 1;

SELECT * FROM Nhatkybanhang;


--e.
CREATE OR REPLACE TRIGGER trg_delete_limit
FOR DELETE ON Nhatkybanhang
COMPOUND TRIGGER

BEFORE STATEMENT IS
BEGIN
    pkg_state.g_row_count := 0;
END BEFORE STATEMENT;

BEFORE EACH ROW IS
BEGIN
    pkg_state.g_row_count := pkg_state.g_row_count + 1;

    IF pkg_state.g_row_count > 1 THEN
        RAISE_APPLICATION_ERROR(-20003,'Chi duoc xoa 1 dong');
    END IF;

    UPDATE Mathang
    SET Soluong = Soluong + :OLD.Soluong
    WHERE Mahang = :OLD.Mahang;

END BEFORE EACH ROW;

END;
/

--test
DELETE FROM Nhatkybanhang
WHERE Stt = 5;

SELECT * FROM Nhatkybanhang;


--f.
CREATE OR REPLACE TRIGGER trg_update_2
BEFORE UPDATE ON Nhatkybanhang
FOR EACH ROW
DECLARE
    v_soluong_ton NUMBER;
BEGIN

    --lấy số lượng tồn kho
    SELECT Soluong
    INTO v_soluong_ton
    FROM Mathang
    WHERE Mahang = :NEW.Mahang;

    --nếu số lượng cập nhật < tồn kho
    IF :NEW.Soluong < v_soluong_ton THEN
        RAISE_APPLICATION_ERROR(-20001,
        'So luong cap nhat nho hon ton kho');
    END IF;

    --nếu số lượng = tồn kho
    IF :NEW.Soluong = v_soluong_ton THEN
        RAISE_APPLICATION_ERROR(-20002,
        'So luong bang ton kho - khong can cap nhat');
    END IF;

    --nếu hợp lệ → cập nhật tồn kho
    UPDATE Mathang
    SET Soluong = Soluong - (:NEW.Soluong - :OLD.Soluong)
    WHERE Mahang = :NEW.Mahang;

END;
/

--test
UPDATE Nhatkybanhang
SET Soluong = 20
WHERE Stt = 3;


--g. 
CREATE OR REPLACE PROCEDURE sp_xoa_mathang (
    p_mahang IN VARCHAR2
)
AS
    v_dem NUMBER;
BEGIN

    --kiểm tra mặt hàng có tồn tại ko
    SELECT COUNT(*)
    INTO v_dem
    FROM Mathang
    WHERE Mahang = p_mahang;

    IF v_dem = 0 THEN
        DBMS_OUTPUT.PUT_LINE('Ma hang khong ton tai');
    ELSE

        --xóa dữ liệu liên quan trước
        DELETE FROM Nhatkybanhang
        WHERE Mahang = p_mahang;

        --xóa mặt hàng
        DELETE FROM Mathang
        WHERE Mahang = p_mahang;

        DBMS_OUTPUT.PUT_LINE('Da xoa mat hang thanh cong');

    END IF;

END;
/

--test
EXEC sp_xoa_mathang('2');

SELECT * FROM Mathang;
SELECT * FROM Nhatkybanhang;



--h.
CREATE OR REPLACE FUNCTION fn_tongtien (
    p_tenhang IN VARCHAR2
)
RETURN NUMBER
AS
    v_tong NUMBER;
BEGIN

    SELECT SUM(nk.Soluong * nk.Giaban)
    INTO v_tong
    FROM Nhatkybanhang nk
    JOIN Mathang mh
    ON nk.Mahang = mh.Mahang
    WHERE mh.Tenhang = p_tenhang;

    RETURN NVL(v_tong,0);

END;
/

--test
SELECT fn_tongtien('Laptop Dell')
FROM dual;

SELECT * FROM Nhatkybanhang;


---------------------------- PHIẾU BÀI TẬP 3 ----------------------------
CREATE TABLE Lophoc (
    Malop VARCHAR2(5) PRIMARY KEY,
    Tenlop VARCHAR2(50),
    Sisotoida NUMBER,
    Sisohientai NUMBER
);

CREATE TABLE Dangky (
    Madk NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    Masv VARCHAR2(10),
    Malop VARCHAR2(5),
    Ngaydangky DATE
);

INSERT INTO Lophoc VALUES ('L01','Lap trinh Java',30,2);
INSERT INTO Lophoc VALUES ('L02','Co so du lieu',25,1);
INSERT INTO Lophoc VALUES ('L03','Tri tue nhan tao',20,0);

INSERT INTO Dangky(Masv,Malop,Ngaydangky) VALUES ('SV01','L01',SYSDATE);
INSERT INTO Dangky(Masv,Malop,Ngaydangky) VALUES ('SV02','L01',SYSDATE);
INSERT INTO Dangky(Masv,Malop,Ngaydangky) VALUES ('SV03','L02',SYSDATE);

SELECT * FROM Lophoc;
SELECT * FROM Dangky;


--1. 
CREATE OR REPLACE TRIGGER trg_dangky_insert
BEFORE INSERT ON Dangky
FOR EACH ROW
DECLARE
    v_dem NUMBER;
    v_hientai NUMBER;
    v_toida NUMBER;
BEGIN
    --kiểm tra lớp tồn tại
    SELECT COUNT(*)
    INTO v_dem
    FROM Lophoc
    WHERE Malop = :NEW.Malop;

    IF v_dem = 0 THEN
        RAISE_APPLICATION_ERROR(-20001,'Lop khong ton tai');
    END IF;

    --kiểm tra sinh viên đã đăng ký chưa
    SELECT COUNT(*)
    INTO v_dem
    FROM Dangky
    WHERE Masv = :NEW.Masv
    AND Malop = :NEW.Malop;

    IF v_dem > 0 THEN
        RAISE_APPLICATION_ERROR(-20002,'Sinh vien da dang ky lop nay');
    END IF;

    --kiểm tra sĩ số
    SELECT Sisohientai, Sisotoida
    INTO v_hientai, v_toida
    FROM Lophoc
    WHERE Malop = :NEW.Malop;

    IF v_hientai >= v_toida THEN
        RAISE_APPLICATION_ERROR(-20003,'Lop da day');
    END IF;

    --tăng sỉ số
    UPDATE Lophoc
    SET Sisohientai = Sisohientai + 1
    WHERE Malop = :NEW.Malop;

END;
/

--test
INSERT INTO Dangky(Masv,Malop,Ngaydangky)
VALUES ('SV04','L01',SYSDATE);

SELECT * FROM Lophoc;
SELECT * FROM Dangky;


--2.
CREATE OR REPLACE TRIGGER trg_dangky_delete
AFTER DELETE ON Dangky
FOR EACH ROW
BEGIN

    UPDATE Lophoc
    SET Sisohientai = Sisohientai - 1
    WHERE Malop = :OLD.Malop;

END;
/

--test 
DELETE FROM Dangky
WHERE Masv = 'SV03';

SELECT * FROM Lophoc;


--3. 
CREATE OR REPLACE TRIGGER trg_dangky_update
BEFORE UPDATE ON Dangky
FOR EACH ROW
DECLARE
    v_dem NUMBER;
    v_hientai NUMBER;
    v_toida NUMBER;
BEGIN

    --nếu không đổi lớp thì bỏ qua
    IF :OLD.Malop = :NEW.Malop THEN
        RETURN;
    END IF;

    --kiểm tra lớp mới tồn tại
    SELECT COUNT(*)
    INTO v_dem
    FROM Lophoc
    WHERE Malop = :NEW.Malop;

    IF v_dem = 0 THEN
        RAISE_APPLICATION_ERROR(-20004,'Lop moi khong ton tai');
    END IF;

    --kiểm tra sĩ số lớp mới
    SELECT Sisohientai, Sisotoida
    INTO v_hientai, v_toida
    FROM Lophoc
    WHERE Malop = :NEW.Malop;

    IF v_hientai >= v_toida THEN
        RAISE_APPLICATION_ERROR(-20005,'Lop moi da day');
    END IF;

    --giảm sĩ số lớp cũ
    UPDATE Lophoc
    SET Sisohientai = Sisohientai - 1
    WHERE Malop = :OLD.Malop;

    --tăng sĩ số lớp mới
    UPDATE Lophoc
    SET Sisohientai = Sisohientai + 1
    WHERE Malop = :NEW.Malop;

END;
/

--test
UPDATE Dangky
SET Malop = 'L03'
WHERE Masv = 'SV04';

SELECT * FROM Lophoc;
SELECT * FROM Dangky;