-----------------------TẠO BẢNG-----------------------------
CREATE TABLE HangSX (
    MaHangSX VARCHAR2(10) CONSTRAINT pk_hangsx PRIMARY KEY,
    TenHang VARCHAR2(30) NOT NULL,
    DiaChi VARCHAR2(50),
    SoDT VARCHAR2(15),
    Email VARCHAR2(50)
);

CREATE TABLE SanPham (
    MaSP VARCHAR2(10) CONSTRAINT pk_sanpham PRIMARY KEY,
    MaHangSX VARCHAR2(10) REFERENCES HangSX(MaHangSX),
    TenSP VARCHAR2(50) NOT NULL,
    SoLuong NUMBER(10),
    MauSac VARCHAR2(20),
    GiaBan NUMBER(15,2),
    DonViTinh VARCHAR2(15),
    MoTa CLOB
);

CREATE TABLE NhanVien (
    MaNV VARCHAR2(10) CONSTRAINT pk_nhanvien PRIMARY KEY,
    TenNV VARCHAR2(50) NOT NULL,
    GioiTinh VARCHAR2(10),
    DiaChi VARCHAR2(100),
    SoDT VARCHAR2(15),
    Email VARCHAR2(50),
    TenPhong VARCHAR2(30)
);

CREATE TABLE PNhap (
    SoHDN VARCHAR2(10) CONSTRAINT pk_pnhap PRIMARY KEY,
    NgayNhap DATE,
    MaNV VARCHAR2(10) REFERENCES NhanVien(MaNV)
);

CREATE TABLE Nhap (
    SoHDN VARCHAR2(10) REFERENCES PNhap(SoHDN),
    MaSP VARCHAR2(10) REFERENCES SanPham(MaSP),
    SoLuongN NUMBER(10),
    DonGiaN NUMBER(15,2),
    CONSTRAINT pk_nhap PRIMARY KEY (SoHDN, MaSP)
);

CREATE TABLE PXuat (
    SoHDX VARCHAR2(10) CONSTRAINT pk_pxuat PRIMARY KEY,
    NgayXuat DATE,
    MaNV VARCHAR2(10) REFERENCES NhanVien(MaNV)
);

CREATE TABLE Xuat (
    SoHDX VARCHAR2(10) REFERENCES PXuat(SoHDX),
    MaSP VARCHAR2(10) REFERENCES SanPham(MaSP),
    SoLuongX NUMBER(10),
    CONSTRAINT pk_xuat PRIMARY KEY (SoHDX, MaSP)
);


-----------------------PHIẾU BÀI TẬP 1 -----------------------------
--a.Thủ tục sp_NhapHangSX
CREATE OR REPLACE PROCEDURE sp_NhapHangSX(
    p_mahangsx IN VARCHAR2,
    p_tenhang IN VARCHAR2,
    p_diachi IN VARCHAR2,
    p_sodt IN VARCHAR2,
    p_email IN VARCHAR2,
    p_kq OUT NUMBER
)
AS
    v_count NUMBER;
BEGIN

    SELECT COUNT(*) INTO v_count
    FROM HangSX
    WHERE TenHang = p_tenhang;
    IF v_count > 0 THEN
        p_kq := 1;
        RETURN;
    END IF;

    INSERT INTO HangSX
    VALUES(p_mahangsx,p_tenhang,p_diachi,p_sodt,p_email);

    p_kq := 0;
    COMMIT;

END;
/

--test
DECLARE
    v_kq NUMBER;
BEGIN
    sp_NhapHangSX('HS01', 'Iphone', '17A Nguyễn Văn Bứa, TPHCM', '0985672453', 'iphonebd@gmail.com', v_kq);
    DBMS_OUTPUT.PUT_LINE('Ket qua: ' || v_kq);
END;
/
SELECT * FROM HangSX;

--b.Thủ tục sp_NhapSP
CREATE OR REPLACE PROCEDURE sp_NhapSP(
    p_masp IN VARCHAR2,
    p_tenhang IN VARCHAR2,
    p_tensp IN VARCHAR2,
    p_soluong IN NUMBER,
    p_mausac IN VARCHAR2,
    p_giaban IN NUMBER,
    p_donvitinh IN VARCHAR2,
    p_mota IN CLOB,
    p_kq OUT NUMBER
)
AS
    v_mahang VARCHAR2(10);
    v_count NUMBER;
BEGIN

    SELECT MaHangSX INTO v_mahang
    FROM HangSX
    WHERE TenHang = p_tenhang;
    SELECT COUNT(*) INTO v_count
    FROM SanPham
    WHERE MaSP = p_masp;

    IF v_count > 0 THEN

        UPDATE SanPham
        SET MaHangSX = v_mahang,
            TenSP = p_tensp,
            SoLuong = p_soluong,
            MauSac = p_mausac,
            GiaBan = p_giaban,
            DonViTinh = p_donvitinh,
            MoTa = p_mota
        WHERE MaSP = p_masp;

    ELSE

        INSERT INTO SanPham
        VALUES(p_masp,v_mahang,p_tensp,p_soluong,p_mausac,p_giaban,p_donvitinh,p_mota);

    END IF;

    p_kq := 0;
    COMMIT;

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        p_kq := 2;
END;
/

--test
DECLARE
    v_kq NUMBER;
BEGIN
    sp_NhapSP('SP01', 'Iphone', 'Iphone 17 Promax 1T', 50, 'Cam', 60000000, 'Cai',  'Điện thoại cao cấp, thiết kế sang trọng', v_kq);
    DBMS_OUTPUT.PUT_LINE('Ket qua: ' || v_kq);
END;
/
SELECT * FROM SanPham;

--c.Thủ tục sp_xoaHangSX
CREATE OR REPLACE PROCEDURE sp_xoaHangSX(
    p_tenhang IN VARCHAR2,
    p_kq OUT NUMBER
)
AS
    v_mahang VARCHAR2(10);
BEGIN

    SELECT MaHangSX INTO v_mahang
    FROM HangSX
    WHERE TenHang = p_tenhang;

    DELETE FROM SanPham
    WHERE MaHangSX = v_mahang;

    DELETE FROM HangSX
    WHERE MaHangSX = v_mahang;

    p_kq := 0;

    COMMIT;

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        p_kq := 1;
END;
/

--test
DECLARE
    v_kq NUMBER;
BEGIN
    sp_xoaHangSX('Iphone', v_kq);
    DBMS_OUTPUT.PUT_LINE('Ket qua: ' || v_kq);
END;
/
SELECT * FROM HangSX;
SELECT * FROM SanPham;

--d. Thủ tục nhập dữ liệu NhanVien (có biến FLAG)
CREATE OR REPLACE PROCEDURE sp_NhanVien(
    p_manv IN VARCHAR2,
    p_tennv IN VARCHAR2,
    p_gioitinh IN VARCHAR2,
    p_diachi IN VARCHAR2,
    p_sodt IN VARCHAR2,
    p_email IN VARCHAR2,
    p_tenphong IN VARCHAR2,
    p_flag IN NUMBER,
    p_kq OUT NUMBER
)
AS
BEGIN

    IF p_flag = 0 THEN

        UPDATE NhanVien
        SET TenNV = p_tennv,
            GioiTinh = p_gioitinh,
            DiaChi = p_diachi,
            SoDT = p_sodt,
            Email = p_email,
            TenPhong = p_tenphong
        WHERE MaNV = p_manv;

    ELSE

        INSERT INTO NhanVien
        VALUES(p_manv,p_tennv,p_gioitinh,p_diachi,p_sodt,p_email,p_tenphong);

    END IF;

    p_kq := 0;
    COMMIT;

END;
/

--test
--insert (flag != 0)
DECLARE
    v_kq NUMBER;
BEGIN
    sp_NhanVien('NV01', 'Đoàn Ngọc Phương Thanh', 'Nữ', 'HCM', '0337645255', '1250080174@sv.hcmunre.edu.vn', 'Kế toán', 1, v_kq);
    DBMS_OUTPUT.PUT_LINE('Ket qua: ' || v_kq);
END;
/
--update (flag = 0)
DECLARE
    v_kq NUMBER;
BEGIN
    sp_NhanVien('NV02', 'Đoàn Ngọc Phương Trinh', 'Nữ', 'HCM', '0337645255', '1250080174@sv.hcmunre.edu.vn', 'Kế toán', 1, v_kq); 
    DBMS_OUTPUT.PUT_LINE('Ket qua: ' || v_kq);
END;
/
SELECT * FROM NhanVien;

--e. Thủ tục nhập dữ liệu bảng Nhap
CREATE OR REPLACE PROCEDURE sp_Nhap(
    p_sohdn IN VARCHAR2,
    p_masp IN VARCHAR2,
    p_manv IN VARCHAR2,
    p_ngaynhap IN DATE,
    p_soluongn IN NUMBER,
    p_dongian IN NUMBER,
    p_kq OUT NUMBER
)
AS
    v_count NUMBER;
BEGIN

    SELECT COUNT(*) INTO v_count FROM SanPham WHERE MaSP = p_masp;
    IF v_count = 0 THEN
        p_kq := 1;
        RETURN;
    END IF;

    SELECT COUNT(*) INTO v_count FROM NhanVien WHERE MaNV = p_manv;
    IF v_count = 0 THEN
        p_kq := 2;
        RETURN;
    END IF;

    SELECT COUNT(*) INTO v_count FROM PNhap WHERE SoHDN = p_sohdn;

    IF v_count > 0 THEN

        UPDATE Nhap
        SET SoLuongN = p_soluongn,
            DonGiaN = p_dongian
        WHERE SoHDN = p_sohdn
        AND MaSP = p_masp;

    ELSE

        INSERT INTO PNhap VALUES(p_sohdn,p_ngaynhap,p_manv);

        INSERT INTO Nhap
        VALUES(p_sohdn,p_masp,p_soluongn,p_dongian);

    END IF;

    p_kq := 0;

    COMMIT;

END;
/

--test
DECLARE
    v_kq NUMBER;
BEGIN
    sp_Nhap('HDN01', 'SP01', 'NV01', SYSDATE, 10, 15000000, v_kq);
    DBMS_OUTPUT.PUT_LINE('Ket qua: ' || v_kq);
END;
/
SELECT * FROM PNhap;
SELECT * FROM Nhap;

--f. Thủ tục nhập dữ liệu bảng Xuat
CREATE OR REPLACE PROCEDURE sp_Xuat(
    p_sohdx IN VARCHAR2,
    p_masp IN VARCHAR2,
    p_manv IN VARCHAR2,
    p_ngayxuat IN DATE,
    p_soluongx IN NUMBER,
    p_kq OUT NUMBER
)
AS
    v_count NUMBER;
    v_soluong NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_count FROM SanPham WHERE MaSP = p_masp;
    IF v_count = 0 THEN
        p_kq := 1;
        RETURN;
    END IF;
    SELECT COUNT(*) INTO v_count FROM NhanVien WHERE MaNV = p_manv;
    IF v_count = 0 THEN
        p_kq := 2;
        RETURN;
    END IF;
    SELECT SoLuong INTO v_soluong
    FROM SanPham
    WHERE MaSP = p_masp;

    IF p_soluongx > v_soluong THEN
        p_kq := 3;
        RETURN;
    END IF;
    SELECT COUNT(*) INTO v_count FROM PXuat WHERE SoHDX = p_sohdx;
    IF v_count > 0 THEN

        UPDATE Xuat
        SET SoLuongX = p_soluongx
        WHERE SoHDX = p_sohdx
        AND MaSP = p_masp;

    ELSE

        INSERT INTO PXuat VALUES(p_sohdx,p_ngayxuat,p_manv);

        INSERT INTO Xuat VALUES(p_sohdx,p_masp,p_soluongx);

    END IF;
    UPDATE SanPham
    SET SoLuong = SoLuong - p_soluongx
    WHERE MaSP = p_masp;
    p_kq := 0;
    COMMIT;
END;
/

--test
DECLARE
    v_kq NUMBER;
BEGIN
    sp_Xuat(
        'HDX01',
        'SP01',
        'NV01',
        SYSDATE,
        5,
        v_kq
    );
    DBMS_OUTPUT.PUT_LINE('Ket qua: ' || v_kq);
END;
/
SELECT * FROM PXuat;
SELECT * FROM Xuat;
SELECT * FROM SanPham;

--g. Thủ tục xóa NhanVien
CREATE OR REPLACE PROCEDURE sp_xoaNhanVien(
    p_manv IN VARCHAR2,
    p_kq OUT NUMBER
)
AS
    v_count NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_count
    FROM NhanVien
    WHERE MaNV = p_manv;

    IF v_count = 0 THEN
        p_kq := 1;
        RETURN;
    END IF;
    DELETE FROM Nhap
    WHERE SoHDN IN (SELECT SoHDN FROM PNhap WHERE MaNV = p_manv);
    DELETE FROM Xuat
    WHERE SoHDX IN (SELECT SoHDX FROM PXuat WHERE MaNV = p_manv);
    DELETE FROM PNhap WHERE MaNV = p_manv;
    DELETE FROM PXuat WHERE MaNV = p_manv;
    DELETE FROM NhanVien WHERE MaNV = p_manv;
    p_kq := 0;

    COMMIT;
END;
/

--test
DECLARE
    v_kq NUMBER;
BEGIN
    sp_xoaNhanVien(
        'NV01',
        v_kq
    );
    DBMS_OUTPUT.PUT_LINE('Ket qua: ' || v_kq);
END;
/
SELECT * FROM NhanVien;

--h. Thủ tục xóa SanPham
CREATE OR REPLACE PROCEDURE sp_xoaSanPham(
    p_masp IN VARCHAR2,
    p_kq OUT NUMBER
)
AS
    v_count NUMBER;
BEGIN

    SELECT COUNT(*) INTO v_count
    FROM SanPham
    WHERE MaSP = p_masp;

    IF v_count = 0 THEN
        p_kq := 1;
        RETURN;
    END IF;

    DELETE FROM Nhap WHERE MaSP = p_masp;

    DELETE FROM Xuat WHERE MaSP = p_masp;

    DELETE FROM SanPham WHERE MaSP = p_masp;

    p_kq := 0;

    COMMIT;

END;
/

--test
DECLARE
    v_kq NUMBER;
BEGIN
    sp_xoaSanPham(
        'SP01',
        v_kq
    );
    DBMS_OUTPUT.PUT_LINE('Ket qua: ' || v_kq);
END;
/
SELECT * FROM SanPham;


-----------------------PHIẾU BÀI TẬP 2 -----------------------------
--a. Thủ tục sp_ThemNhanVien (có OUT)
CREATE OR REPLACE PROCEDURE sp_ThemNhanVien(
    p_manv IN VARCHAR2,
    p_tennv IN VARCHAR2,
    p_gioitinh IN VARCHAR2,
    p_diachi IN VARCHAR2,
    p_sodt IN VARCHAR2,
    p_email IN VARCHAR2,
    p_tenphong IN VARCHAR2,
    p_flag IN NUMBER,
    p_kq OUT NUMBER
)
AS
BEGIN

    IF p_gioitinh <> 'Nam' AND p_gioitinh <> 'Nữ' THEN
        p_kq := 1;
        RETURN;
    END IF;

    IF p_flag = 0 THEN
        INSERT INTO NhanVien
        VALUES(p_manv,p_tennv,p_gioitinh,p_diachi,p_sodt,p_email,p_tenphong);
    ELSE
        UPDATE NhanVien
        SET TenNV = p_tennv,
            GioiTinh = p_gioitinh,
            DiaChi = p_diachi,
            SoDT = p_sodt,
            Email = p_email,
            TenPhong = p_tenphong
        WHERE MaNV = p_manv;
    END IF;

    p_kq := 0;
    COMMIT;

END;
/

--test
DECLARE
    v_kq NUMBER;
BEGIN
    sp_ThemNhanVien('NV05', 'Đoàn Công Thức', 'Nam', 'HCM', '0356644177', 'dcthuc@gmail.com', 'Quản lý', 0, v_kq);
    DBMS_OUTPUT.PUT_LINE('Ket qua: ' || v_kq);
END;
/
SELECT * FROM NhanVien;

--b. Thủ tục sp_ThemMoiSP (có OUT)
CREATE OR REPLACE PROCEDURE sp_ThemMoiSP(
    p_masp IN VARCHAR2,
    p_tenhang IN VARCHAR2,
    p_tensp IN VARCHAR2,
    p_soluong IN NUMBER,
    p_mausac IN VARCHAR2,
    p_giaban IN NUMBER,
    p_donvitinh IN VARCHAR2,
    p_mota IN CLOB,
    p_flag IN NUMBER,
    p_kq OUT NUMBER
)
AS
    v_mahang VARCHAR2(10);
BEGIN

    SELECT MaHangSX INTO v_mahang
    FROM HangSX
    WHERE TenHang = p_tenhang;

    IF p_soluong < 0 THEN
        p_kq := 2;
        RETURN;
    END IF;

    IF p_flag = 0 THEN
        INSERT INTO SanPham
        VALUES(p_masp,v_mahang,p_tensp,p_soluong,p_mausac,p_giaban,p_donvitinh,p_mota);
    ELSE
        UPDATE SanPham
        SET MaHangSX = v_mahang,
            TenSP = p_tensp,
            SoLuong = p_soluong,
            MauSac = p_mausac,
            GiaBan = p_giaban,
            DonViTinh = p_donvitinh,
            MoTa = p_mota
        WHERE MaSP = p_masp;
    END IF;

    p_kq := 0;
    COMMIT;

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        p_kq := 1;
END;
/

--test
DECLARE
    v_kq NUMBER;
BEGIN
    sp_ThemMoiSP('SP05', 'Samsung', 'Galaxy S24', 50, 'Den', 25000000, 'Cai', 'Dien thoai Samsung AI', 0, v_kq);
    DBMS_OUTPUT.PUT_LINE('Ket qua: ' || v_kq);
END;
/

--c.Thủ tục xóa NhanVien (có OUT)
CREATE OR REPLACE PROCEDURE sp_XoaNhanVien(
    p_manv IN VARCHAR2,
    p_kq OUT NUMBER
)
AS
    v_count NUMBER;
BEGIN

    SELECT COUNT(*) INTO v_count
    FROM NhanVien
    WHERE MaNV = p_manv;

    IF v_count = 0 THEN
        p_kq := 1;
        RETURN;
    END IF;

    DELETE FROM Nhap
    WHERE SoHDN IN (SELECT SoHDN FROM PNhap WHERE MaNV = p_manv);

    DELETE FROM Xuat
    WHERE SoHDX IN (SELECT SoHDX FROM PXuat WHERE MaNV = p_manv);

    DELETE FROM PNhap WHERE MaNV = p_manv;

    DELETE FROM PXuat WHERE MaNV = p_manv;

    DELETE FROM NhanVien WHERE MaNV = p_manv;

    p_kq := 0;

    COMMIT;

END;
/

--d. Thủ tục xóa SanPham (có OUT)
CREATE OR REPLACE PROCEDURE sp_XoaSanPham(
    p_masp IN VARCHAR2,
    p_kq OUT NUMBER
)
AS
    v_count NUMBER;
BEGIN

    SELECT COUNT(*) INTO v_count
    FROM SanPham
    WHERE MaSP = p_masp;

    IF v_count = 0 THEN
        p_kq := 1;
        RETURN;
    END IF;

    DELETE FROM Nhap WHERE MaSP = p_masp;
    DELETE FROM Xuat WHERE MaSP = p_masp;

    DELETE FROM SanPham WHERE MaSP = p_masp;

    p_kq := 0;

    COMMIT;

END;
/

--e. Thủ tục sp_NhapHangSX (có OUT)
CREATE OR REPLACE PROCEDURE sp_NhapHangSX(
    p_mahangsx IN VARCHAR2,
    p_tenhang IN VARCHAR2,
    p_diachi IN VARCHAR2,
    p_sodt IN VARCHAR2,
    p_email IN VARCHAR2,
    p_kq OUT NUMBER
)
AS
    v_count NUMBER;
BEGIN

    SELECT COUNT(*) INTO v_count
    FROM HangSX
    WHERE TenHang = p_tenhang;

    IF v_count > 0 THEN
        p_kq := 1;
        RETURN;
    END IF;

    INSERT INTO HangSX
    VALUES(p_mahangsx,p_tenhang,p_diachi,p_sodt,p_email);

    p_kq := 0;
    COMMIT;

END;
/

--f. Thủ tục nhập bảng Nhap (có OUT)
CREATE OR REPLACE PROCEDURE sp_Nhap(
    p_sohdn IN VARCHAR2,
    p_masp IN VARCHAR2,
    p_manv IN VARCHAR2,
    p_ngaynhap IN DATE,
    p_soluongn IN NUMBER,
    p_dongian IN NUMBER,
    p_kq OUT NUMBER
)
AS
    v_count NUMBER;
BEGIN

    SELECT COUNT(*) INTO v_count FROM SanPham WHERE MaSP = p_masp;
    IF v_count = 0 THEN
        p_kq := 1;
        RETURN;
    END IF;

    SELECT COUNT(*) INTO v_count FROM NhanVien WHERE MaNV = p_manv;
    IF v_count = 0 THEN
        p_kq := 2;
        RETURN;
    END IF;

    SELECT COUNT(*) INTO v_count FROM PNhap WHERE SoHDN = p_sohdn;

    IF v_count > 0 THEN

        UPDATE Nhap
        SET SoLuongN = p_soluongn,
            DonGiaN = p_dongian
        WHERE SoHDN = p_sohdn
        AND MaSP = p_masp;

    ELSE

        INSERT INTO PNhap VALUES(p_sohdn,p_ngaynhap,p_manv);

        INSERT INTO Nhap VALUES(p_sohdn,p_masp,p_soluongn,p_dongian);

    END IF;

    p_kq := 0;
    COMMIT;

END;
/

--g. Thủ tục nhập bảng Xuat (có OUT)
CREATE OR REPLACE PROCEDURE sp_Xuat(
    p_sohdx IN VARCHAR2,
    p_masp IN VARCHAR2,
    p_manv IN VARCHAR2,
    p_ngayxuat IN DATE,
    p_soluongx IN NUMBER,
    p_kq OUT NUMBER
)
AS
    v_count NUMBER;
    v_soluong NUMBER;
BEGIN

    SELECT COUNT(*) INTO v_count FROM SanPham WHERE MaSP = p_masp;
    IF v_count = 0 THEN
        p_kq := 1;
        RETURN;
    END IF;

    SELECT COUNT(*) INTO v_count FROM NhanVien WHERE MaNV = p_manv;
    IF v_count = 0 THEN
        p_kq := 2;
        RETURN;
    END IF;

    SELECT SoLuong INTO v_soluong
    FROM SanPham
    WHERE MaSP = p_masp;

    IF p_soluongx > v_soluong THEN
        p_kq := 3;
        RETURN;
    END IF;

    SELECT COUNT(*) INTO v_count FROM PXuat WHERE SoHDX = p_sohdx;

    IF v_count > 0 THEN

        UPDATE Xuat
        SET SoLuongX = p_soluongx
        WHERE SoHDX = p_sohdx
        AND MaSP = p_masp;

    ELSE

        INSERT INTO PXuat VALUES(p_sohdx,p_ngayxuat,p_manv);

        INSERT INTO Xuat VALUES(p_sohdx,p_masp,p_soluongx);

    END IF;

    p_kq := 0;

    COMMIT;

END;
/