show user;

------------------------------------VIEW----------------------------------------
--1.1
CREATE OR REPLACE VIEW vw_tongquan_monhoc AS
SELECT mh.mamon,
       mh.tenmon,
       mh.hocphi,
       COUNT(DISTINCT lh.malop) AS so_lop,
       COUNT(dk.masv) AS tong_sv
FROM MONHOC mh
LEFT JOIN LOPHOC lh ON mh.mamon = lh.mamon
LEFT JOIN DANGKY dk ON lh.malop = dk.malop
GROUP BY mh.mamon, mh.tenmon, mh.hocphi;

--test
SELECT * FROM vw_tongquan_monhoc;

--1.2
CREATE OR REPLACE VIEW vw_sinhvien_status AS
SELECT sv.masv,
       sv.ho || ' ' || sv.ten AS hoten,
       COUNT(dk.malop) AS so_lop,
       NVL(SUM(mh.hocphi),0) AS tong_tien
FROM SINHVIEN sv
JOIN DANGKY dk ON sv.masv = dk.masv
JOIN LOPHOC lh ON dk.malop = lh.malop
JOIN MONHOC mh ON lh.mamon = mh.mamon
GROUP BY sv.masv, sv.ho, sv.ten;

--test
SELECT * FROM vw_sinhvien_status;

--1.3
CREATE OR REPLACE VIEW vw_lophoc_concho AS
SELECT lh.malop,
       lh.mamon,
       mh.tenmon,
       lh.succhua,
       COUNT(dk.masv) AS so_dadangky,
       lh.succhua - COUNT(dk.masv) AS cho_trong,
       CASE 
           WHEN lh.succhua - COUNT(dk.masv) > 0 THEN 'Con cho'
           ELSE 'Het cho'
       END AS trangthai
FROM LOPHOC lh
JOIN MONHOC mh ON lh.mamon = mh.mamon
LEFT JOIN DANGKY dk ON lh.malop = dk.malop
GROUP BY lh.malop, lh.mamon, mh.tenmon, lh.succhua
HAVING lh.succhua - COUNT(dk.masv) > 0;

--test
SELECT * FROM vw_lophoc_concho;

--1.4
CREATE OR REPLACE VIEW vw_top_monhoc AS
SELECT mamon, tenmon, hocphi, tong_dk, hang
FROM (
    SELECT mh.mamon,
           mh.tenmon,
           mh.hocphi,
           COUNT(dk.masv) AS tong_dk,
           RANK() OVER (ORDER BY COUNT(dk.masv) DESC) AS hang
    FROM MONHOC mh
    LEFT JOIN LOPHOC lh ON mh.mamon = lh.mamon
    LEFT JOIN DANGKY dk ON lh.malop = dk.malop
    GROUP BY mh.mamon, mh.tenmon, mh.hocphi
)
WHERE hang <= 5
WITH READ ONLY;

--test
SELECT * FROM vw_top_monhoc;

--1.5
CREATE OR REPLACE VIEW vw_dangky_chuadiem AS
SELECT masv,
       malop,
       ngaydangky,
       diemtongket,
       nguoitao,
       ngaytao,
       nguoisua,
       ngaysua
FROM DANGKY
WHERE diemtongket IS NULL
WITH CHECK OPTION;

--test
INSERT INTO vw_dangky_chuadiem
(masv, malop, ngaydangky, nguoitao, ngaytao, nguoisua, ngaysua)
VALUES (103, 1, SYSDATE, USER, SYSDATE, USER, SYSDATE);

SELECT * FROM vw_dangky_chuadiem;


----------------------------------PROCEDURE-------------------------------------
--2.1
CREATE OR REPLACE PROCEDURE enroll_student
(
    p_masv  IN NUMBER,
    p_malop IN NUMBER
)
IS
    v_check     NUMBER;
    v_succhua   NUMBER;
    v_dadangky  NUMBER;
BEGIN
    --dk1: SV ton tai
    SELECT COUNT(*) INTO v_check 
    FROM SINHVIEN 
    WHERE masv = p_masv;

    IF v_check = 0 THEN
        DBMS_OUTPUT.PUT_LINE('[LOI] Sinh vien ' || p_masv || ' khong ton tai!');
        RETURN;
    END IF;

    --dk2: Lop hoc ton tai
    SELECT COUNT(*) INTO v_check 
    FROM LOPHOC 
    WHERE malop = p_malop;

    IF v_check = 0 THEN
        DBMS_OUTPUT.PUT_LINE('[LOI] Lop hoc ' || p_malop || ' khong ton tai!');
        RETURN;
    END IF;

    --dk3: KT con cho
    SELECT succhua INTO v_succhua 
    FROM LOPHOC 
    WHERE malop = p_malop;

    SELECT COUNT(*) INTO v_dadangky 
    FROM DANGKY 
    WHERE malop = p_malop;

    IF v_dadangky >= v_succhua THEN
        DBMS_OUTPUT.PUT_LINE('[LOI] Lop ' || p_malop || ' da day! (' 
                             || v_dadangky || '/' || v_succhua || ')');
        RETURN;
    END IF;

    --dk4: SV chua dang ky lop nay
    SELECT COUNT(*) INTO v_check 
    FROM DANGKY
    WHERE masv = p_masv AND malop = p_malop;

    IF v_check > 0 THEN
        DBMS_OUTPUT.PUT_LINE('[LOI] Sinh vien da dang ky lop nay!');
        RETURN;
    END IF;

    --dk5: ko qua 3 lop
    SELECT COUNT(*) INTO v_check 
    FROM DANGKY 
    WHERE masv = p_masv;

    IF v_check >= 3 THEN
        DBMS_OUTPUT.PUT_LINE('[LOI] Sinh vien da dang ky du 3 lop!');
        RETURN;
    END IF;

    -- INSERT
    INSERT INTO DANGKY
    (masv, malop, ngaydangky, nguoitao, ngaytao, nguoisua, ngaysua)
    VALUES
    (p_masv, p_malop, SYSDATE, USER, SYSDATE, USER, SYSDATE);

    COMMIT;

    DBMS_OUTPUT.PUT_LINE('[OK] Dang ky thanh cong! SV ' 
                         || p_masv || ' -> Lop ' || p_malop);

EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('[LOI HE THONG] ' || SQLERRM);
END;
/

SET SERVEROUTPUT ON;

--test
BEGIN
    enroll_student(101, 1); 
    enroll_student(999, 1); 
    enroll_student(101, 999); 
END;
/

--2.2
CREATE OR REPLACE PROCEDURE update_final_grade
(p_masv IN NUMBER,
 p_malop IN NUMBER,
 p_diem IN NUMBER)
IS
    v_check NUMBER;
    v_old_diem NUMBER;
BEGIN
    --KT diem hop le
    IF p_diem < 0 OR p_diem > 100 THEN
        DBMS_OUTPUT.PUT_LINE('[LOI] Diem khong hop le!');
        RETURN;
    END IF;

    --KT ton tai
    SELECT COUNT(*) INTO v_check 
    FROM DANGKY
    WHERE masv = p_masv AND malop = p_malop;

    IF v_check = 0 THEN
        DBMS_OUTPUT.PUT_LINE('[LOI] SV chua dang ky lop!');
        RETURN;
    END IF;

    --lay diem cu
    SELECT diemtongket INTO v_old_diem
    FROM DANGKY
    WHERE masv = p_masv AND malop = p_malop;

    --update DANGKY
    UPDATE DANGKY
    SET diemtongket = p_diem,
        nguoisua = USER,
        ngaysua = SYSDATE
    WHERE masv = p_masv AND malop = p_malop;

    --gop sang DIEM
    MERGE INTO DIEM d
    USING (SELECT p_masv masv, p_malop malop FROM dual) src
    ON (d.masv = src.masv AND d.malop = src.malop)
    
    WHEN MATCHED THEN
        UPDATE SET d.diem = p_diem,
                   d.nguoisua = USER,
                   d.ngaysua = SYSDATE
                   
    WHEN NOT MATCHED THEN
        INSERT (masv, malop, diem, nguoitao, ngaytao, nguoisua, ngaysua)
        VALUES (p_masv, p_malop, p_diem, USER, SYSDATE, USER, SYSDATE);

    COMMIT;

    DBMS_OUTPUT.PUT_LINE('[OK] Cap nhat thanh cong!');

EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('[LOI] ' || SQLERRM);
END;
/

--test
BEGIN
    update_final_grade(101, 1, 90);
END;

--2.3
CREATE OR REPLACE PROCEDURE unenroll_student
(p_masv IN NUMBER,
 p_malop IN NUMBER)
IS
    v_check NUMBER;
BEGIN
    --KT SV co dang ky lop nay ko
    SELECT COUNT(*) INTO v_check
    FROM DANGKY
    WHERE masv = p_masv AND malop = p_malop;

    IF v_check = 0 THEN
        DBMS_OUTPUT.PUT_LINE('[LOI] Sinh vien chua dang ky lop nay!');
        RETURN;
    END IF;

    --xoa ben DIEM truoc
    DELETE FROM DIEM
    WHERE masv = p_masv AND malop = p_malop;

    --xoa dang ky
    DELETE FROM DANGKY
    WHERE masv = p_masv AND malop = p_malop;

    COMMIT;

    DBMS_OUTPUT.PUT_LINE('[OK] Huy dang ky thanh cong! SV '
                         || p_masv || ' - Lop ' || p_malop);

EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('[LOI] ' || SQLERRM);
END;
/

--test
BEGIN
    unenroll_student(101, 1); --hop le
END;

--2.4
CREATE OR REPLACE PROCEDURE report_class_detail
(p_malop IN NUMBER)
IS
    v_check NUMBER;
    v_tenmon VARCHAR2(50);
    v_mamon NUMBER;
    v_gv VARCHAR2(100);
    v_phong VARCHAR2(50);
    v_succhua NUMBER;

    v_stt NUMBER := 0;
    v_tong NUMBER := 0;
    v_sum_d NUMBER := 0;
    v_co_d NUMBER := 0;
    v_xeploai VARCHAR2(20);
BEGIN
    --KT lop ton tai
    SELECT COUNT(*) INTO v_check 
    FROM LOPHOC 
    WHERE malop = p_malop;

    IF v_check = 0 THEN
        DBMS_OUTPUT.PUT_LINE('Lop ' || p_malop || ' khong ton tai!');
        RETURN;
    END IF;

    --lay thong tin lop
    SELECT mh.tenmon, mh.mamon,
           gv.ho || ' ' || gv.ten,
           lh.phonghoc, lh.succhua
    INTO v_tenmon, v_mamon, v_gv, v_phong, v_succhua
    FROM LOPHOC lh
    JOIN MONHOC mh ON lh.mamon = mh.mamon
    JOIN GIAOVIEN gv ON lh.magv = gv.magv
    WHERE lh.malop = p_malop;

    -- Header
    DBMS_OUTPUT.PUT_LINE('=== BAO CAO LOP: ' || p_malop || ' ===');
    DBMS_OUTPUT.PUT_LINE('Mon hoc : ' || v_mamon || ' - ' || v_tenmon);
    DBMS_OUTPUT.PUT_LINE('Giao vien: ' || v_gv);
    DBMS_OUTPUT.PUT_LINE('Phong hoc: ' || v_phong);
    DBMS_OUTPUT.PUT_LINE('Suc chua : ' || v_succhua);
    DBMS_OUTPUT.PUT_LINE(RPAD('-',50,'-'));

    DBMS_OUTPUT.PUT_LINE('STT | Ho ten               | Diem | Xep loai');
    DBMS_OUTPUT.PUT_LINE(RPAD('-',50,'-'));

    --loop SV
    FOR rec IN (
        SELECT sv.ho || ' ' || sv.ten AS hoten,
               dk.diemtongket
        FROM DANGKY dk
        JOIN SINHVIEN sv ON dk.masv = sv.masv
        WHERE dk.malop = p_malop
        ORDER BY sv.ten
    )
    LOOP
        v_stt := v_stt + 1;
        v_tong := v_tong + 1;

        --xep loai
        IF rec.diemtongket IS NULL THEN
            v_xeploai := 'Chua co diem';
        ELSIF rec.diemtongket >= 90 THEN
            v_xeploai := 'A';
            v_sum_d := v_sum_d + rec.diemtongket; v_co_d := v_co_d + 1;
        ELSIF rec.diemtongket >= 80 THEN
            v_xeploai := 'B';
            v_sum_d := v_sum_d + rec.diemtongket; v_co_d := v_co_d + 1;
        ELSIF rec.diemtongket >= 70 THEN
            v_xeploai := 'C';
            v_sum_d := v_sum_d + rec.diemtongket; v_co_d := v_co_d + 1;
        ELSIF rec.diemtongket >= 50 THEN
            v_xeploai := 'D';
            v_sum_d := v_sum_d + rec.diemtongket; v_co_d := v_co_d + 1;
        ELSE
            v_xeploai := 'F';
            v_sum_d := v_sum_d + rec.diemtongket; v_co_d := v_co_d + 1;
        END IF;

        DBMS_OUTPUT.PUT_LINE(
            LPAD(v_stt,3) || ' | ' ||
            RPAD(rec.hoten,20) || ' | ' ||
            LPAD(NVL(TO_CHAR(rec.diemtongket),'NULL'),5) || ' | ' ||
            v_xeploai
        );
    END LOOP;

    -- Footer
    DBMS_OUTPUT.PUT_LINE(RPAD('-',50,'-'));
    DBMS_OUTPUT.PUT_LINE('Tong SV: ' || v_tong);

    IF v_co_d > 0 THEN
        DBMS_OUTPUT.PUT_LINE('Diem TB: ' || ROUND(v_sum_d / v_co_d, 2));
    ELSE
        DBMS_OUTPUT.PUT_LINE('Diem TB: Chua co diem');
    END IF;

END;
/

--test
BEGIN
    report_class_detail(1);
END;

--2.5
CREATE OR REPLACE PROCEDURE sync_grade_from_enrollment
IS
    v_check NUMBER;
    v_insert NUMBER := 0;
    v_update NUMBER := 0;
BEGIN
    FOR rec IN (
        SELECT masv, malop, diemtongket
        FROM DANGKY
        WHERE diemtongket IS NOT NULL
    ) LOOP

        --KT ton tai trong DIEM
        SELECT COUNT(*) INTO v_check
        FROM DIEM
        WHERE masv = rec.masv AND malop = rec.malop;

        IF v_check = 0 THEN
            --INSERT moi
            INSERT INTO DIEM
            (masv, malop, diem, nguoitao, ngaytao, nguoisua, ngaysua)
            VALUES
            (rec.masv, rec.malop, rec.diemtongket,
             USER, SYSDATE, USER, SYSDATE);

            v_insert := v_insert + 1;

        ELSE
            --UPDATE
            UPDATE DIEM
            SET diem = rec.diemtongket,
                nguoisua = USER,
                ngaysua = SYSDATE
            WHERE masv = rec.masv AND malop = rec.malop;

            v_update := v_update + 1;
        END IF;

    END LOOP;

    COMMIT;

    DBMS_OUTPUT.PUT_LINE('[OK] Dong bo xong!');
    DBMS_OUTPUT.PUT_LINE('INSERT: ' || v_insert);
    DBMS_OUTPUT.PUT_LINE('UPDATE: ' || v_update);

EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('[LOI] ' || SQLERRM);
END;
/

--test
BEGIN
    sync_grade_from_enrollment;
END;
/


-----------------------------------TRIGGER--------------------------------------
--3.1
CREATE OR REPLACE TRIGGER trg_check_capacity
BEFORE INSERT ON DANGKY
FOR EACH ROW
DECLARE
    v_siso NUMBER;
    v_dadangky NUMBER;
BEGIN
    --lấy sức chứa lớp
    SELECT succhua INTO v_siso
    FROM LOPHOC
    WHERE malop = :NEW.malop;

    --đếm số SV đã đăng ký
    SELECT COUNT(*) INTO v_dadangky
    FROM DANGKY
    WHERE malop = :NEW.malop;

    --nếu lớp đầy thì chặn
    IF v_dadangky >= v_siso THEN
        RAISE_APPLICATION_ERROR(
            -20010,
            'LOI: Lop ' || :NEW.malop || ' da day! (' 
            || v_dadangky || '/' || v_siso || ')'
        );
    END IF;

END;
/

--test
INSERT INTO DANGKY
(masv, malop, ngaydangky)
VALUES (101, 2, SYSDATE);

--3.2
CREATE TABLE grade_audit_log (
    log_id NUMBER GENERATED ALWAYS AS IDENTITY,
    masv NUMBER(8),
    malop NUMBER(8),
    diem_cu NUMBER(3),
    diem_moi NUMBER(3),
    nguoi_sua VARCHAR2(30),
    thoi_gian DATE
);

CREATE OR REPLACE TRIGGER trg_grade_audit_log
AFTER UPDATE OF diemtongket ON DANGKY
FOR EACH ROW
BEGIN
    --chỉ ghi log khi điểm THỰC SỰ thay đổi
    IF (:OLD.diemtongket IS NULL AND :NEW.diemtongket IS NOT NULL)
    OR (:OLD.diemtongket IS NOT NULL AND :NEW.diemtongket IS NULL)
    OR (:OLD.diemtongket != :NEW.diemtongket)
    THEN
        INSERT INTO grade_audit_log
        (masv, malop, diem_cu, diem_moi, nguoi_sua, thoi_gian)
        VALUES
        (:OLD.masv, :OLD.malop, :OLD.diemtongket,
         :NEW.diemtongket, USER, SYSDATE);
    END IF;
END;
/

--test
UPDATE DANGKY
SET diemtongket = 85
WHERE masv = 102 AND malop = 1;

COMMIT;
SELECT * FROM grade_audit_log;

--3.3
CREATE OR REPLACE TRIGGER trg_prevent_course_delete
BEFORE DELETE ON MONHOC
FOR EACH ROW
DECLARE
    v_so_lop NUMBER;
BEGIN
    --đếm số lớp đang thuộc môn học này
    SELECT COUNT(*) INTO v_so_lop
    FROM LOPHOC
    WHERE mamon = :OLD.mamon;

    --nếu còn lớp thì chặn xóa
    IF v_so_lop > 0 THEN
        RAISE_APPLICATION_ERROR(
            -20020,
            'Khong the xoa mon hoc ' || :OLD.mamon ||
            ' (' || :OLD.tenmon || ') vi con '
            || v_so_lop || ' lop hoc dang ton tai!'
        );
    END IF;

END;
/

--test
DELETE FROM MONHOC WHERE mamon = 10;

--3.4
CREATE TABLE class_grade_summary (
    malop NUMBER(8) PRIMARY KEY,
    so_sv NUMBER,
    diem_tb NUMBER(5,2),
    diem_cao_nhat NUMBER(3),
    diem_thap_nhat NUMBER(3),
    cap_nhat_luc DATE
);

CREATE OR REPLACE TRIGGER trg_update_grade_summary
AFTER INSERT OR UPDATE OR DELETE ON DANGKY
FOR EACH ROW
DECLARE
    v_malop NUMBER;
    v_so_sv NUMBER;
    v_diem_tb NUMBER;
    v_max_d NUMBER;
    v_min_d NUMBER;
BEGIN
    --xác định lớp bị ảnh hưởng
    IF INSERTING OR UPDATING THEN
        v_malop := :NEW.malop;
    ELSE
        v_malop := :OLD.malop;
    END IF;

    --tính lại thống kê
    SELECT COUNT(diemtongket),
           ROUND(AVG(diemtongket), 2),
           MAX(diemtongket),
           MIN(diemtongket)
    INTO v_so_sv, v_diem_tb, v_max_d, v_min_d
    FROM DANGKY
    WHERE malop = v_malop
      AND diemtongket IS NOT NULL;

    --cập nhật / thêm mới
    MERGE INTO class_grade_summary cgs
    USING (SELECT v_malop AS malop FROM dual) src
    ON (cgs.malop = src.malop)
    WHEN MATCHED THEN
        UPDATE SET
            so_sv = v_so_sv,
            diem_tb = v_diem_tb,
            diem_cao_nhat = v_max_d,
            diem_thap_nhat = v_min_d,
            cap_nhat_luc = SYSDATE
    WHEN NOT MATCHED THEN
        INSERT (malop, so_sv, diem_tb, diem_cao_nhat, diem_thap_nhat, cap_nhat_luc)
        VALUES (v_malop, v_so_sv, v_diem_tb, v_max_d, v_min_d, SYSDATE);

END;
/

--test
UPDATE DANGKY
SET diemtongket = 90
WHERE masv = 102 AND malop = 1;

COMMIT;
SELECT * FROM class_grade_summary WHERE malop = 1;


----------------------------------TỔNG HỢP--------------------------------------
--4.1
CREATE OR REPLACE VIEW vw_instructor_workload AS
SELECT gv.magv,
       gv.ho || ' ' || gv.ten AS ho_ten,
       COUNT(DISTINCT lh.malop) AS so_lop,
       COUNT(dk.masv) AS tong_sv,
       ROUND(AVG(dk.diemtongket), 2) AS diem_tb_chung,
       CASE
           WHEN COUNT(DISTINCT lh.malop) >= 3 THEN 'Ban nhieu'
           WHEN COUNT(DISTINCT lh.malop) = 2 THEN 'Binh thuong'
           ELSE 'Nhe nhang'
       END AS muc_ban
FROM GIAOVIEN gv
LEFT JOIN LOPHOC lh ON gv.magv = lh.magv
LEFT JOIN DANGKY dk ON lh.malop = dk.malop
GROUP BY gv.magv, gv.ho, gv.ten;

CREATE OR REPLACE VIEW vw_top_courses AS
SELECT mh.mamon,
       mh.tenmon,
       COUNT(dk.masv) AS tong_dk,
       RANK() OVER (ORDER BY COUNT(dk.masv) DESC) AS hang
FROM MONHOC mh
LEFT JOIN LOPHOC lh ON mh.mamon = lh.mamon
LEFT JOIN DANGKY dk ON lh.malop = dk.malop
GROUP BY mh.mamon, mh.tenmon;

CREATE OR REPLACE PROCEDURE print_system_report
IS
    v_so_mon NUMBER;
    v_so_lop NUMBER;
    v_so_sv NUMBER;
    v_so_gv NUMBER;
BEGIN
    -- Tổng quan
    SELECT COUNT(*) INTO v_so_mon FROM MONHOC;
    SELECT COUNT(*) INTO v_so_lop FROM LOPHOC;
    SELECT COUNT(*) INTO v_so_sv FROM SINHVIEN;
    SELECT COUNT(*) INTO v_so_gv FROM GIAOVIEN;

    DBMS_OUTPUT.PUT_LINE('==============================');
    DBMS_OUTPUT.PUT_LINE(' BAO CAO HE THONG ');
    DBMS_OUTPUT.PUT_LINE('==============================');

    DBMS_OUTPUT.PUT_LINE('So mon hoc  : ' || v_so_mon);
    DBMS_OUTPUT.PUT_LINE('So lop hoc  : ' || v_so_lop);
    DBMS_OUTPUT.PUT_LINE('So sinh vien: ' || v_so_sv);
    DBMS_OUTPUT.PUT_LINE('So giao vien: ' || v_so_gv);

    DBMS_OUTPUT.PUT_LINE('------------------------------');

    -- 📌 Thống kê giáo viên
    DBMS_OUTPUT.PUT_LINE('THONG KE GIAO VIEN:');

    FOR rec IN (SELECT * FROM vw_instructor_workload) LOOP
        DBMS_OUTPUT.PUT_LINE(
            RPAD(rec.ho_ten, 25)
            || ' | ' || LPAD(rec.so_lop, 2) || ' lop'
            || ' | ' || LPAD(rec.tong_sv, 3) || ' SV'
            || ' | DTB: ' || NVL(TO_CHAR(rec.diem_tb_chung),'--')
            || ' | ' || rec.muc_ban
        );
    END LOOP;

    DBMS_OUTPUT.PUT_LINE('------------------------------');

    -- 📌 Top 3 môn học
    DBMS_OUTPUT.PUT_LINE('TOP 3 MON HOC:');

    FOR rec IN (SELECT * FROM vw_top_courses WHERE hang <= 3) LOOP
        DBMS_OUTPUT.PUT_LINE(
            rec.hang || '. '
            || RPAD(rec.tenmon, 25)
            || ' - ' || rec.tong_dk || ' luot'
        );
    END LOOP;

    DBMS_OUTPUT.PUT_LINE('==============================');

END;
/

--test
SET SERVEROUTPUT ON;
BEGIN
    print_system_report;
END;
/