INSERT INTO HangSX VALUES ('H1','Samsung','Ha Noi','0123456789','ss@gmail.com');
INSERT INTO HangSX VALUES ('H2','Apple','TP HCM','0987654321','apple@gmail.com');

INSERT INTO SanPham VALUES ('SP1','H1','DienThoai SamSung Galaxy 7',100,'Den',1000,'Cai','');
INSERT INTO SanPham VALUES ('SP2','H1','DienThoai SamSung Galaxy 9',50,'Trang',1500,'Cai','');
INSERT INTO SanPham VALUES ('SP3','H2','Iphone 14 pro max',200,'Xanh',2000,'Cai','');

INSERT INTO NhanVien VALUES ('NV1','Nguyen Van An','Nam','Ha Noi','0123','a@gmail.com','KinhDoanh');
INSERT INTO NhanVien VALUES ('NV2','Tran Thi Bich Tuyen','Nu','TP HCM','0456','b@gmail.com','KeToan');

INSERT INTO PNhap VALUES ('HDN1', SYSDATE, 'NV1');
INSERT INTO PNhap VALUES ('HDN2', SYSDATE, 'NV2');

INSERT INTO PXuat VALUES ('HDX1', SYSDATE, 'NV1');
INSERT INTO PXuat VALUES ('HDX2', SYSDATE, 'NV2');

INSERT INTO Nhap VALUES ('HDN1', 'SP1', 10, 500);
INSERT INTO Nhap VALUES ('HDN1', 'SP2', 20, 700);
INSERT INTO Nhap VALUES ('HDN2', 'SP3', 15, 1000);

INSERT INTO Xuat VALUES ('HDX1', 'SP1', 5);
INSERT INTO Xuat VALUES ('HDX1', 'SP2', 10);
INSERT INTO Xuat VALUES ('HDX2', 'SP3', 8);

------------------------------ PHIẾU BÀI TẬP 1 ---------------------------------
--a. Trigger INSERT bảng NHAP – trg_Nhap
CREATE OR REPLACE TRIGGER trg_Nhap
BEFORE INSERT ON Nhap
FOR EACH ROW
DECLARE
    v_dem NUMBER := 0;
BEGIN
    -- 1. Kiểm tra MaSP có tồn tại không
    SELECT COUNT(*) INTO v_dem
    FROM SanPham
    WHERE MaSP = :NEW.MaSP;

    IF v_dem = 0 THEN
        RAISE_APPLICATION_ERROR(-20001, 'MaSP khong ton tai');
    END IF;

    -- 2. Kiểm tra dữ liệu hợp lệ
    IF :NEW.SoLuongN <= 0 OR :NEW.DonGiaN <= 0 THEN
        RAISE_APPLICATION_ERROR(-20002, 'SoLuongN va DonGiaN phai > 0');
    END IF;

    -- 3. Cập nhật số lượng sản phẩm
    UPDATE SanPham
    SET SoLuong = SoLuong + :NEW.SoLuongN
    WHERE MaSP = :NEW.MaSP;

END;
/
SELECT * FROM Nhap;
--test
INSERT INTO Nhap VALUES ('HDN1', 'SP1', 10, 500);

--b. Trigger INSERT bảng XUAT – trg_xuat
CREATE OR REPLACE TRIGGER trg_Xuat
BEFORE INSERT ON Xuat
FOR EACH ROW
DECLARE
    v_dem NUMBER := 0;
    v_soluong NUMBER := 0;
BEGIN
    -- 1. Kiểm tra MaSP tồn tại
    SELECT COUNT(*) INTO v_dem
    FROM SanPham
    WHERE MaSP = :NEW.MaSP;

    IF v_dem = 0 THEN
        RAISE_APPLICATION_ERROR(-20001, 'MaSP khong ton tai');
    END IF;

    -- 2. Lấy số lượng hiện có
    SELECT SoLuong INTO v_soluong
    FROM SanPham
    WHERE MaSP = :NEW.MaSP;

    -- 3. Kiểm tra đủ hàng không
    IF :NEW.SoLuongX > v_soluong THEN
        RAISE_APPLICATION_ERROR(-20002, 'Khong du so luong trong kho');
    END IF;

    -- 4. Trừ số lượng
    UPDATE SanPham
    SET SoLuong = SoLuong - :NEW.SoLuongX
    WHERE MaSP = :NEW.MaSP;

END;
/

--test
INSERT INTO Xuat VALUES ('HDX1', 'SP1', 5);

--c. Trigger DELETE bảng XUAT – trg_XoaXuat
CREATE OR REPLACE TRIGGER trg_XoaXuat
AFTER DELETE ON Xuat
FOR EACH ROW
BEGIN
    -- Hoàn lại số lượng sản phẩm
    UPDATE SanPham
    SET SoLuong = SoLuong + :OLD.SoLuongX
    WHERE MaSP = :OLD.MaSP;

END;
/

--test
-- Xem trước
SELECT SoLuong FROM SanPham WHERE MaSP = 'SP1';

-- Xóa
DELETE FROM Xuat 
WHERE SoHDX = 'HDX1' AND MaSP = 'SP1';

-- Xem lại
SELECT SoLuong FROM SanPham WHERE MaSP = 'SP1';


------------------------------ PHIẾU BÀI TẬP 2 ---------------------------------
CREATE OR REPLACE PACKAGE pkg_state AS
    g_row_count NUMBER := 0;
END pkg_state;
/

--a. Trigger UPDATE bảng XUAT – trg_CapNhatXuat
CREATE OR REPLACE TRIGGER trg_CapNhatXuat
FOR UPDATE ON Xuat
COMPOUND TRIGGER

--reset trước khi chạy UPDATE
BEFORE STATEMENT IS
BEGIN
    pkg_state.g_row_count := 0;
END BEFORE STATEMENT;

--chạy từng dòng
BEFORE EACH ROW IS
    v_soluong NUMBER;
    v_chenhlech NUMBER;
BEGIN
    pkg_state.g_row_count := pkg_state.g_row_count + 1;

    --nếu update > 1 dòng → lỗi
    IF pkg_state.g_row_count > 1 THEN
        RAISE_APPLICATION_ERROR(-20001, 'Chi duoc cap nhat 1 ban ghi');
    END IF;

    --nếu thay đổi số lượng xuất
    IF :NEW.SoLuongX != :OLD.SoLuongX THEN

        v_chenhlech := :NEW.SoLuongX - :OLD.SoLuongX;

        --lấy số lượng hiện tại
        SELECT SoLuong INTO v_soluong
        FROM SanPham
        WHERE MaSP = :OLD.MaSP;

        --nếu không đủ hàng
        IF v_chenhlech > v_soluong THEN
            RAISE_APPLICATION_ERROR(-20002, 'Khong du hang de cap nhat');
        END IF;

        --cập nhật kho
        UPDATE SanPham
        SET SoLuong = SoLuong - v_chenhlech
        WHERE MaSP = :OLD.MaSP;

    END IF;

END BEFORE EACH ROW;

END trg_CapNhatXuat;
/

--test
-- Xem trước
SELECT SoLuong FROM SanPham WHERE MaSP = 'SP1';

UPDATE Xuat
SET SoLuongX = 8
WHERE SoHDX = 'HDX1' AND MaSP = 'SP1';

SELECT SoLuong FROM SanPham WHERE MaSP = 'SP1';

--b. Trigger UPDATE bảng NHAP – trg_CapNhatNhap
CREATE OR REPLACE TRIGGER trg_CapNhatNhap
FOR UPDATE ON Nhap
COMPOUND TRIGGER

BEFORE STATEMENT IS
BEGIN
    pkg_state.g_row_count := 0;
END BEFORE STATEMENT;

BEFORE EACH ROW IS
    v_chenhlech NUMBER;
BEGIN
    pkg_state.g_row_count := pkg_state.g_row_count + 1;

    -- Chỉ cho update 1 dòng
    IF pkg_state.g_row_count > 1 THEN
        RAISE_APPLICATION_ERROR(-20001, 'Chi duoc cap nhat 1 ban ghi');
    END IF;

    -- Nếu thay đổi số lượng nhập
    IF :NEW.SoLuongN != :OLD.SoLuongN THEN

        v_chenhlech := :NEW.SoLuongN - :OLD.SoLuongN;

        UPDATE SanPham
        SET SoLuong = SoLuong + v_chenhlech
        WHERE MaSP = :OLD.MaSP;

    END IF;

END BEFORE EACH ROW;

END trg_CapNhatNhap;
/

--test 
UPDATE Nhap
SET SoLuongN = 20
WHERE SoHDN = 'HDN1' AND MaSP = 'SP1';

SELECT * FROM Nhap;

--c. Trigger DELETE bảng NHAP – trg_XoaNhap
CREATE OR REPLACE TRIGGER trg_XoaNhap
AFTER DELETE ON Nhap
FOR EACH ROW
BEGIN
    UPDATE SanPham
    SET SoLuong = SoLuong - :OLD.SoLuongN
    WHERE MaSP = :OLD.MaSP;
END;
/

--test 
DELETE FROM Nhap
WHERE SoHDN = 'HDN1' AND MaSP = 'SP1';

SELECT SoLuong FROM SanPham WHERE MaSP = 'SP1';

------------------------------ PHIẾU BÀI TẬP 3 ---------------------------------
--Tạo bảng
CREATE TABLE Phong (
    MaPhong VARCHAR2(10) PRIMARY KEY,
    LoaiPhong VARCHAR2(20),
    TrangThai VARCHAR2(20),
    GiaTheoGio NUMBER,
    GiaTheoNgay NUMBER,
    SoNguoiToiDa NUMBER
);

CREATE TABLE KhachHang_KS (
    MaKH VARCHAR2(10) PRIMARY KEY,
    HoTen VARCHAR2(50),
    CCCD VARCHAR2(20),
    SoDT VARCHAR2(15),
    Email VARCHAR2(50),
    QuocTich VARCHAR2(30)
);

CREATE TABLE HoaDon_KS (
    MaHD VARCHAR2(10) PRIMARY KEY,
    MaKH VARCHAR2(10),
    MaPhong VARCHAR2(10),
    NgayNhan DATE,
    NgayTra DATE,
    SoNguoi NUMBER,
    TongTien NUMBER,
    TrangThai VARCHAR2(20),

    CONSTRAINT fk_HD_KH FOREIGN KEY (MaKH) REFERENCES KhachHang(MaKH),
    CONSTRAINT fk_HD_Phong FOREIGN KEY (MaPhong) REFERENCES Phong(MaPhong)
);

CREATE TABLE ChiPhiPhuThu (
    MaCP VARCHAR2(10) PRIMARY KEY,
    MaHD VARCHAR2(10),
    MoTa VARCHAR2(100),
    SoTien NUMBER,
    ThoiGian DATE,

    CONSTRAINT fk_CP_HD FOREIGN KEY (MaHD) REFERENCES HoaDon(MaHD)
);

CREATE TABLE LichSuPhong (
    MaLS VARCHAR2(10) PRIMARY KEY,
    MaPhong VARCHAR2(10),
    MaHD VARCHAR2(10),
    NgayNhan DATE,
    NgayTra DATE,
    GhiChu VARCHAR2(100)
);

--insert dữ liệu 
INSERT INTO Phong VALUES ('P1','Don','TRONG',100,500,2);
INSERT INTO Phong VALUES ('P2','Doi','TRONG',150,800,4);
INSERT INTO Phong VALUES ('P3','VIP','BAO_TRI',300,1500,6);
SELECT * FROM Phong;

INSERT INTO KhachHang_KS VALUES ('KH1','Nguyen Minh Duc','123456','0123','a@gmail.com','VN');
INSERT INTO KhachHang_KS VALUES ('KH2','Tran Hoang Linh','654321','0456','b@gmail.com','VN');
SELECT * FROM KhachHang_KS;

INSERT INTO HoaDon_KS VALUES ('HD1','KH1','P1', SYSDATE, SYSDATE + 2, 2, 1000, 'CHO_NHAN');
INSERT INTO HoaDon_KS VALUES ('HD2','KH2','P2', SYSDATE, SYSDATE + 3, 3, 2400, 'CHO_NHAN');

INSERT INTO ChiPhiPhuThu VALUES ('CP1','HD1','Nuoc',100000,SYSDATE);
INSERT INTO ChiPhiPhuThu VALUES ('CP2','HD1','Do an',200000,SYSDATE);
INSERT INTO ChiPhiPhuThu VALUES ('CP3','HD2','Giat ui',150000,SYSDATE);

--a. Trigger INSERT bảng HoaDon — trg_DatPhong
CREATE OR REPLACE TRIGGER trg_DatPhong
BEFORE INSERT ON HoaDon_KS
FOR EACH ROW
DECLARE
    v_dem NUMBER;
    v_trangthai VARCHAR2(20);
    v_succhua NUMBER;
    v_gia NUMBER;
    v_songay NUMBER;
BEGIN
    --kiểm tra MaKH
    SELECT COUNT(*) INTO v_dem
    FROM KhachHang_KS
    WHERE MaKH = :NEW.MaKH;

    IF v_dem = 0 THEN
        RAISE_APPLICATION_ERROR(-20001, 'MaKH khong ton tai');
    END IF;

    --kiểm tra MaPhong + lấy thông tin
    SELECT TrangThai, SoNguoiToiDa, GiaTheoNgay
    INTO v_trangthai, v_succhua, v_gia
    FROM Phong
    WHERE MaPhong = :NEW.MaPhong;

    --phòng phải trống
    IF v_trangthai <> 'TRONG' THEN
        RAISE_APPLICATION_ERROR(-20002, 'Phong khong trong');
    END IF;

    --kiểm tra số người
    IF :NEW.SoNguoi > v_succhua THEN
        RAISE_APPLICATION_ERROR(-20003, 'Vuot qua suc chua');
    END IF;

    --kiểm tra ngày
    IF :NEW.NgayNhan >= :NEW.NgayTra OR :NEW.NgayNhan < TRUNC(SYSDATE) THEN
        RAISE_APPLICATION_ERROR(-20004, 'Ngay khong hop le');
    END IF;

    --tính tiền
    v_songay := :NEW.NgayTra - :NEW.NgayNhan;
    :NEW.TongTien := v_songay * v_gia;

    --cập nhật phòng
    UPDATE Phong
    SET TrangThai = 'DA_THUE'
    WHERE MaPhong = :NEW.MaPhong;

END;
/

--test
INSERT INTO KhachHang_KS 
VALUES ('KH3','Nguyen Thi Kim Thi','123456','0123','a@gmail.com','VN');
INSERT INTO Phong 
VALUES ('P4','Don','TRONG',100,500,2);

INSERT INTO HoaDon_KS (
    MaHD, MaKH, MaPhong, NgayNhan, NgayTra, SoNguoi, TrangThai
)
VALUES (
    'HD9','KH3','P4',
    SYSDATE,
    SYSDATE + 2,
    2,
    'CHO_NHAN'
);

SELECT * FROM HoaDon_KS;
SELECT MaPhong, TrangThai FROM Phong;