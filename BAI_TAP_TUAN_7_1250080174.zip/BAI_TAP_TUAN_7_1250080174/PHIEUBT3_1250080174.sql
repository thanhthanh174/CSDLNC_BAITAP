--thêm nhân viên 
CREATE OR REPLACE PROCEDURE sp_them_nhan_vien1 (
    p_MaNV        IN VARCHAR2,
    p_MaCV        IN VARCHAR2,
    p_TenNV       IN VARCHAR2,
    p_NgaySinh    IN DATE,
    p_LuongCB     IN NUMBER,
    p_NgayCong    IN NUMBER,
    p_PhuCap      IN NUMBER,
    p_kq          OUT NUMBER
)
AS
    v_dem NUMBER := 0;
BEGIN
    --kiểm tra MaCV tồn tại chưa
    SELECT COUNT(*) INTO v_dem
    FROM tblChucVu
    WHERE MaCV = p_MaCV;

    IF v_dem = 0 THEN
        p_kq := 0;   --MaCV không tồn tại
    ELSE
        INSERT INTO tblNhanVien
        VALUES (p_MaNV, p_MaCV, p_TenNV, p_NgaySinh,
                p_LuongCB, p_NgayCong, p_PhuCap);
        COMMIT;
        p_kq := 1;   --thêm thành công
    END IF;
END;
/

--test
DECLARE
    v_kq NUMBER;
BEGIN
    sp_them_nhan_vien1('NV05','CV01','Nguyen Thi Kim Thi', TO_DATE('01/01/2000','DD/MM/YYYY'), 5000000, 26, 500000, v_kq);
    DBMS_OUTPUT.PUT_LINE('Ket qua: ' || v_kq);
END;
/

DECLARE
    v_kq NUMBER;
BEGIN
    sp_them_nhan_vien1('NV06','CV05','Pham Thi Thuy Trang', TO_DATE('01/01/2005','DD/MM/YYYY'), 8000000, 26, 100000, v_kq);
    DBMS_OUTPUT.PUT_LINE('Ket qua: ' || v_kq);
END;
/

--sửa thủ tục
CREATE OR REPLACE PROCEDURE sp_them_nhan_vien2 (
    p_MaNV        IN VARCHAR2,
    p_MaCV        IN VARCHAR2,
    p_TenNV       IN VARCHAR2,
    p_NgaySinh    IN DATE,
    p_LuongCB     IN NUMBER,
    p_NgayCong    IN NUMBER,
    p_PhuCap      IN NUMBER,
    p_kq          OUT NUMBER
)
AS
    v_dem_nv  NUMBER := 0;
    v_dem_cv  NUMBER := 0;
BEGIN
    -- Kiểm tra MaNV trùng
    SELECT COUNT(*) INTO v_dem_nv
    FROM tblNhanVien
    WHERE MaNV = p_MaNV;

    IF v_dem_nv > 0 THEN
        p_kq := 0;  -- MaNV đã tồn tại
    ELSE
        -- Kiểm tra MaCV tồn tại
        SELECT COUNT(*) INTO v_dem_cv
        FROM tblChucVu
        WHERE MaCV = p_MaCV;

        IF v_dem_cv = 0 THEN
            p_kq := 1;  -- MaCV không tồn tại
        ELSE
            INSERT INTO tblNhanVien
            VALUES (p_MaNV, p_MaCV, p_TenNV, p_NgaySinh,
                    p_LuongCB, p_NgayCong, p_PhuCap);
            COMMIT;
            p_kq := 2;  -- Thêm thành công
        END IF;

    END IF;
END;
/

--test
--1. MaNV đã tồn tại trả về 0
DECLARE
    v_kq NUMBER;
BEGIN
    sp_them_nhan_vien2('NV05', 'CV03', 'Nguyen Tran Thi Kim Thai', TO_DATE('01/01/2000','DD/MM/YYYY'), 5000000, 26, 500000, v_kq);
    DBMS_OUTPUT.PUT_LINE('Ket qua: ' || v_kq);
END;
/

--2. MaCV kh tồn tại trả về 1
DECLARE
    v_kq NUMBER;
BEGIN
    sp_them_nhan_vien2('NV06','CV05','Pham Thi Thuy Trang', TO_DATE('01/01/2005','DD/MM/YYYY'), 8000000, 26, 100000, v_kq);
    DBMS_OUTPUT.PUT_LINE('Ket qua: ' || v_kq);
END;
/

--3. Thêm thành công trả về 2
DECLARE
    v_kq NUMBER;
BEGIN
    sp_them_nhan_vien2('NV06','CV03','Pham Thi Thuy Trang', TO_DATE('01/01/2005','DD/MM/YYYY'), 8000000, 26, 100000, v_kq);
    DBMS_OUTPUT.PUT_LINE('Ket qua: ' || v_kq);
END;
/

--cập nhật ngày sinh
CREATE OR REPLACE PROCEDURE sp_capnhat_ngaysinh (
    p_MaNV     IN VARCHAR2,
    p_NgaySinh IN DATE,
    p_kq       OUT NUMBER
)
AS
    v_dem NUMBER := 0;
BEGIN
    SELECT COUNT(*) INTO v_dem
    FROM tblNhanVien
    WHERE MaNV = p_MaNV;

    IF v_dem = 0 THEN
        p_kq := 0;  --kh tìm thấy
    ELSE
        UPDATE tblNhanVien
        SET NgaySinh = p_NgaySinh
        WHERE MaNV = p_MaNV;

        COMMIT;
        p_kq := 1;  --cập nhật thành công
    END IF;
END;
/

--test
DECLARE
    v_kq NUMBER;
BEGIN
    sp_capnhat_ngaysinh('NV06', TO_DATE('02/12/2005','DD/MM/YYYY'), v_kq);
    DBMS_OUTPUT.PUT_LINE('Ket qua: ' || v_kq);
END;
/

DECLARE
    v_kq NUMBER;
BEGIN
    sp_capnhat_ngaysinh('NV15', TO_DATE('12/12/2005','DD/MM/YYYY'), v_kq);
    DBMS_OUTPUT.PUT_LINE('Ket qua: ' || v_kq);
END;
/













