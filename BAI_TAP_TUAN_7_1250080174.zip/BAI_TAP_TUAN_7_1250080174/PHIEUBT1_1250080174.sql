--------------------BAI TAP 1-------------------------------
SET SERVEROUTPUT ON;
CREATE TABLE KHOA (
    Makhoa     VARCHAR2(10) PRIMARY KEY,
    Tenkhoa    VARCHAR2(100),
    Dienthoai  VARCHAR2(15)
);

CREATE TABLE LOP (
    Malop        VARCHAR2(10) PRIMARY KEY,
    Tenlop       VARCHAR2(100),
    Khoa         VARCHAR2(50),
    Hedt         VARCHAR2(50),
    Namnhaphoc   NUMBER(4),
    Makhoa       VARCHAR2(10),
    
    CONSTRAINT fk_lop_khoa
    FOREIGN KEY (Makhoa)
    REFERENCES KHOA(Makhoa)
);

CREATE OR REPLACE PROCEDURE sp_them_khoa (
    p_makhoa     IN VARCHAR2,
    p_tenkhoa    IN VARCHAR2,
    p_dienthoai  IN VARCHAR2
)
AS
    dem NUMBER := 0;
--Kiểm tra tên khoa tồn tại chưa
BEGIN
   SELECT COUNT(*)
   INTO dem
   FROM KHOA 
   WHERE Tenkhoa = p_tenkhoa;
   
   IF dem > 0 THEN
    DBMS_OUTPUT.PUT_LINE('Ten khoa da ton tai!');
   ELSE 
    INSERT INTO KHOA(Makhoa, Tenkhoa, Dienthoai)
    VALUES (p_makhoa, p_tenkhoa, p_dienthoai);
    
    DBMS_OUTPUT.PUT_LINE('Them khoa thanh cong!');
    COMMIT;
   END IF;
   
END sp_them_khoa;
/

--test 2 trường hợp
BEGIN
    sp_them_khoa('KT', 'Ke toan', '0123456789');
END;
/

BEGIN
    sp_them_khoa('CNTT', 'Cong nghe thong tin', '0999999999');
END;
/

DELETE FROM KHOA
WHERE Makhoa = 'CNTT2';

COMMIT;

--------------------BAI TAP 2-------------------------------
CREATE OR REPLACE PROCEDURE sp_them_lop (
    p_malop        IN VARCHAR2,
    p_tenlop       IN VARCHAR2,
    p_khoa         IN VARCHAR2,
    p_hedt         IN VARCHAR2,
    p_namnhaphoc   IN NUMBER,
    p_makhoa       IN VARCHAR2
)
AS
    v_dem_lop   NUMBER := 0;
    v_dem_khoa  NUMBER := 0;
BEGIN
    -- Kiểm tra tên lớp đã tồn tại chưa
    SELECT COUNT(*)
    INTO v_dem_lop
    FROM LOP
    WHERE Tenlop = p_tenlop;

    IF v_dem_lop > 0 THEN
        DBMS_OUTPUT.PUT_LINE('Ten lop da ton tai!');
    ELSEDoanNgocPhuongThanh

        -- Kiểm tra Makhoa có tồn tại trong KHOA không
        SELECT COUNT(*)
        INTO v_dem_khoa
        FROM KHOA
        WHERE Makhoa = p_makhoa;

        IF v_dem_khoa = 0 THEN
            DBMS_OUTPUT.PUT_LINE('Ma khoa khong ton tai!');
        ELSE
            INSERT INTO LOP(Malop, Tenlop, Khoa, Hedt, Namnhaphoc, Makhoa)
            VALUES (p_malop, p_tenlop, p_khoa, p_hedt, p_namnhaphoc, p_makhoa);

            DBMS_OUTPUT.PUT_LINE('Them lop thanh cong!');
            COMMIT;
        END IF;
    END IF;
    
END sp_them_lop;
/

----test 3 trường hợp
BEGIN
    sp_them_lop('L01', '12_DH_CNTT4', 'K12', 'Chinh quy', 2023, 'CNTT');
END;
/

BEGIN
    sp_them_lop('L02', '12_DH_CNTT1', 'K12', 'Chinh quy', 2023, 'CNTT2');
END;
/

--------------------BAI TAP 3-------------------------------
CREATE OR REPLACE PROCEDURE sp_them_khoa_bt3 (
    p_makhoa     IN VARCHAR2,
    p_tenkhoa    IN VARCHAR2,
    p_dienthoai  IN VARCHAR2,
    p_kq         OUT NUMBER
)
AS
    v_dem NUMBER := 0;
BEGIN
    --kiểm tra tên khoa tồn tại chưa
    SELECT COUNT(*)
    INTO v_dem
    FROM KHOA
    WHERE Tenkhoa = p_tenkhoa;

    IF v_dem > 0 THEN
        p_kq := 0;  --đã tồn tại
    ELSE
        INSERT INTO KHOA(Makhoa, Tenkhoa, Dienthoai)
        VALUES (p_makhoa, p_tenkhoa, p_dienthoai);

        COMMIT;
        p_kq := 1;  --thêm thành công
    END IF;

END sp_them_khoa_bt3;
/

--test
DECLARE
    v_kq NUMBER;
BEGIN
    sp_them_khoa_bt3('QLDD', 'Quan ly dat dai', '0854546898', v_kq);
    DBMS_OUTPUT.PUT_LINE('Ket qua: ' || v_kq);
END;
/

--------------------BAI TAP 4-------------------------------
CREATE OR REPLACE PROCEDURE sp_them_lop_bt4 (
    p_malop        IN VARCHAR2,
    p_tenlop       IN VARCHAR2,
    p_khoa         IN VARCHAR2,
    p_hedt         IN VARCHAR2,
    p_namnhaphoc   IN NUMBER,
    p_makhoa       IN VARCHAR2,
    p_kq           OUT NUMBER
)
AS
    v_dem_lop   NUMBER := 0;
    v_dem_khoa  NUMBER := 0;
BEGIN
    --kiểm tra tên lớp
    SELECT COUNT(*)
    INTO v_dem_lop
    FROM LOP
    WHERE Tenlop = p_tenlop;

    IF v_dem_lop > 0 THEN
        p_kq := 0;   --đã tồn tại
    ELSE
        -- Kiểm tra Makhoa
        SELECT COUNT(*)
        INTO v_dem_khoa
        FROM KHOA
        WHERE Makhoa = p_makhoa;

        IF v_dem_khoa = 0 THEN
            p_kq := 1;  --Makhoa không tồn tại
        ELSE
            INSERT INTO LOP(Malop, Tenlop, Khoa, Hedt, Namnhaphoc, Makhoa)
            VALUES (p_malop, p_tenlop, p_khoa, p_hedt, p_namnhaphoc, p_makhoa);

            COMMIT;
            p_kq := 2;  --thêm thành công
        END IF;
    END IF;

END sp_them_lop_bt4;
/

--test 
--1.thành công trả về 2
DECLARE
    v_kq NUMBER;
BEGIN
    sp_them_lop_bt4('L03', '12_DH_CNTT2', 'K12', 'Chinh quy', 2023, 'CNTT', v_kq);
    DBMS_OUTPUT.PUT_LINE('Ket qua: ' || v_kq);
END;
/

--2.trùng trả về 0
DECLARE
    v_kq NUMBER;
BEGIN
    sp_them_lop_bt4('L03', '12_DH_CNTT2', 'K12', 'Chinh quy', 2023, 'CNTT', v_kq);
    DBMS_OUTPUT.PUT_LINE('Ket qua: ' || v_kq);
END;
/

--3.Makhoa kh tồn tại trả về 1
DECLARE
    v_kq NUMBER;
BEGIN
    sp_them_lop_bt4('L04', '12_DH_BDS', 'K12', 'Chinh quy', 2023, 'BDS', v_kq);
    DBMS_OUTPUT.PUT_LINE('Ket qua: ' || v_kq);
END;
/


























