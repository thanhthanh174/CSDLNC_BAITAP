--tạo bảng
CREATE TABLE tblChucVu (
    MaCV   VARCHAR2(10) PRIMARY KEY,
    TenCV  VARCHAR2(100)
);

CREATE TABLE tblNhanVien (
    MaNV         VARCHAR2(10) PRIMARY KEY,
    MaCV         VARCHAR2(10),
    TenNV        VARCHAR2(100),
    NgaySinh     DATE,
    LuongCanBan  NUMBER(10,2),
    NgayCong     NUMBER(5),
    PhuCap       NUMBER(10,2),
    CONSTRAINT fk_nv_chucvu
    FOREIGN KEY (MaCV)
    REFERENCES tblChucVu(MaCV)
);

--chèn dữ liệu mẫu
INSERT INTO tblChucVu VALUES ('CV01','Giam doc');
INSERT INTO tblChucVu VALUES ('CV02','Thu ky');
INSERT INTO tblChucVu VALUES ('CV03','Nhan vien');
INSERT INTO tblChucVu VALUES ('CV04','Lao cong');
COMMIT;

--thêm nhân viên 
CREATE OR REPLACE PROCEDURE sp_them_nhan_vien (
    p_MaNV        IN VARCHAR2,
    p_MaCV        IN VARCHAR2,
    p_TenNV       IN VARCHAR2,
    p_NgaySinh    IN DATE,
    p_LuongCanBan     IN NUMBER,
    p_NgayCong    IN NUMBER,
    p_PhuCap      IN NUMBER
)
AS
    v_dem NUMBER := 0;
BEGIN
    -- Kiểm tra MaCV tồn tại chưa
    SELECT COUNT(*) INTO v_dem
    FROM tblChucVu
    WHERE MaCV = p_MaCV;

    IF v_dem = 0 THEN
        DBMS_OUTPUT.PUT_LINE('MaCV khong ton tai!');
    ELSE
        INSERT INTO tblNhanVien
        VALUES (p_MaNV, p_MaCV, p_TenNV, p_NgaySinh,
                p_LuongCanBan, p_NgayCong, p_PhuCap);

        COMMIT;
        DBMS_OUTPUT.PUT_LINE('Them nhan vien thanh cong!');
    END IF;
END sp_them_nhan_vien;
/

--test 
BEGIN
    SP_Them_Nhan_Vien('NV10', 'CV02', 'Doan Ngoc Phuong Thanh', TO_DATE('30/10/2005','DD/MM/YYYY'), 8000000, 26, 2000000);
END;
/

BEGIN
    SP_Them_Nhan_Vien('NV10', 'CV05', 'Nguyen Thi Thuy Trang', TO_DATE('29/10/2005','DD/MM/YYYY'), 8000000, 26, 1000000);
END;
/

--cập nhật nhân viên
CREATE OR REPLACE PROCEDURE sp_capnhat_nhan_vien (
    p_MaNV        IN VARCHAR2,
    p_MaCV        IN VARCHAR2,
    p_TenNV       IN VARCHAR2,
    p_NgaySinh    IN DATE,
    p_LuongCanBan     IN NUMBER,
    p_NgayCong    IN NUMBER,
    p_PhuCap      IN NUMBER
)
AS
    v_dem NUMBER := 0;
BEGIN
    SELECT COUNT(*) INTO v_dem
    FROM tblChucVu
    WHERE MaCV = p_MaCV;

    IF v_dem = 0 THEN
        DBMS_OUTPUT.PUT_LINE('MaCV khong ton tai!');
    ELSE
        UPDATE tblNhanVien
        SET MaCV = p_MaCV,
            TenNV = p_TenNV,
            NgaySinh = p_NgaySinh,
            LuongCanBan = p_LuongCanBan,
            NgayCong = p_NgayCong,
            PhuCap = p_PhuCap
        WHERE MaNV = p_MaNV;

        COMMIT;
        DBMS_OUTPUT.PUT_LINE('Cap nhat thanh cong!');
    END IF;
END sp_capnhat_nhan_vien;
/

--test
BEGIN
    sp_capnhat_nhan_vien('NV10', 'CV02', 'Doan Ngoc Phuong Thanh', TO_DATE('30/10/2005','DD/MM/YYYY'), 10000000, 26, 2000000);
END;
/

BEGIN
    sp_capnhat_nhan_vien('NV10', 'CV05', 'Nguyen Thi Thuy Trang', TO_DATE('29/10/2005','DD/MM/YYYY'), 8000000, 26, 2000000);
END;
/

--tính lương
CREATE OR REPLACE PROCEDURE SP_LuongLN
AS
BEGIN
    FOR r IN (
        SELECT MaNV, TenNV,
               (LuongCanBan * NgayCong + PhuCap) AS Luong
        FROM tblNhanVien
    )
    LOOP
        DBMS_OUTPUT.PUT_LINE(
            'MaNV: ' || r.MaNV ||
            ' | TenNV: ' || r.TenNV ||
            ' | Luong: ' || r.Luong
        );
    END LOOP;
END;
/

--test
BEGIN
    SP_LuongLN;
END;
/




















